# Build and verification status — 28 October 2026

## Verified in the current source workspace

- `python3 tools/verify_source.py`: passed. Checks required integration files, confirms the `:core` module contains no Android framework imports, parses Android XML, checks microphone/notification/boot permissions and receivers, verifies language/notification catalog markers, and confirms CI accepts only the canonical ZIP, verifies its per-file SHA-256 manifest, checks the Memo-only launcher boundary, and includes core/app test, lint, and APK tasks.
- `python3 -m unittest discover -s tests -v` from `remote-runner/`: **12/12 tests passed**. Tests cover bearer-token authentication, explicit approval, workflow bounds, sensitive-text rejection, durable interrupted-job status, and final postcondition verification.
- All **10 Android XML files** parse successfully.
- The current source tree contains the persisted English/Polish/Turkish language preference, exact-string translation catalog/tests, tap-to-talk input, local notification center, daily reminder scheduling, workflow status notifications, and their manifest permissions/receivers.
- Cross-build feature inventory exists in `FEATURE_AUDIT.md`; priorities and acceptance criteria exist in `PRODUCT_GAP_REGISTRY.md`.

## Not verified — do not claim as passed

- Android/Kotlin compilation, Gradle JVM tests, Android lint, APK assembly, emulator tests, Accessibility behavior, real-device voice recognition, notifications, app automation, and remote paired-device behavior.
- I attempted `./gradlew --version`; its pinned Gradle download failed because this environment could not resolve `services.gradle.org`. No Android SDK/Gradle installation is available to finish the build locally.
- No APK is included or claimed to have been built. Use `.github/workflows/build-apk.yml` in GitHub Actions as the build gate, then install the resulting APK and complete `DEVICE_ACCEPTANCE_CHECKLIST.md`.

## Latest GitHub Actions findings — 28 October 2026

- Run #47: static checks and guest-runner tests passed; `:core:test` failed because the Android optional runtime was not selected for an automation intent.
- Run #48: the prior ZIP had Kotlin compile failures; those reported compile errors were corrected before run #49.
- Run #49: Kotlin compilation succeeded; `:core:test` failed in two tests due to automation intents being classified as BUILD when the wording also contained “app”.
- Current source change: explicit automation classification now precedes generic build classification. Static source validation, guest-runner tests, and a focused `kotlinc` smoke harness for planner + capability compiler + optional runtime selection pass in this workspace. Run #50 failed at `:app:lintDebug` with one `MissingPermission` error in `MemoNotificationCenter.kt`. The run's actual log shows the ZIP it built still used `runCatching { NotificationManagerCompat.from(context).notify(id, notification) }`; therefore run #50 did **not** test the newer explicit `POST_NOTIFICATIONS` guard plus `SecurityException` catch now present in the handoff ZIP. Core tests, app unit tests, Kotlin compilation, and `assembleDebug` passed for the older source in run #50. A fresh upload/CI run is required to verify the packaged fix. The local wrapper cannot resolve `services.gradle.org`, so full Gradle verification must come from GitHub Actions.

## Current release status

**Development source package; not release-certified.** Do not distribute as production-ready until Android CI is green, real-device acceptance is complete, the remaining product gaps are reviewed, and release signing/security checks have been completed.


## Director's Cut source reset — 28 October 2026

- Replaced the old duplicate Activity UI with `app.memo.android.runtime.MemoRuntimeBridge`; the accessibility service now reports status through Memo's listener boundary.
- Recentered the home experience on unsent conversational capture, linked records/sources, review attention and work continuity.
- Renamed active Compose app, viewmodel and design-token entry points to Memo-specific names. Extracted platform-independent domain contracts and deterministic rules into a new `:core` JVM module. Existing encrypted-vault aliases and filenames are intentionally unchanged.
- Updated `tools/verify_source.py` to cover the new product boundary and prompt handoff.
- Local Gradle compilation remains unavailable in this environment because the wrapper distribution cannot be downloaded. Run the delivered GitHub Actions workflow before treating this archive as build-verified.


## 28 October 2026 — exact-content approval slice

### Verified in this workspace

- `python3 tools/verify_source.py`: passed after adding the exact approval dialog's Polish/Turkish strings. Static translation scan: 283/283 eligible literal `Text()` labels across six scanned Compose UI source files have catalog entries.
- `PYTHONPATH=. python3 -m unittest discover -s tests -v` from `remote-runner/`: 12/12 passed. (Running the same discovery command from the project root fails because `server` is imported relative to `remote-runner/`; use the command above.)
- The actual `ActionApprovalLedger.kt` compiled with `kotlinc` in an isolated harness using minimal snapshot/evidence stubs. That harness passed proposal → approval → begin execution → evidence-backed completion, missing-evidence review, changed-payload invalidation, and audit-tamper detection. This validates the ledger logic's tested branches, not the Android/core integration or JSON codec.
- Added `ActionApprovalLedgerTest.kt` and schema v4 round-trip/tamper test. These tests have **not** been run through Gradle yet. Added `ActionApprovalInboxScreen.kt` under More with queue/review/history filters, exact-payload/audit inspection, rejection, guarded routing to a matching live browser approval, and explicit review for uncertain outcomes. The inbox cannot approve saved history.

### Blocking verification

- `./gradlew :core:test --offline --no-daemon` could not run because the Gradle wrapper attempted to download Gradle 8.14.6 and DNS resolution for `services.gradle.org` failed. Kotlin compilation of the full project, core JSON tests, Android unit tests, lint and APK build remain unverified.
- Browser WebView behavior and exact prompt approval must be tested on a real device after CI compilation passes. Global pause/stop and adoption of the shared ledger by native/guest/publication runtimes remain open product tasks. The new central inbox still needs Android compile and device acceptance.


## 2026-10-28 source increment

The action inbox and first top-level stop control are present in source. Static/source verification and guest runner tests are not substitutes for Kotlin/Compose compilation. Full Gradle testing remains blocked locally by the unavailable Gradle distribution download; no APK or device acceptance is claimed.


## Permanent repository rule

- `AGENTS.md` is now part of the canonical source package and mandates latest-CI-log-first debugging, root-cause fixes, regression tests, a durable change/evidence trail, checksums, and follow-through after every upload.
- Active target remains `ysfclc/memo` on `ysfclc-patch-1`. `memo-2` must remain untouched.


### Run #50 — 28 October 2026

- Run URL: `https://github.com/ysfclc/memo/actions/runs/40727323970`
- Commit: `39695492e6a8d8a7fe171fdf4d722f15c1cf5777`
- Passed: ZIP/source validation, remote runner tests, `:core:test`, `:app:testDebugUnitTest`, Kotlin compilation, and `:app:assembleDebug`.
- Failed: `:app:lintDebug`, one `MissingPermission` error at notification delivery (`POST_NOTIFICATIONS` may be denied/revoked).
- Follow-up: explicit Android 13+ permission guard and `SecurityException` handling added to `MemoNotificationCenter.kt`; next CI run must verify the fix.


## Handoff package reconciliation — 28 October 2026

- **Mismatch found:** the actual `:app:lintDebug` log from run #50 shows `runCatching { NotificationManagerCompat.from(context).notify(id, notification) }` at the reported line. The current handoff archive instead contains an explicit Android 13+ `POST_NOTIFICATIONS` permission check and a direct `try/catch (SecurityException)` around `notify()`. The current archive was produced after run #50 completed, so the failed run is not evidence that this updated source still fails.
- **Current archive checks:** `python3 tools/verify_source.py` passed; `PYTHONPATH=. python3 -m unittest discover -s tests -v` from `remote-runner/` passed 12/12; `sha256sum -c SOURCE_SHA256SUMS.txt` passed; `unzip -tq Memo-Android-Repository.zip` passed.
- **Local Android build attempt:** `./gradlew --no-daemon :core:test :app:testDebugUnitTest :app:lintDebug :app:assembleDebug` could not start because the wrapper could not resolve `services.gradle.org` (`curl: (6) Could not resolve host`). No new Gradle/lint/APK result is claimed.
- **Next verification gate:** upload this exact updated `Memo-Android-Repository.zip` to the root of `ysfclc/memo` on `ysfclc-patch-1`, replacing the canonical ZIP without renaming it. Inspect the newly triggered run and follow any actual failure; do not treat the fix as lint-verified until that run passes.


## CI-51 — notification fix verified

- Run: https://github.com/ysfclc/memo/actions/runs/40737354480
- Commit: `9cad0ef6064d14c62848d4d2d3184520f97f417a`
- Result: **success**. ZIP/source validation, remote runner tests, `:core:test`, `:app:testDebugUnitTest`, `:app:lintDebug`, `:app:assembleDebug`, APK preparation and artifact upload all completed successfully.
- This verifies the notification-permission fix in the uploaded source. It does not constitute physical-device acceptance.

## WP-12 — workflow graph foundation (pending CI)

- Added persisted graph and trigger metadata, dependency validation/readiness rules, and tests.
- Local `./gradlew --no-daemon :core:test` was attempted but could not download Gradle 8.14.6 because DNS resolution for `services.gradle.org` failed. The newly added Kotlin tests have not yet run locally.
- Await GitHub Actions after uploading the next canonical source ZIP; no build result is claimed for this increment until that run completes.


## WP-13 — 29 October 2026: workflow runtime safety and model integrity

### Source-level checks that pass in this workspace

- `python3 tools/verify_source.py`: passed after expanding the structural checks to cover the workflow execution state machine, cancellation-ledger integration, exact model SHA-256 pins, safe model replacement and Paper + Mint palette tokens. The current static UI translation scan finds all eligible literal `Text()` labels in the catalog.
- Direct `kotlinc` smoke harness compiles the actual `WorkflowGraphPolicy.kt` and `WorkflowExecutionEngine.kt` using minimal stubs for the data model, and exercises start/outcome, correlation token, stale-result rejection, timeout/manual-retry bound, audit tampering, graph readiness, and global stop even with a damaged audit log. This is a focused test harness, not the Gradle test suite.
- `PYTHONPATH=. python3 -m unittest discover -s tests -v` from `remote-runner/`: expected 12/12 pass; rerun with the packaged source before delivery.
- Model catalog downloads now require exact byte length and a pinned SHA-256 before installing; an existing model is staged as a rollback copy during replacement. The UI exposes workflow audit history, progress/ready-step counts and a per-job cancel confirmation. The local-model generated-artifact path carries the launch execution token; stale results are not attached to a cancelled or newer run. Cancellation invalidates unused external-action approvals while flagging in-progress actions for destination review.

### Still unverified / blocking

- Android/Kotlin/Compose compilation, Gradle `:core:test`, `:app:testDebugUnitTest`, lint, APK assembly, on-device behavior and actual LiteRT-LM execution are **not verified for this source increment**. No fresh CI run has tested this archive.
- The execution engine is a tested deterministic state machine, but not every existing browser/native/local/remote executor has yet been converted to pass its captured execution token. The timeout sweep is process-local (15-second ViewModel loop), not a durable background trigger. The app remains a partial product build.
- Local Gradle is blocked before startup because this environment cannot resolve `services.gradle.org`. The next decisive gate is CI on the exact uploaded canonical archive, followed by device acceptance.


## WP-14 — DOM discovery slice (29 October 2026)

- Source verifier: **PASS**.
- Remote runner suite: **12/12 PASS**.
- Extracted DOM discovery JavaScript syntax check: **PASS** (`node --check`).
- DOM security fixture: **PASS** (`node tools/test_dom_discovery.js`), including password/hidden/OTP exclusion and a throwing field-value getter; wired into GitHub Actions.
- New schema policy/codec JVM tests and Android/Compose compilation: **not run**; pinned Gradle distribution cannot be downloaded in this offline environment.
- APK build, lint and device interaction: **not verified for this increment**.
- Source status: read-only DOM inventory and versioned proposed schema persistence implemented; generic execution/Teach & Select remains incomplete.
