# Permanent repository operating rules

Read this file before every change to Memo source, tests, packaging, or workflow.

## Source and branch boundaries
- The active implementation is `ysfclc/memo`, branch `ysfclc-patch-1`.
- The canonical Android source package is `Memo-Android-Repository.zip`. Preserve this exact filename in every handoff.
- **Never modify, push to, merge into, or treat `ysfclc/memo-2` as the implementation target.** It is a reference blueprint only.
- Treat the newest uploaded canonical ZIP and newest branch workflow as the source of truth. Do not continue from an older local snapshot without reconciling it first.

## Required engineering loop
1. Inspect the latest GitHub Actions run on `ysfclc-patch-1` before editing. Read the actual failing step and logs; do not infer failures from status badges or older runs.
2. Extract and inspect the latest `Memo-Android-Repository.zip` before modifying source.
3. Fix the production cause of a failure. Never weaken, delete, skip, or rewrite a test solely to obtain a green workflow. Add regression coverage for behavior changes.
4. Run every check available locally. Label static validation, pure Kotlin tests, Gradle JVM tests, Android compilation, lint, APK assembly, and device acceptance separately; one is not proof of another.
5. Keep a durable evidence trail in `IMPLEMENTATION_LOG.md`, `CHANGELOG.md`, `TASKS.md`, and `BUILD_STATUS.md` as relevant. Record the requirement, root cause, files changed, commands, exact results, known gaps, and CI run URL/number plus commit SHA when available.
6. Regenerate `SOURCE_SHA256SUMS.txt` after source edits; verify it with `sha256sum -c`, run `unzip -t`, and deliver `Memo-Android-Repository.zip` with an external SHA-256 receipt. Never claim a check ran if it did not.
7. After the user uploads a package, inspect the newly triggered run and keep following the actual failure until the workflow passes or a specific blocker is documented. Record every new failure in the source trace.
8. Continue implementation in coherent product slices. Do not substitute dashboards, mock buttons, placeholders, or documentation-only work for working behavior when implementation is possible.

## Product and safety invariants
- Preserve Memo's local-first/privacy boundary, existing app identity, encrypted-vault names and aliases, and stored-data compatibility unless a migration is designed and tested.
- Models may propose or enrich; deterministic policy owns routing, permissions, approvals, workflow state, audit, cancellation, retries, and postcondition verification.
- External/destructive actions must be visible, bounded, and gated by approval bound to the exact current content and scope.
- Never claim a feature is complete because code exists. Require its relevant tests and acceptance evidence; distinguish CI success from real-device acceptance.
- Keep credentials, tokens, private user data, decrypted vaults, cookies, and machine-specific build caches out of source, logs, screenshots, and archives.

## Required handoff
State what changed and why, the checks actually completed, what remains unverified, the canonical archive and checksum, and the exact next action. The trace must live in the repository, not only in chat.
