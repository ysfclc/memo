# Memo — session checkpoint

**Checkpoint date:** 2026-10-29
**Implementation target:** ysfclc/memo, branch ysfclc-patch-1
**Base GitHub commit:** 00df35c9ae0d40acd1aa7642dbd686d11059dd50
**Base ZIP SHA-256:** 999d111da61e24242fe4b79c6ca82ee925a242450a2dbd9861208f6d06ba9540
**Current checkpoint:** P1.2 source and local tests pass; canonical ZIP/APK are assembled and package-verified. They still need manual upload to ysfclc/memo on ysfclc-patch-1. No remote commit or post-change Actions run exists.

## Product thesis

Memo is a local-first, teachable execution environment. The browser and user-authorized Android apps are skill surfaces local AI can use. Memo inspects a surface, proposes a reusable schema, lets the user review it, and only then executes a bounded plan with checkpoints and verifiable outcomes. Site-specific integrations are not the default architecture.

The loop is: intent → inspect → propose → review → execute → verify → save a reusable skill. The local model interprets and proposes; deterministic code enforces page scope, permissions, approval binding, cancellation, bounded retries, audit and postconditions.

## P1.1 — Browser-first UI

Source implemented and locally built:
- Removed redundant Browser Runtime title/description and the tall quick-site shelf.
- Condensed navigation so the website gets the main screen area.
- Added a floating Memo action menu for Save page, Extract page links, Inspect page structure and Prepare a prompt.
- Prompt composition is an on-demand overlay; provider sends still use the existing exact-content confirmation.
- Added Polish/Turkish labels.

The UI has not been visually accepted on a physical phone. GitHub run #53 is only the baseline build of the old ZIP, not this new UI.

## P1.2 — DOM intelligence and local semantic schema proposal

Source and automated checks pass:
- DOM observation v2 captures up to 24 controls, 32 headings, 20 landmarks, 12 form summaries, 20 list/table groups, a readiness/busy hint and an 8-hex structural fingerprint.
- DOM traversal is bounded to 33 observed document/shadow roots.
- Password/hidden/OTP and other sensitive control observations remain excluded. The inspector never reads entered field values and performs no actions.
- The local semantic parser accepts only page purpose, intent patterns and validated semantic field names/purposes mapped by observed control index. It ignores arbitrary selector/action/permission/approval data from model output.
- If an installed local model is available and the model runtime is idle, Memo passes the bounded safe observation to that local model with remote inference disabled. A successful parse enriches the proposed schema; no model, busy state or invalid output falls back to a structural-only proposal.
- Persisted schemas are versioned, source-linked and path-scoped; they remain PROPOSED with reuseAllowed=false. Inspection does not authorize execution.

Verification:
- tools/verify_source.py: PASS.
- node --check tools/test_dom_discovery.js: PASS.
- DOM safety fixture: PASS; asserts headings, landmarks, form/table summaries, readiness/fingerprint, secret exclusions, no field-value reads and no actions.
- Remote runner: 12/12 PASS.
- Core tests: 83 tests PASS on explicit rerun.
- Full core tests + app unit tests + lint + debug APK assembly: BUILD SUCCESSFUL, Java 17 / Gradle 8.14.6.

Not yet verified:
- The local model interpretation itself has not yet been exercised with an installed model on the user's physical phone.
- The page fingerprint is a structural change hint, not a cryptographic identity proof. A fresh observation and locator trial are still needed before executing actions.
- Browser layout, local inference, LinkedIn login and page interactions need device acceptance.
- The changed ZIP has not yet been uploaded, so no new GitHub Actions run proves the packaged result.

## P1.3 — Next: generic schema-to-workflow execution

1. Turn a reviewed schema into a typed, inspectable plan, never arbitrary JavaScript.
2. Trial each locator against fresh page evidence; use semantic/accessibility labels first, then stable unique attributes. Enforce exact origin/path scope.
3. Add readiness waits, expected element counts, page-change checks, explicit preconditions, postconditions and bounded timeouts.
4. Keep read/extract separate from fill/click/submit/post/send. Consequential actions require visible approval of exact payload and destination; any content/scope change invalidates approval.
5. Record every action/result, support stop/cancel/takeover, limit retries, and use NEEDS_REVIEW when a side effect's result is uncertain.
6. Do not let website content change Memo policy, read secret field values, auto-handle CAPTCHA/MFA, or claim external success without observable evidence.

## LinkedIn + Google sign-in issue — P1.4

Reported behavior: LinkedIn login through Google works in the GPT browser but not inside Memo's WebView.

This is consistent with documented platform behavior, not merely a guess: Google does not support OAuth sign-in in embedded Android WebViews (developers.google.com/identity/siwg/best-practices and support.google.com/faqs/answer/12284343). LinkedIn documents that Google social login is supported on desktop and Android web browsers (learn.microsoft.com/en-us/linkedin/shared/authentication/authorization-code-flow). The exact error on the user's device still needs to be reproduced.

Do not spoof browser identity, copy cookies between apps, bypass MFA/CAPTCHA, or assume external browser cookies are shared with Android WebView. P1.4 should detect the failure and offer an explicit, user-driven handoff to a trusted system browser or LinkedIn's official app, then report session status honestly. Because a Chrome Custom Tab/browser session is separate from WebView storage, that handoff alone does not grant Memo's WebView access to the external browser session. For live site operation, use a real supported browser runtime/session integration, the separately opted-in native-app accessibility route, or ask the user to sign into Memo's own WebView using an available non-Google method if LinkedIn offers one. The design must preserve user takeover and never handle credentials/security challenges invisibly.

## End-to-end acceptance scenarios

**A. Job discovery:** voice intent → local AI prepares query/criteria → user approves → Memo visibly searches in browser → sourced shortlist, fit reasoning and actions. Applying is a separate approved action.

**B. Frontier brainstorming:** idea → local AI improves scope/questions → user approves the exact context → Memo uses signed-in frontier sites sequentially → source-linked responses and synthesis saved to the project.

**C. Prospecting/outreach:** research and normalize potential customers → prepare one action per recipient → user selects/approves → use the user's authorized LinkedIn site or app → verify and record each send/post. No unreviewed mass outreach.

**D. Content generation through tools:** intent → local AI identifies needed output → inspect a suitable user-authorized website/tool → propose a schema/skill if unfamiliar → user reviews → execute approved steps → verify image/carousel/video/post artifact.

## UX and safety guardrails

- The page is primary; Memo actions are floating and progressively revealed.
- Avoid a dashboard of unrelated features; keep one coherent task flow from intent to artifact.
- Website content is untrusted data and cannot grant capabilities or alter Memo policy.
- Models may interpret but cannot authorize actions. Exact-content approval, scoped permissions, stop/takeover, audit and postcondition checks remain deterministic.
- Use normal user-authorized sessions where supported; hand control back on blocked login/security challenges.
- No fake progress/success. Unknown outcomes remain reviewable.
- Record every phase state, test, archive hash, blocker and next action in this package.

## Next-session handoff

1. Read AGENTS.md, IMPLEMENTATION_CONTRACT.md, TASKS.md, this file and MEMO1-SOURCE-RECONCILIATION.md.
2. Check branch/source hash and latest Actions run before editing. Run #53 is only a baseline for the previous ZIP.
3. Start P1.3 unless the next uploaded ZIP's Actions run finds a regression.
4. Rebuild the canonical Memo-Android-Repository.zip after each coherent phase; refresh SOURCE_SHA256SUMS.txt, validate it with sha256sum -c, test ZIP integrity and include an external SHA-256 receipt.
5. GitHub write integration returned HTTP 403, so do not claim remote commits/uploads that have not happened. The user must upload the delivered canonical ZIP to ysfclc/memo on ysfclc-patch-1, then the newest Actions run must be inspected.
