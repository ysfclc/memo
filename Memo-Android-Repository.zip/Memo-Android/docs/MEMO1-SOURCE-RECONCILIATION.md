# Memo 1 source reconciliation — checkpoint 2026-10-29

**Purpose:** evidence for the P1-0 source gate. This report distinguishes the active Memo 1 implementation from the separate source archive on the repository's main branch.

## Source identities

| Evidence | Memo 1: ysfclc-patch-1 | Separate main snapshot |
|---|---|---|
| Commit observed | 00df35c9ae0d40acd1aa7642dbd686d11059dd50 | fd69fcabd0ddafc9cf73e615fc4386a6b45fd3aa |
| ZIP Git blob | 88e2f301c567e77bf912ddb9d155c39e78a7b633 | 52e6ad6c627670a717a22330493934549f1c837f |
| ZIP bytes | 473,361 | 2,008,638 |
| ZIP SHA-256 | 999d111da61e24242fe4b79c6ca82ee925a242450a2dbd9861208f6d06ba9540 | d0d72ea8ec7a4bbaabb9c80f399e0d924f7c121e71230cc3ab0773c2cd32f792 |
| ZIP entries (files + directories) | 194 | 328 |
| Project root | Memo-Android/ | Memo-Android-Repository/ |
| Original regular files | 119, including 2 Python bytecode cache files | 227 |
| CI baseline | Run #53 passed on original ZIP | Run #31 passed on the distinct main ZIP |

Both SHA-256 values were calculated from the actual ZIP bytes. unzip integrity checks passed for both. The active patch1 ZIP was preserved separately before source edits.

## Path-level comparison

Comparing pristine extracted source snapshots, excluding bytecode caches and generated build output:
- Memo 1 paths examined: 117 (including its internal checksum manifest).
- Main snapshot paths examined: 227.
- Paths only in Memo 1: 107.
- Paths only in main: 217.
- Shared relative paths: 10; all ten have different contents.

The shared filenames are .gitignore, AGENTS.md, CHANGELOG.md, README.md, app/src/main/AndroidManifest.xml, app/src/main/res/values/strings.xml, gradle.properties, gradle/wrapper/gradle-wrapper.properties, gradlew and gradlew.bat. These projects are structurally different and their ZIPs are not interchangeable.

## Architecture and storage observations

### Active Memo 1 — preserve
- Build scripts: Gradle Groovy (build.gradle and settings.gradle).
- Namespace/application ID: app.memo.android; debug suffix .debug.
- Main workspace: app/src/main/java/app/memo/android/ui/MemoWorkspaceApp.kt.
- Browser runtime: app/src/main/java/app/memo/android/browser/BrowserSession.kt, BrowserScripts.kt and BrowserWorkflow.kt.
- The browser is an Android WebView. Current DOM discovery is a read-only bounded JavaScript inventory; a versioned schema proposal is saved as proposed/unapproved. The general schema-to-workflow executor is not complete.
- Primary vault: EncryptedVault.kt writes atomically to filesDir/synthos-vault.bin; cipher AES/GCM/NoPadding; Android Keystore alias synthos_fieldwork_vault_v1; associated data Memo-Android:v1; snapshots serialize as JSON.
- Legacy com.synthos.runtime.data.SynthStore and AccessibilityService code remain. Unification of workspace and native workflow persistence is still an open gap. This UI increment does not change storage.

### Separate main snapshot
- Build scripts: Kotlin DSL (build.gradle.kts and settings.gradle.kts).
- Namespace/application ID: app.memo.
- Android entry point: app/src/main/kotlin/app/memo/MainActivity.kt.
- Different application identity, source tree and dependency/build contract. Its source was not copied into Memo 1 and main was not modified.

### Compatibility decision
Do not transplant main source or replace the Memo 1 ZIP. Preserve Memo 1 application ID, vault filename, KeyStore alias, AAD and existing data formats. Any storage consolidation requires a reviewed, versioned migration, backup/rollback design and migration tests.

## G0 evidence status

| Gate | State | Evidence / remaining work |
|---|---|---|
| P1-0.1 Source identity | Complete for both snapshots | Commit, blob SHA, size, SHA-256, integrity and entry counts above. |
| P1-0.2 Inventory | Initial inventory complete | MEMO1-SOURCE-INVENTORY.txt and architecture notes above. |
| P1-0.3 Snapshot comparison | Complete for these snapshots | Path comparison above; all ten shared files differ. |
| P1-0.4 Architecture mapping | Partial | Main runtime/source mapping captured; detailed requirement-to-file mapping remains open. |
| P1-0.5 Storage compatibility | Partial | Memo 1 vault identity captured; full schema/backup/version audit and migration tests remain open. |
| P1-0.6 Baseline CI | Complete for original patch1 ZIP | Run #53 green before WP-15; it does not test the changed ZIP. |
| P1-0.7 Acceptance ledger | In progress | Tasks and current session checkpoint now include use cases and phase ordering; more path/test/device mapping remains. |
| P1-0.8 Workflow alignment | In progress | Existing workflow validates the canonical ZIP. Upload updated ZIP and inspect its new Actions run. |

**No remote commit or CI run is claimed for the updated ZIP.** The connected GitHub write integration returned HTTP 403. The new ZIP is a local checkpoint for manual upload.


## Implementation delta after baseline — 2026-10-29 (P1.1 + P1.2, local only)

The original archive remains the source identity baseline above. The local working copy adds the browser-first UI and P1.2 DOM observation/schema proposal. These changes have not been uploaded to the branch because GitHub content writes are unavailable through the connected integration. Run #53 does not test this working copy.

P1.2 checks run locally: source verifier PASS; DOM discovery safety fixture PASS; remote runner 12/12; core tests 83/83 PASS; app unit tests PASS; lint PASS; debug APK assembly PASS. No physical-device acceptance is claimed.
