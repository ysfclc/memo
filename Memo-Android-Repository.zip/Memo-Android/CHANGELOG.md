# Changelog

## 2026-10-26 — Voice entry, local reminders, and whole-product audit

- Added permission-gated tap-to-talk input in chat. Speech transcripts enter the editable message draft; the feature does not send automatically or claim always-on listening.
- Added opt-in local daily reminder scheduling, workflow terminal-status notifications, generic/private lock-screen text, notification permission/settings handling, and reboot/time-change rescheduling.
- Added Polish/Turkish strings for voice and notification controls and tests for the language catalog.
- Added `FEATURE_AUDIT.md` and `PRODUCT_GAP_REGISTRY.md` to distinguish current source features from source-branch-only ideas, planned work, and unverified Android behavior.
- Release status remains unchanged: Android build/lint/device acceptance are not claimed until they pass.


## 2026-10-26 — Interface language settings

- Added a persisted interface-language preference with English, Polish, and Turkish options in Settings.
- Routed workspace UI text through the translation catalog while preserving unrecognized/user-entered text.
- Localized navigation, core settings, workspace entry points, workflow controls and lock-screen copy where catalog entries exist.
- Added tests for English fallback, Polish/Turkish core labels, and preserving unknown/user text.

## 4.0.0-memo — Integration build (2026-10-26)

- Consolidated the richer Compose workspace, browser-based frontier-AI workflows, encrypted typed work graph, model/Council capabilities and source-grounded outcome review into the Memo Android application ID and branding.
- Added **Apps & automation**: installed app inventory/launcher, revisioned workflow editor, run/history details, exact-text actions, final visible-text postconditions, explicit stop handling, Accessibility permission onboarding and manual floating capture entry points.
- Registered External Android as a separate runtime; its action capabilities are distinct from browser and in-app capabilities, and label taps explicitly require user initiation/approval.
- Added optional HTTPS guest runner configuration, encrypted bearer-token storage, connection checks, explicit per-workflow approval, guest status/cancel controls and companion Python tests.
- Updated build tooling to Gradle 8.14.6 and Kotlin 2.4.21, added native workflow policy tests, and embedded the GitHub workflow at `.github/workflows/build-apk.yml`.
- Corrected stale documentation that described native app inventory/automation as absent.

### Verification boundary

- XML resources/manifest parse successfully.
- Guest runner tests: 12/12 passed.
- Android Gradle build, Kotlin compilation, lint, emulator and device tests could not be run in the editing environment because no Android SDK/Gradle distribution is installed and network DNS resolution for `services.gradle.org` failed. They remain unverified; do not treat this integration source as a release-signed or device-validated APK.

### Known integration debt

- The primary Compose workspace vault and legacy native workflow vault remain separate encrypted stores.
- Browser workflow surfaces are not yet a generic versioned DOM schema executor.
- Cross-runtime dependency DAG execution, full app/web schema editing, file/media pipeline completion, channel publishing/engagement analytics and broad device model discovery still need implementation.

## 3.1.0 — Frontier browser workflows and source-grounded outcomes

Retained from the integrated source branch: visible browser-based frontier consultations, sequential multi-provider comparison, critique chains, provider-response entities, local output mapping and source-checked entity proposals.
