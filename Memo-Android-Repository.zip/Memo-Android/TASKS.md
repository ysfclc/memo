# Memo — Product contract and delivery tasks

**Purpose:** Recover and continue Memo as its own product. This file is a consolidated execution backlog based on the existing README, feature audit, gap registry, device acceptance checklist, and Memo architecture blueprint. It is not a claim that every earlier conversation or uncommitted task was recovered.

## Product contract

Memo is a local-first personal execution environment. Conversation is the easiest way to interact; it is not the database. Durable records, relationships, source evidence, tasks, decisions, and verified work live behind the conversation and can be opened independently.

1. **Memo owns the product experience.** Other projects are donors for bounded primitives only. Do not import their complete screens, Activity trees, or storage assumptions as the product shell.
2. **One accepted truth, with provenance.** Proposals remain distinct from accepted records. Important facts and actions retain source, timestamp, excerpt, and decision/run lineage where available.
3. **Local-first and explicit disclosure.** Capture, search, internal records and compatible on-device inference should not require a cloud account. A remote request must preview its context and obtain per-request consent.
4. **Evidence before success.** Model output is untrusted. Deterministic validation, bounded permissions, human approval for material actions, and observable postconditions are required.
5. **Human-in-the-loop always.** Local AI may plan and operate only through user-authorized app/browser surfaces; every external or destructive action is bound to the exact destination and content approved. Changed content requires fresh approval. The user can pause, take over or stop; AI cannot grant itself permissions.
6. **No hidden or duplicate runtime UI.** Browser, local models, Android app automation and a separately configured guest runner are replaceable capabilities behind narrow interfaces.
7. **Security is a product feature.** Preserve existing vault identity for upgrades; do not rename storage keys or files without a migration. Plaintext export must be clearly disclosed. Never log secrets or private payloads.

## Director's Cut reset — current increment

- [x] Establish a real `:core` JVM module for platform-independent record/task/job schemas, deterministic validation, runtime capability contracts, and their pure JVM tests. The Android app depends on it; core has no Android framework imports.
- [x] Rebrand active Compose app entry points and shared design tokens as Memo-specific names.
- [x] Replace the generic dashboard with a Memo-first home: quick prompt capture, connected records, sources, review attention, recent conversation, work in motion, and specialist capabilities.
- [x] Make the home prompt open a conversation with the text placed in the composer as an **unsent draft**. Sending still requires the user's explicit action and model/provider policy.
- [x] Remove the unused legacy SynthOS `MainActivity.java` UI tree; replace its static helper role with `MemoRuntimeBridge`.
- [x] Route accessibility-runtime state and service messages through a listener interface instead of a second Activity. Keep optional native automation bounded and user-enabled.
- [x] Preserve existing encrypted-vault filenames and key aliases to avoid breaking existing local data.
- [x] Add this consolidated backlog and update offline structural checks for the one-Activity boundary, domain module, and canonical delivery.
- [ ] Run the packaged Gradle wrapper in GitHub Actions and resolve any compiler/test/lint failures before calling the archive build-verified.
- [ ] Install the APK on a real Android device and complete `DEVICE_ACCEPTANCE_CHECKLIST.md`.

## P0 — trustworthy delivery

- [x] Make the canonical ZIP the only build input; validate ZIP entries, verify a per-file SHA-256 manifest, and emit a checksum receipt for the source archive.
- [ ] Require `:app:testDebugUnitTest`, `:app:lintDebug`, and `:app:assembleDebug` to pass in CI.
- [ ] Publish the APK and SHA-256 checksum as a GitHub Actions artifact; keep test/lint reports on failure.
- [x] Add a regression check that only one launcher Activity is shipped and runtime updates use Memo's bridge.
- [ ] Do not call the package production-ready until real-device checks and signing/security review pass.

## P1 — one durable Memo workspace

- [ ] Define stable domain contracts for Conversation, Source, Entity, Relationship, Task, Job, Decision, Artifact, and Run.
- [ ] Move persistence behind repositories and use explicit schema/migration versions. Avoid separate UI-owned stores for canonical facts.
- [ ] Plan a compatibility-preserving migration that unifies the Compose workspace vault and native workflow/run vault without losing user data.
- [ ] Preserve immutable capture originals, content hashes, source metadata, and human review decisions.
- [ ] Add encrypted portable backup/restore with authenticated manifest, compatibility checks, atomic restore and clear failure recovery. Keep readable JSON export an explicit opt-in exception.

## P2 — cohesive daily experience

- [ ] Keep conversation and quick capture as the easiest entry point; add voice capture without taking over the screen.
- [ ] Turn records, links and people into a navigable connected workspace. Search must span conversations, evidence, entities, relationships and tasks.
- [ ] Make source/decision cards open the original evidence and its context.
- [ ] Use a shared Memo token/component system, dynamic type, screen-reader labels, reduced motion, and robust keyboard/IME behavior.
- [ ] Complete Polish/Turkish review of all high-traffic screens; preserve user-authored/model text without accidental translation.

## P3 — trustworthy intelligence and execution

- [ ] Keep model providers behind replaceable adapters with actual streaming, cancellation, compatibility checks, and accurate failure states.
- [ ] Version skills, tool contracts, schemas, browser selectors and workflow definitions; pin versions into a run manifest.
- [ ] Add a dependency-aware executor across approved runtimes with durable checkpoints, idempotency keys, postcondition evidence and cancellation.
- [ ] Recover interrupted work into a review state; never blindly replay an uncertain external side effect.
- [ ] Keep browser work visible, isolated from privileged storage, and bounded by explicit page/action policies.
- [ ] Make local-model install/availability truthful: not installed, unsupported, loading, ready, and failed are distinct states.

## P4 — optional capability expansion

- [ ] Complete multi-file/share/file capture and a resumable media pipeline before adding broad OCR/video features.
- [ ] Treat Council/multi-model comparison as an optional specialist tool, not the product's default identity.
- [ ] Device-verify AccessibilityService, overlay permission and Android background behavior. Remote guest execution remains separately configured, HTTPS-only and explicitly approved.
- [ ] Defer public publishing, unattended microphone, generalized scraping and autonomous outbound actions until permissions, previews, receipts and rollback/review policy are proven.

## Acceptance rules

- A button is not evidence that a feature works.
- A source file or unit test is not evidence of successful APK generation.
- A successful APK build is not evidence of device-level compatibility or production security.
- A model's claim is not proof of an external side effect; use observed postconditions and retain uncertainty.


## 28 October 2026 — exact-content browser approval slice

- [~] Added `ActionApprovalLedger` in `:core`: approvals bind runtime, capability, destination and exact payload; approvals expire, are one-use, and are invalidated on payload/destination mismatch or process restart. A SHA-256 chained event log records proposals, approvals, rejection, execution start, verified completion and review states. This is tamper-evident, not a claim of authenticated/immutable audit storage against a fully privileged editor.
- [~] Connected visible frontier website prompt submission to a full exact-prompt preview and explicit per-provider approval. Memo must persist the proposal, pass the current-hash gate, recheck the live provider destination immediately before submission, and save the observed response as evidence before marking the action complete. A rejection stops the sequence.
- [~] Bumped the workspace JSON schema to v4 with backward import support for v1-v3. Portable imports invalidate pending/approved actions; process recovery invalidates approvals tied to lost browser context and moves in-flight external actions to `NEEDS_REVIEW`.
- [~] Added `ActionApprovalLedgerTest.kt` coverage for hash binding, one-use approval, mismatch invalidation, evidence-backed completion, import/restart recovery, schema round-trip, and audit-chain tampering. Static source checks pass; the pure ledger behavior was exercised with a standalone Kotlin harness. Full Gradle core/app tests, Android compilation/lint, and live WebView/device acceptance remain **unverified** because the Gradle wrapper distribution could not be downloaded in this environment. Do not mark M0/F1 or the product milestone complete.
- [~] Added `ActionApprovalInboxScreen.kt` under More: queue, needs-review and history filters; counts; exact payload/hash, destination/runtime/capability, evidence and recent audit details; reject; and mark uncertain actions for review. It only navigates to the live browser confirmation when the prompt hash and destination match the pending action. Historical/stale approvals cannot be approved in the inbox.
- [~] Tightened import verification to reject orphaned audit events and included audit timestamps/status in the workspace size estimate. Additional regression coverage for orphaned events, expiry and rejection is present but not Gradle-run.
- [ ] Next: run the complete Gradle suite on CI; fix compiler/test/lint errors; wire the same gate into native/guest/publishing side effects; implement a real global pause/stop and durable dependency-aware workflow checkpoints; then complete device acceptance.


## 28 October 2026 — top-level stop control increment

- **Task family/status:** M0 cancellation + HITL safety gate, `[~]` partial. This is not a durable global cancellation token and does not prove that an already-issued external side effect was rolled back.
- **Files:** `app/src/main/java/app/memo/android/ui/MemoWorkspaceApp.kt`; `tools/verify_source.py`; `PRODUCT_GAP_REGISTRY.md`; `FEATURE_AUDIT.md`; `BUILD_STATUS.md`; `CHANGELOG.md`; `SOURCE_SHA256SUMS.txt`.
- **Behavior:** header stop requests cancellation of local AI generation, browser workflow, pending browser task, and active AccessibilityService automation. Pending external proposals are rejected. Approved/in-flight actions are moved to `NEEDS_REVIEW`, so uncertain side effects are not represented as undone or replayable. A last-known nonterminal guest job receives a best-effort cancellation request; the user is told to verify the final remote state.
- **Evidence:** source structure check added; targeted Kotlin compilation/Gradle, runtime cancellation race tests, and device acceptance remain unverified.
- **Commit:** none in this session; a source ZIP is provided. Full milestone remains open.
