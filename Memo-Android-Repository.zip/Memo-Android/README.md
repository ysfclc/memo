# Memo for Android

Memo is a mobile-first, local-first personal workspace that combines conversation, a real in-app web browser, visible app interaction, tasks, workflows, a shared people/company/opportunity record layer, saved sources, and private content drafts.

This repository is the Android application source. It is not the former HTML prototype and it is not an iOS project.

## The product in the app

- **Talk** — conversation-first tasking. The local model receives a bounded prompt assembled from available skills, saved tasks/records, app metadata, and recent evidence. If no compatible local model is configured, Memo tells you; it does not fake an AI response.
- **Browse** — an HTTPS-only WebView with address/search, back/forward/reload, page inspection, saved cookies for normal site login flows, uploads from Android's single-file picker, and user-initiated popups kept inside Memo. Page contents are untrusted input and are never treated as instructions to override Memo's policies.
- **Apps** — searchable installed-app inventory, launch/management affordances, evidence-linked UI observations, and first-party web-companion links for common online apps (for example Gmail, LinkedIn, ChatGPT, Claude, Reddit, WhatsApp and others) that stay inside Memo's browser. Android does not let an ordinary application embed arbitrary third-party native app screens as in-process child views. For native-only apps, Memo opens the real Android app and can show its optional floating control panel over it.
- **Floating Memo** — a movable, collapsible cross-app action bubble with Talk, Browse, Capture, Task, Work and Library. It is opt-in and requires Android Accessibility plus Display over other apps. Nothing is captured until the user taps Capture. Only accessible UI labels are observed; editable-field values and passwords are excluded.
- **Work** — durable tasks, workflows, execution runs, local AI jobs and their recovery/review states.
- **People & opportunities** — one encrypted record collection for contacts, companies, opportunities, projects and their source references. Saved browser pages and Android share-sheet content can be turned into records or drafts.
- **Studio** — editable private drafts, including content, emails, application notes and briefs. Drafts can be copied to the Android clipboard or marked ready; Memo does not auto-post or silently send them.
- **Library** — local source shelf for pages, notes, shared links/text and explicit accessible-screen captures.
- **Device AI inspection** — automatically matches names of launchable AI apps and searches model formats in the files Android exposes. An optional second stage can inspect model filenames and sizes throughout shared storage after you explicitly enable Android's sensitive All files access. It never opens model contents during discovery; importing a model is a separate action. Memo cannot access another app's private directory.

## Security posture

- The application requires a device screen lock and uses Android biometric/device-credential authentication before opening the workspace.
- The local workspace is encrypted at rest with AES-GCM and an Android Keystore-held key; writes use an atomic replacement strategy. New capture and CRM-style records live in the existing encrypted vault and are additive to prior stored data.
- Android backup is disabled. `FLAG_SECURE` prevents ordinary screenshots and recents snapshots of Memo's own UI; it does not protect the external screen while another app is in front.
- The built-in browser only allows HTTPS top-level navigation, blocks mixed content, disables file/content URL access, uses Safe Browsing and does not expose a JavaScript bridge. Website forms, password managers, CAPTCHA and provider sign-in behaviour can still vary. Popups are kept inside Memo when the site supports normal WebView popup handling.
- The cross-app service only works after explicit Android settings consent. It does not read password/editable field values, and it pauses workflow execution when the device locks or the target app leaves the foreground.
- Local AI models are selected/imported by the user. The app's current built-in LLM runtime accepts compatible `.litertlm` files; other detected extensions are matches/inventory hints, not claims of compatibility.
- The optional full shared-storage scan asks the user to visit Android's settings. It only scans shared storage and skips app-private `Android/data` and `Android/obb` areas. All files access is sensitive and may not qualify for Google Play distribution without an approved core use case; review Play policy before publishing there.
- Export is intentionally an explicit action and produces readable JSON. Treat exported data as sensitive.
- Optional remote guest execution is inherited and off until explicitly configured. Do not configure an untrusted endpoint. The app never sends chat history or model context through the remote runner; inspect `REMOTE_RUNNER_PROTOCOL.md` before enabling it.

## Build prerequisites

- Android Studio with Android SDK Platform 35 and Build Tools 35.0.0.
- JDK 17 or later (JDK 21 is suitable).
- Gradle 8.9 and internet access for Gradle plugins/dependencies.
- A physical Android device or emulator running Android 10/API 29 or newer.

The source archive intentionally does **not** claim to contain a compiled APK. This execution environment did not have an Android SDK, `android.jar`, or an installed Gradle distribution. The project includes a custom executable `gradlew` bootstrapper that downloads Gradle 8.9, but network DNS was unavailable here, so the download failed; native compilation and device execution could not be performed in this environment. On a machine with Android Studio/SDK 35 and network access, run the following from the repository root:

```bash
./gradlew --no-daemon :app:assembleDebug :app:lintDebug :app:testDebugUnitTest
```

Alternatively open the repository root in Android Studio and sync/build the `app` module.

Debug APK output, if the build succeeds, is `app/build/outputs/apk/debug/app-debug.apk`. The debug package ID is `app.memo.android.debug`.

## First-run setup

1. Install/open Memo and authenticate with the device's secure screen lock.
2. Open **More → Device AI inspection**. Scan the device. If no compatible model is found, either import a `.litertlm` model with the single-file picker or use **Local AI** to download one of the documented community choices. Test the model before relying on it.
3. Use **More → Enable floating Memo assistant** if you need the menu over other apps. Android will ask separately for Accessibility and display-over-other-apps permissions. These are powerful permissions; grant them only if you trust the build.
4. Open **Browse** to visit a site, sign in through its normal login flow where supported, inspect/save the page and turn sources into records or drafts.
5. Open **Apps** to choose a native app, then **Watch + control** / **Open + assist** to enable visible UI support. App UI availability is subject to Android Accessibility and the target app's own window implementation.

## Main source map

```text
app/src/main/java/com/synthos/runtime/
  MainActivity.java                   Native shell, navigation, browser and user flows
  ai/JobCompiler.java                 Evidence-bounded local prompt assembly
  ai/LocalModelRuntime.kt             On-device LiteRT-LM inference adapter
  ai/PlanProposalParser.java          Model response parsing and validation
  ai/SkillRegistry.java               Versioned task instruction bundles
  data/SynthStore.java                Encrypted local vault and migrations
  data/DeviceAiScanner.java           Installed-app/model inventory and format matching
  data/CaptureRecord.java             Provenance-aware saved sources
  data/MemoRecord.java                Contacts, companies, opportunities, projects and drafts
  engine/AutomationAccessibilityService.java  Explicit cross-app controls and run engine
  engine/WorkflowPolicy.java          Workflow constraints and validation
  remote/RemoteRunnerClient.java      Optional HTTPS guest-runner client
  ui/DesignSystem.java                Shared native design tokens and motion
```

See [ARCHITECTURE.md](ARCHITECTURE.md) for the data model, runtime boundaries, and validation status.
