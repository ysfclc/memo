#!/usr/bin/env python3
"""Offline structural checks for the Memo Android source package.

This script is intentionally not presented as an Android build/test. CI must still
run Gradle unit tests, lint, and APK assembly, then exercise a real device.
"""
from __future__ import annotations

import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "settings.gradle",
    "build.gradle",
    "app/build.gradle",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/app/memo/android/MainActivity.kt",
    "app/src/main/java/app/memo/android/ui/MemoLocalization.kt",
    "app/src/main/java/app/memo/android/notifications/MemoNotificationCenter.kt",
    "app/src/main/res/drawable/ic_notification.xml",
    "app/src/main/java/app/memo/android/ui/WorkspaceScreens.kt",
    "app/src/main/java/app/memo/android/ui/SynthOsApp.kt",
    "app/src/main/java/com/synthos/runtime/engine/AutomationAccessibilityService.java",
    "remote-runner/server.py",
    "remote-runner/tests/test_runner.py",
    ".github/workflows/build-apk.yml",
    "FEATURE_AUDIT.md",
    "PRODUCT_GAP_REGISTRY.md",
    "DEVICE_ACCEPTANCE_CHECKLIST.md",
    "CHANGELOG.md",
    "README.md",
    "app/src/test/java/app/memo/android/ui/MemoLocalizationTest.kt",
]

def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)

for rel in REQUIRED:
    if not (ROOT / rel).is_file():
        fail(f"required file is missing: {rel}")
print(f"PASS: {len(REQUIRED)} required integration files exist")

xml_files = sorted((ROOT / "app/src/main").rglob("*.xml"))
for file in xml_files:
    try:
        ET.parse(file)
    except ET.ParseError as exc:
        fail(f"invalid XML in {file.relative_to(ROOT)}: {exc}")
print(f"PASS: {len(xml_files)} Android XML files parse")

manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text()
for permission in (
    "android.permission.RECORD_AUDIO",
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.RECEIVE_BOOT_COMPLETED",
):
    if permission not in manifest:
        fail(f"manifest permission not declared: {permission}")
for receiver in (
    "app.memo.android.notifications.MemoDailyNudgeReceiver",
    "app.memo.android.notifications.MemoReminderBootReceiver",
):
    if receiver not in manifest:
        fail(f"notification receiver missing from manifest: {receiver}")
print("PASS: microphone/notification/boot permissions and notification receivers are declared")
notifications = (ROOT / "app/src/main/java/app/memo/android/notifications/MemoNotificationCenter.kt").read_text()
for marker in ("setAndAllowWhileIdle", "cancelNudge", "VISIBILITY_PRIVATE", "getBoolean(WORKFLOW_NOTIFICATIONS_ENABLED, false)", "R.drawable.ic_notification"):
    if marker not in notifications:
        fail(f"notification center missing safety/behavior marker: {marker}")
print("PASS: local reminder scheduling/cancellation, monochrome notification icon, private lock-screen visibility, and opt-in workflow alerts are present")

localization = (ROOT / "app/src/main/java/app/memo/android/ui/MemoLocalization.kt").read_text()
for marker in ('"EN" to "English"', '"PL" to "Polski"', '"TR" to "Türkçe"', '"Notifications & reminders"', '"Voice input"'):
    if marker not in localization:
        fail(f"language catalog missing marker: {marker}")
localization_test = ROOT / "app/src/test/java/app/memo/android/ui/MemoLocalizationTest.kt"
if not localization_test.exists():
    fail("MemoLocalization JVM unit test file missing")
print("PASS: English, Polish, Turkish and voice/notification translations are represented")

# Estimate coverage of the static string literals passed to the custom UI Text wrapper.
# URLs and empty placeholders are intentionally not translations. Dynamic/interpolated
# and string-valued labels are outside this conservative static scan.
ui_dir = ROOT / "app/src/main/java/app/memo/android/ui"
localization_sources = (ui_dir / "MemoLocalization.kt").read_text()
translation_keys = set(re.findall(r'^\s*"((?:[^"\\]|\\.)*)"\s+to\s+\(', localization_sources, re.M))
scanned = []
for ui_file in ("SynthOsApp.kt", "WorkspaceScreens.kt", "AppsWorkspaceScreen.kt", "BrowserWorkflowScreen.kt", "AiScreens.kt"):
    source = (ui_dir / ui_file).read_text()
    scanned.extend(re.findall(r'\bText\(\s*"((?:[^"\\]|\\.)*)"', source))
translatable = [value for value in scanned if len(value.strip()) > 1 and "$" not in value and "\\n" not in value and not value.startswith(("https://", "http://"))]
missing = sorted(set(value for value in translatable if value not in translation_keys))
if missing:
    fail("static UI strings are missing Polish/Turkish catalog entries: " + " | ".join(missing[:30]))
print(f"PASS: {len(translatable)}/{len(translatable)} static UI Text literals requiring translation are present in the catalog ({len(scanned)} literals scanned; URLs/placeholders excluded)")

workflow = (ROOT / ".github/workflows/build-apk.yml").read_text()
for archive in ("Memo-Android-Repository.zip", "Memo-Android-source.zip", "Memo-Android-Download-Fresh.zip"):
    if archive not in workflow:
        fail(f"GitHub workflow does not recognize {archive}")
for task in (":app:testDebugUnitTest", ":app:lintDebug", ":app:assembleDebug"):
    if task not in workflow:
        fail(f"GitHub workflow missing Android gate: {task}")
print("PASS: CI recognizes all documented source ZIP names and runs Android unit tests/lint/APK assembly")

runner_tests = list((ROOT / "remote-runner/tests").glob("test_*.py"))
if not runner_tests:
    fail("no remote runner tests found")
print(f"PASS: remote runner test suite is present ({len(runner_tests)} test module(s)); run it separately with unittest")
print("NOTE: This script does not compile Kotlin, run Gradle, prove Android runtime behavior, or verify a device.")
