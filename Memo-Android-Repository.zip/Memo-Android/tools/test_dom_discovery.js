#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const sourcePath = 'app/src/main/java/app/memo/android/browser/BrowserScripts.kt';
const source = fs.readFileSync(sourcePath, 'utf8');
const marker = 'val inspectInteractiveDom: String = """';
const startAt = source.indexOf(marker);
assert.notEqual(startAt, -1, 'DOM discovery script must exist');
const start = startAt + marker.length;
const end = source.indexOf('""".trimIndent()', start);
assert.notEqual(end, -1, 'DOM discovery script must have a bounded Kotlin string');
const script = source.slice(start, end);

const sandbox = {};
const makeElement = (tag, attrs = {}) => ({
  nodeType: 1,
  tagName: tag.toUpperCase(),
  id: attrs.id || '',
  labels: [],
  innerText: attrs.label || '',
  textContent: attrs.label || '',
  required: false,
  readOnly: false,
  isContentEditable: false,
  disabled: false,
  parentElement: null,
  getBoundingClientRect: () => ({ width: 100, height: 24 }),
  getRootNode: () => sandbox.document,
  getAttribute: (name) => attrs[name] ?? null,
  querySelectorAll: (selector) => (attrs.children && attrs.children[selector]) || [],
  // Accessing entered data is a test failure: the inventory must never read it.
  get value() { throw new Error('DOM inventory must not read field values'); }
});
const safeInput = makeElement('input', { type: 'text', name: 'query', placeholder: 'Search jobs', label: 'Search jobs' });
const passwordInput = makeElement('input', { type: 'password', name: 'password', label: 'Password' });
const hiddenInput = makeElement('input', { type: 'hidden', name: 'csrf', label: 'Token' });
const secretHintInput = makeElement('input', { type: 'text', autocomplete: 'one-time-code', name: 'otp_code', label: 'Verification code' });
const button = makeElement('button', { 'data-testid': 'search-submit', label: 'Search' });
const heading = makeElement('h1', { label: 'Available jobs' });
const mainLandmark = makeElement('main', { role: 'main', 'aria-label': 'Results' });
const form = makeElement('form', {
  'aria-label': 'Job search',
  method: 'GET',
  action: '/search',
  children: {
    'input,textarea,select': [safeInput, passwordInput, hiddenInput, secretHintInput],
    'button,[type="submit"],[role="button"]': [button]
  }
});
const tableHeader = makeElement('th', { label: 'Company' });
const tableRow = makeElement('tr', { label: 'row' });
const table = makeElement('table', {
  'aria-label': 'Job results',
  children: {
    'tr': [tableRow],
    'th,[role="columnheader"]': [tableHeader]
  }
});
const controls = [safeInput, passwordInput, hiddenInput, secretHintInput, button];
const allNodes = [...controls, heading, mainLandmark, form, table];
sandbox.document = {
  title: 'Jobs fixture',
  readyState: 'complete',
  documentElement: { scrollHeight: 1800 },
  querySelectorAll: (selector) => {
    if (selector === '*') return allNodes;
    if (selector.startsWith('input,textarea')) return controls;
    if (selector === 'h1,h2,h3,h4') return [heading];
    if (selector.startsWith('header,nav,main,aside,footer')) return [mainLandmark];
    if (selector === 'form') return [form];
    if (selector.startsWith('table,')) return [table];
    return [];
  }
};
sandbox.location = {
  hostname: 'jobs.example.com',
  origin: 'https://jobs.example.com',
  pathname: '/search',
  href: 'https://jobs.example.com/search'
};
sandbox.getComputedStyle = () => ({ display: 'block', visibility: 'visible', opacity: '1' });
sandbox.CSS = { escape: (value) => String(value) };
const raw = vm.runInNewContext(script, sandbox, { timeout: 1000 });
const result = JSON.parse(raw);
assert.equal(result.ok, true);
assert.equal(result.metadata.readOnly, true);
assert.equal(result.metadata.fieldValuesCollected, false);
assert.equal(result.metadata.actionsPerformed, false);
assert.equal(result.metadata.schemaVersion, 2);
assert.equal(result.metadata.controls.length, 2, 'only the safe input and button should remain');
assert.ok(result.metadata.controls.every((control) => !/password|csrf|otp|verification code/i.test(JSON.stringify(control))));
assert.ok(result.metadata.controls[0].locatorCandidates.some((candidate) => candidate.strategy === 'name'));
assert.deepEqual(Array.from(result.metadata.headings), ['Available jobs']);
assert.ok(result.metadata.landmarks.some((item) => item.role === 'main'));
assert.equal(result.metadata.forms.length, 1);
assert.equal(result.metadata.forms[0].safeFieldCount, 1, 'secret fields must not be exposed in form summaries');
assert.equal(result.metadata.groups.length, 1);
assert.deepEqual(Array.from(result.metadata.groups[0].headers), ['Company']);
assert.equal(result.metadata.readiness.stableHint, true);
assert.equal(result.metadata.readiness.requiresRecheck, false);
assert.match(result.metadata.pageFingerprint, /^[0-9a-f]{8}$/);
const secondResult = JSON.parse(vm.runInNewContext(script, sandbox, { timeout: 1000 }));
assert.equal(secondResult.metadata.pageFingerprint, result.metadata.pageFingerprint, 'same page shape should yield a stable fingerprint');
console.log('PASS: DOM map captures structure/readiness/fingerprint while excluding secrets, reading no field values, and performing no actions.');
