#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const sourcePath = 'app/src/main/java/app/memo/android/browser/BrowserScripts.kt';
const source = fs.readFileSync(sourcePath, 'utf8');
const marker = 'val inspectInteractiveDom: String = """';
const startAt = source.indexOf(marker);
assert.notEqual(startAt, -1, 'DOM discovery script must exist');
const start = startAt + marker.length;
const end = source.indexOf('""".trimIndent()', start);
assert.notEqual(end, -1, 'DOM discovery script must have a bounded Kotlin string');
const script = source.slice(start, end);

const sandbox = {};
const makeElement = (tag, attrs = {}) => ({
  nodeType: 1,
  tagName: tag.toUpperCase(),
  id: attrs.id || '',
  labels: [],
  innerText: attrs.label || '',
  textContent: attrs.label || '',
  required: false,
  readOnly: false,
  isContentEditable: false,
  disabled: false,
  parentElement: null,
  getBoundingClientRect: () => ({ width: 100, height: 24 }),
  getRootNode: () => sandbox.document,
  getAttribute: (name) => attrs[name] ?? null,
  // Accessing entered data is a test failure: the inventory must never read it.
  get value() { throw new Error('DOM inventory must not read field values'); }
});
const safeInput = makeElement('input', { type: 'text', name: 'query', placeholder: 'Search jobs', label: 'Search jobs' });
const passwordInput = makeElement('input', { type: 'password', name: 'password', label: 'Password' });
const hiddenInput = makeElement('input', { type: 'hidden', name: 'csrf', label: 'Token' });
const secretHintInput = makeElement('input', { type: 'text', autocomplete: 'one-time-code', name: 'otp_code', label: 'Verification code' });
const button = makeElement('button', { 'data-testid': 'search-submit', label: 'Search' });
const controls = [safeInput, passwordInput, hiddenInput, secretHintInput, button];
sandbox.document = {
  title: 'Jobs fixture',
  querySelectorAll: (selector) => selector === '*'
    ? controls
    : selector.startsWith('input,textarea') ? controls : []
};
sandbox.location = {
  hostname: 'jobs.example.com',
  origin: 'https://jobs.example.com',
  pathname: '/search',
  href: 'https://jobs.example.com/search'
};
sandbox.getComputedStyle = () => ({ display: 'block', visibility: 'visible', opacity: '1' });
sandbox.CSS = { escape: (value) => String(value) };
const raw = vm.runInNewContext(script, sandbox, { timeout: 1000 });
const result = JSON.parse(raw);
assert.equal(result.ok, true);
assert.equal(result.metadata.readOnly, true);
assert.equal(result.metadata.fieldValuesCollected, false);
assert.equal(result.metadata.actionsPerformed, false);
assert.equal(result.metadata.controls.length, 2, 'only the safe input and button should remain');
assert.ok(result.metadata.controls.every((control) => !/password|csrf|otp|verification code/i.test(JSON.stringify(control))));
assert.ok(result.metadata.controls[0].locatorCandidates.some((candidate) => candidate.strategy === 'name'));
console.log('PASS: DOM inventory excludes password/hidden/OTP controls, never reads values, and performs no actions.');
