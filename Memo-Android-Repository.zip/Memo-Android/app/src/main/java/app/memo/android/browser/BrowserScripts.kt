package app.memo.android.browser

import org.json.JSONObject

/** Scripts return JSON strings. They execute only inside the active WebView; no JavaScript bridge is exposed. */
object BrowserScripts {
    val capturePage: String = """
        (function(){
          const clean = s => (s || '').replace(/\u00a0/g, ' ').replace(/[\t ]+/g, ' ').trim();
          const visible = el => { const r = el.getBoundingClientRect(); const st = getComputedStyle(el); return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none'; };
          const body = document.body;
          const text = clean(body ? body.innerText : '').slice(0, 15000);
          const headings = Array.from(document.querySelectorAll('h1,h2,h3')).filter(visible).slice(0,80).map(e => clean(e.innerText)).filter(Boolean);
          const links = Array.from(document.querySelectorAll('a[href]')).filter(visible).slice(0,200).map(a => ({label:clean(a.innerText || a.getAttribute('aria-label') || a.title).slice(0,240),url:a.href})).filter(a => a.url && /^https?:/i.test(a.url));
          return JSON.stringify({ok:true,kind:'Web page',title:document.title || location.hostname,url:location.href,content:text,summary:headings.slice(0,12).join(' · ') || text.slice(0,360),metadata:{headings:headings,links:links,scrollY:window.scrollY,scrollHeight:document.documentElement ? document.documentElement.scrollHeight : 0,capturedAt:Date.now()}});
        })();
    """.trimIndent()

    /**
     * Read-only DOM inventory for capability discovery. Does not collect entered values,
     * never includes password/secret controls, and never clicks or submits anything.
     * Locators are evidence-backed candidates, not a reusable/approved recipe yet.
     */
    val inspectInteractiveDom: String = """
        (function(){
          const norm = s => (s || '').replace(/\u00a0/g,' ').replace(/[\t ]+/g,' ').trim().slice(0,240);
          const visible = el => { try { const r=el.getBoundingClientRect(), st=getComputedStyle(el); return r.width>0 && r.height>0 && st.display!=='none' && st.visibility!=='hidden' && st.opacity!=='0'; } catch (_) { return false; } };
          const sensitive = el => { const type=(el.getAttribute('type')||'').toLowerCase(); const hint=[el.getAttribute('autocomplete'),el.getAttribute('name'),el.getAttribute('id'),el.getAttribute('aria-label'),el.getAttribute('placeholder')].join(' ').toLowerCase(); return ['password','hidden'].includes(type) || /password|passwd|secret|token|credit.?card|card.?number|cvv|cvc|one.?time.?code|otp|security.?code/.test(hint); };
          const roots=[]; const seenRoots=new Set();
          const walk=root=>{ if(!root || seenRoots.has(root) || roots.length>=33) return; seenRoots.add(root); roots.push(root); let nodes=[]; try{nodes=Array.from(root.querySelectorAll('*')).slice(0,3000);}catch(_){} for(const n of nodes){ if(n.shadowRoot) walk(n.shadowRoot); } };
          walk(document);
          const controls=[]; const selectorsSeen=new Map();
          const cssPath = el => { const parts=[]; let n=el; while(n && n.nodeType===1 && parts.length<5){ let part=n.tagName.toLowerCase(); if(n.id && /^[A-Za-z][\w:.-]{0,80}$/.test(n.id)){part+='#'+CSS.escape(n.id);parts.unshift(part);break;} const test=n.getAttribute('data-testid'); if(test){part+='[data-testid="'+CSS.escape(String(test))+'"]';parts.unshift(part);break;} const parent=n.parentElement || (n.getRootNode && n.getRootNode().host); if(parent){ const siblings=Array.from(parent.children||[]).filter(x=>x.tagName===n.tagName); if(siblings.length>1)part+=':nth-of-type('+(siblings.indexOf(n)+1)+')'; } parts.unshift(part); n=parent; } return parts.join(' > ').slice(0,300); };
          const labelFor = el => { let label=''; try{ if(el.labels && el.labels.length) label=Array.from(el.labels).map(x=>x.innerText).join(' '); }catch(_){} return norm(label || el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('placeholder') || el.innerText || el.textContent); };
          for(const root of roots){ let nodes=[]; try{nodes=Array.from(root.querySelectorAll('input,textarea,select,button,[role="button"],[role="textbox"],[role="combobox"],[role="checkbox"],[role="radio"],[role="switch"],[role="link"],[contenteditable="true"],[tabindex]:not([tabindex="-1"])'));}catch(_){} for(const el of nodes){ if(controls.length>=24)break; if(!visible(el)||sensitive(el)||el.disabled || el.getAttribute('aria-disabled')==='true')continue; const tag=el.tagName.toLowerCase(), type=(el.getAttribute('type')||'').toLowerCase(); const label=labelFor(el); const role=el.getAttribute('role') || (tag==='a'?'link':tag==='button'?'button':tag==='textarea'?'textbox':tag==='select'?'combobox':tag==='input'&&['checkbox','radio'].includes(type)?type:tag==='input'?'textbox':''); if(!label && !el.id && !el.getAttribute('name') && !el.getAttribute('data-testid'))continue;
              const locators=[]; const add=(strategy,value,confidence)=>{if(value && !locators.some(x=>x.strategy===strategy&&x.value===value)){ const key=strategy+'|'+value; const count=selectorsSeen.get(key)||0; selectorsSeen.set(key,count+1); locators.push({strategy,value,confidence:count===0?confidence:Math.min(confidence,0.35)});}};
              add('test-id',el.getAttribute('data-testid'),0.99); add('id',el.id,0.94); add('name',el.getAttribute('name'),0.90); add('label',label,0.84); add('placeholder',el.getAttribute('placeholder'),0.78); add('css',cssPath(el),0.60);
              const opts=tag==='select'?Array.from(el.options||[]).slice(0,60).map(o=>({label:norm(o.label||o.text),disabled:!!o.disabled})):[];
              controls.push({index:controls.length,tag:tag,role:role,type:type||null,label:label,required:!!el.required,readOnly:!!el.readOnly,contentEditable:el.isContentEditable===true,locatorCandidates:locators,options:opts,shadowRoot:root!==document});
            } }
          const title=norm(document.title||location.hostname);
          const collectVisible=(selector,map,limit)=>{const out=[],seen=new Set();for(const root of roots){let els=[];try{els=Array.from(root.querySelectorAll(selector));}catch(_){}for(const el of els){if(out.length>=limit)break;if(!visible(el)||seen.has(el))continue;seen.add(el);try{const value=map(el,out.length);if(value!==null&&value!==undefined)out.push(value);}catch(_){}}if(out.length>=limit)break;}return out;};
          const headings=collectVisible('h1,h2,h3,h4',el=>norm(el.innerText||el.textContent).slice(0,160),32).filter(Boolean);
          const landmarks=collectVisible('header,nav,main,aside,footer,[role="banner"],[role="navigation"],[role="main"],[role="complementary"],[role="contentinfo"],[role="search"],[role="region"]',el=>({tag:el.tagName.toLowerCase(),role:norm(el.getAttribute('role')||''),label:norm(el.getAttribute('aria-label')||el.getAttribute('title')||'').slice(0,120)}),20);
          const forms=collectVisible('form',el=>{let actionOrigin='',actionPath='';try{const u=new URL(el.getAttribute('action')||location.href,location.href);actionOrigin=u.origin;actionPath=u.pathname.slice(0,240);}catch(_){}let fs=[];try{fs=Array.from(el.querySelectorAll('input,textarea,select')).filter(x=>!sensitive(x));}catch(_){}let submits=[];try{submits=Array.from(el.querySelectorAll('button,[type="submit"],[role="button"]')).filter(x=>visible(x)&&!sensitive(x));}catch(_){}return {label:norm(el.getAttribute('aria-label')||el.getAttribute('name')||''),method:(el.getAttribute('method')||'GET').toUpperCase(),actionOrigin:actionOrigin,actionPath:actionPath,safeFieldCount:fs.length,requiredFieldCount:fs.filter(x=>!!x.required).length,submitControlCount:submits.length};},12);
          const groups=collectVisible('table,[role="table"],[role="grid"],ul,ol,[role="list"],[role="listbox"],[role="tree"]',el=>{const tag=el.tagName.toLowerCase(),role=norm(el.getAttribute('role')||'');let count=0,headers=[];try{count=tag==='table'?el.querySelectorAll('tr').length:el.querySelectorAll('li,[role="listitem"],[role="row"],option').length;}catch(_){}try{headers=Array.from(el.querySelectorAll('th,[role="columnheader"]')).slice(0,12).map(x=>norm(x.innerText||x.textContent).slice(0,100)).filter(Boolean);}catch(_){}return {tag:tag,role:role,label:norm(el.getAttribute('aria-label')||el.getAttribute('title')||'').slice(0,120),itemCount:Math.min(count,10000),headers:headers};},20);
          const busyIndicators=collectVisible('[aria-busy="true"],[role="progressbar"],progress',el=>el.tagName.toLowerCase(),20).length;
          const readyState=(document.readyState||'unknown');
          const pageShape=[location.origin,location.pathname,title,headings.join('|'),landmarks.map(x=>x.tag+':'+x.role+':'+x.label).join('|'),controls.map(x=>x.role+':'+x.tag+':'+x.label+':'+((x.locatorCandidates[0]||{}).strategy||'')).join('|'),forms.map(x=>x.method+':'+x.safeFieldCount+':'+x.submitControlCount).join('|'),groups.map(x=>x.tag+':'+x.role+':'+x.itemCount).join('|')].join('¦');
          let hash=2166136261;for(let i=0;i<pageShape.length;i++){hash^=pageShape.charCodeAt(i);hash=Math.imul(hash,16777619);}const fingerprint=('00000000'+(hash>>>0).toString(16)).slice(-8);
          const stableHint=readyState==='complete'&&busyIndicators===0;
          const payload={ok:true,kind:'Interactive DOM inventory',title:'Page structure · '+title,url:location.href,summary:controls.length+' controls, '+headings.length+' headings, '+forms.length+' forms and '+groups.length+' list/table groups mapped; no values read and no actions performed.',content:('PAGE '+title+'\\nHEADINGS '+headings.slice(0,12).join(' · ')+'\\nLANDMARKS '+landmarks.map(x=>(x.role||x.tag)+(x.label?' '+x.label:'')).slice(0,12).join(' · ')+'\\nFORMS '+forms.map(x=>x.method+' '+x.safeFieldCount+' safe fields / '+x.submitControlCount+' submit controls').join(' · ')+'\\nGROUPS '+groups.map(x=>x.tag+' '+x.itemCount+' items '+(x.headers.length?'['+x.headers.join(', ')+']':'')).join(' · ')+'\\nCONTROLS '+controls.map(c=>{const best=c.locatorCandidates[0]||{};return '#'+c.index+' '+c.role+' '+c.tag+(c.type?' type='+c.type:'')+' · '+(c.label||'(unlabelled)')+' · '+(best.strategy||'no locator')+': '+(best.value||'')}).join('\\n')).slice(0,18000),metadata:{schemaVersion:2,origin:location.origin,path:location.pathname,title:title,pageFingerprint:fingerprint,controlCount:controls.length,headingCount:headings.length,landmarkCount:landmarks.length,formCount:forms.length,groupCount:groups.length,headings:headings,landmarks:landmarks,forms:forms,groups:groups,readiness:{documentReadyState:readyState,busyIndicatorCount:busyIndicators,stableHint:stableHint,requiresRecheck:!stableHint},observationBounds:{maxControls:24,maxHeadings:32,maxLandmarks:20,maxForms:12,maxGroups:20,shadowRootsObserved:Math.max(0,roots.length-1)},controls:controls,observedAt:Date.now(),readOnly:true,fieldValuesCollected:false,actionsPerformed:false}};
          return JSON.stringify(payload);
        })();
    """.trimIndent()

    val extractLinks: String = """
        (function(){
          const visible = el => { const r = el.getBoundingClientRect(); const st = getComputedStyle(el); return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none'; };
          const links = Array.from(document.querySelectorAll('a[href]')).filter(visible).map(a => ({label:(a.innerText || a.getAttribute('aria-label') || a.title || '').replace(/\s+/g,' ').trim().slice(0,240),url:a.href})).filter(a => a.url && /^https?:/i.test(a.url)).filter((a,i,arr) => arr.findIndex(x => x.url === a.url) === i).slice(0,300);
          return JSON.stringify({ok:true,kind:'Link collection',title:'Links · ' + (document.title || location.hostname),url:location.href,content:links.map((x,i)=>(i+1)+'. '+(x.label || '(no label)')+'\n'+x.url).join('\n\n') || 'No visible links found.',summary:links.length+' unique visible links collected.',metadata:{count:links.length,links:links}});
        })();
    """.trimIndent()

    fun findText(query: String): String {
        val q = JSONObject.quote(query.trim())
        return """
          (function(){
            const q = $q;
            const text = (document.body ? document.body.innerText : '').replace(/\u00a0/g,' ');
            const lower = text.toLocaleLowerCase(); const needle = q.toLocaleLowerCase(); const matches=[]; let from=0; let index;
            while(needle && (index=lower.indexOf(needle, from))>=0 && matches.length<30){ matches.push(text.slice(Math.max(0,index-240),Math.min(text.length,index+q.length+320)).replace(/\n{3,}/g,'\n\n').trim()); from=index+Math.max(needle.length,1); }
            return JSON.stringify({ok:true,kind:'Text search',title:'Matches · '+(document.title || location.hostname),url:location.href,content:matches.length ? matches.map((m,i)=>(i+1)+'. '+m).join('\n\n---\n\n') : 'No matching text found in the current page.',summary:matches.length+' match(es) for “'+q+'”.',metadata:{query:q,count:matches.length}});
          })();
        """.trimIndent()
    }

    fun preparePrompt(prompt: String): String {
        val quoted = JSONObject.quote(prompt)
        return """
          (function(){
            const prompt = $quoted;
            const visible = el => { const r = el.getBoundingClientRect(); const st = getComputedStyle(el); return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none' && !el.disabled; };
            const candidates = Array.from(document.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]')).filter(visible);
            if(!candidates.length) return JSON.stringify({ok:false,kind:'Prompt preparation',title:'Prompt not prepared',url:location.href,content:'No visible text composer was found. Open a conversation and try again.',summary:'Composer not found.',metadata:{}});
            const el = candidates[candidates.length-1]; el.focus();
            if(el.isContentEditable || el.getAttribute('contenteditable')==='true') { el.textContent=prompt; }
            else { const proto = Object.getPrototypeOf(el); const setter = Object.getOwnPropertyDescriptor(proto,'value') && Object.getOwnPropertyDescriptor(proto,'value').set; if(setter) setter.call(el,prompt); else el.value=prompt; }
            el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:prompt})); el.dispatchEvent(new Event('change',{bubbles:true}));
            return JSON.stringify({ok:true,kind:'Prompt preparation',title:'Prompt prepared · '+(document.title || location.hostname),url:location.href,content:'Prompt filled into the visible composer. It has not been sent. Review it on the page before using Send prepared prompt.',summary:'Prompt filled; not sent.',metadata:{composer:el.tagName,role:el.getAttribute('role')||'',length:prompt.length}});
          })();
        """.trimIndent()
    }

    fun sendPreparedPrompt(prompt: String): String {
        val quoted = JSONObject.quote(prompt)
        return """
          (function(){
            const prompt = $quoted;
            const normalize = s => (s || '').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
            const visible = el => { const r=el.getBoundingClientRect(); const st=getComputedStyle(el); return r.width>0 && r.height>0 && st.visibility!=='hidden' && st.display!=='none' && !el.disabled; };
            const editors=Array.from(document.querySelectorAll('textarea,input,[contenteditable="true"],[role="textbox"]')).filter(visible);
            const editor=editors[editors.length-1];
            if(!editor) return JSON.stringify({ok:false,clicked:false,kind:'Prompt submission',title:'Cannot send prompt',url:location.href,content:'No visible composer was found. The prompt was not sent.',summary:'Composer not found.',metadata:{}});
            const value = () => normalize(editor.isContentEditable || editor.getAttribute('contenteditable')==='true' ? (editor.innerText || editor.textContent) : editor.value);
            const wanted=normalize(prompt);
            if(!wanted || !value().includes(wanted)) return JSON.stringify({ok:false,clicked:false,kind:'Prompt submission',title:'Composer changed',url:location.href,content:'The visible composer no longer contains the prepared prompt. Nothing was sent. Review the page and prepare the prompt again.',summary:'Prepared text no longer matches composer.',metadata:{}});
            const bodyText = () => {
              const clone=document.body ? document.body.cloneNode(true) : null;
              if(!clone) return '';
              clone.querySelectorAll('textarea,input,[contenteditable="true"],[role="textbox"],button,nav').forEach(el=>el.remove());
              return normalize(clone.innerText || clone.textContent);
            };
            const assistantTexts = () => {
              const host=(location.hostname||'').toLowerCase().replace(/^www\./,'');
              let selectors=['[data-message-author-role="assistant"]','[data-testid*="assistant-message"]','[data-testid*="model-response"]','[data-testid*="answer-content"]','[class*="assistant-message"]','[class*="model-response"]','[class*="answer-content"]','.model-response-text','.ds-markdown','.font-claude-message','main [class*="prose"]'];
              if(host==='gemini.google.com') selectors=['model-response','message-content','.model-response-text','[data-message-type="model-response"]',...selectors];
              if(host==='perplexity.ai') selectors=['[data-testid*="answer"]','main .prose','main [class*="prose"]',...selectors];
              if(host==='deepseek.com'||host==='chat.deepseek.com') selectors=['.ds-markdown','[class*="markdown"]',...selectors];
              for(const selector of selectors){
                const nodes=Array.from(document.querySelectorAll(selector)).filter(el=>{const r=el.getBoundingClientRect();const st=getComputedStyle(el);return r.width>0&&r.height>0&&st.visibility!=='hidden'&&st.display!=='none';});
                const values=[]; for(const node of nodes){const text=normalize(node.innerText||node.textContent);if(text.length>20&&!values.includes(text)&&!values.some(value=>value.length>text.length&&value.includes(text)))values.push(text);}
                if(values.length) return values.slice(-30);
              }
              return [];
            };
            const prefix=wanted.slice(0,Math.min(160,wanted.length));
            const occurrences=(text,needle)=>{ if(!needle) return 0; let count=0,from=0,at; while((at=text.toLocaleLowerCase().indexOf(needle.toLocaleLowerCase(),from))>=0){count++;from=at+needle.length;} return count; };
            const beforeText=bodyText();
            const countNode=document.querySelectorAll('[data-message-author-role="user"]').length;
            const beforeAssistant=assistantTexts();
            window.__synthosSubmitState={prompt:prompt,prefix:prefix,beforeOccurrences:occurrences(beforeText,prefix),beforeUserMessages:countNode,beforeAssistantCount:beforeAssistant.length,beforeAssistantLatest:beforeAssistant[beforeAssistant.length-1]||'',lastReplyText:'',stablePolls:0,at:Date.now()};
            const candidates=Array.from((editor.closest('form') || document).querySelectorAll('button,[role="button"]')).filter(visible);
            const send=candidates.find(b=>/\bsend\b/i.test((b.getAttribute('aria-label')||'')+' '+(b.getAttribute('title')||'')+' '+(b.getAttribute('data-testid')||''))) || candidates.find(b=>/^send$/i.test(normalize(b.innerText)));
            if(!send){ return JSON.stringify({ok:false,clicked:false,kind:'Prompt submission',title:'Send control not found',url:location.href,content:'No recognizable send button was found in the composer. Memo did not press Enter or send anything; submit the reviewed prompt manually, then continue the workflow.',summary:'No safe send control found.',metadata:{composer:editor.tagName}}); }
            send.click();
            return JSON.stringify({ok:true,clicked:true,kind:'Prompt submission',title:'Submission requested',url:location.href,content:'The recognized send control was clicked. Memo will verify that the prompt appears as a new conversation message and is no longer in the composer.',summary:'Send control clicked; awaiting evidence.',metadata:{method:'button',label:(send.getAttribute('aria-label')||send.innerText||'Send').slice(0,100)}});
          })();
        """.trimIndent()
    }

    fun verifyPromptSubmission(prompt: String, preserveState: Boolean = false): String {
        val quoted = JSONObject.quote(prompt)
        val consumeState = (!preserveState).toString()
        return """
          (function(){
            const wanted=$quoted;
            const consumeState=$consumeState;
            const normalize=s=>(s||'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
            const state=window.__synthosSubmitState;
            if(!state || state.prompt!==wanted) return JSON.stringify({verified:false,contextPresent:false,composerCleared:false,reason:'Submission context was lost because the page changed. Check the conversation manually.'});
            const clone=document.body ? document.body.cloneNode(true) : null;
            if(!clone) return JSON.stringify({verified:false,contextPresent:true,composerCleared:false,reason:'The page did not expose readable conversation content. Check the result manually.'});
            clone.querySelectorAll('textarea,input,[contenteditable="true"],[role="textbox"]').forEach(el=>el.remove());
            const text=normalize(clone.innerText || clone.textContent);
            const prefix=normalize(wanted).slice(0,Math.min(160,normalize(wanted).length));
            const occurrences=(value,needle)=>{ if(!needle) return 0; let count=0,from=0,at; while((at=value.toLocaleLowerCase().indexOf(needle.toLocaleLowerCase(),from))>=0){count++;from=at+needle.length;} return count; };
            const afterOccurrences=occurrences(text,prefix);
            const userMessageCount=document.querySelectorAll('[data-message-author-role="user"]').length;
            const editors=Array.from(document.querySelectorAll('textarea,input,[contenteditable="true"],[role="textbox"]'));
            const editor=editors.reverse().find(el=>{const r=el.getBoundingClientRect();const st=getComputedStyle(el);return r.width>0&&r.height>0&&st.visibility!=='hidden'&&st.display!=='none';});
            const current=editor ? normalize(editor.isContentEditable || editor.getAttribute('contenteditable')==='true' ? (editor.innerText || editor.textContent) : editor.value) : '';
            const composerCleared=!current.toLocaleLowerCase().includes(prefix.toLocaleLowerCase());
            const newUserMessage=userMessageCount>state.beforeUserMessages;
            const newVisiblePrompt=afterOccurrences>state.beforeOccurrences;
            const verified=composerCleared && (newUserMessage || newVisiblePrompt);
            if(consumeState) delete window.__synthosSubmitState;
            return JSON.stringify({verified:verified,contextPresent:true,reason:verified?'New prompt observed in the page.':'The page did not show a new prompt with the composer cleared. It may still be sending, or the site structure may be unsupported.',composerCleared:composerCleared,newUserMessage:newUserMessage,newVisiblePrompt:newVisiblePrompt,beforeOccurrences:state.beforeOccurrences,afterOccurrences:afterOccurrences,beforeUserMessages:state.beforeUserMessages,afterUserMessages:userMessageCount});
          })();
        """.trimIndent()
    }

    /** Read the newest assistant response. The submit baseline prevents old answers being mistaken for this run. */
    val pollAssistantResponse: String = """
        (function(){
          const normalize=s=>(s||'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
          const visible=el=>{const r=el.getBoundingClientRect();const st=getComputedStyle(el);return r.width>0&&r.height>0&&st.visibility!=='hidden'&&st.display!=='none';};
          const state=window.__synthosSubmitState;
          if(!state) return JSON.stringify({status:'NEEDS_REVIEW',reason:'The browser lost the submission baseline. Inspect the conversation manually before retrying.'});
          const host=(location.hostname||'').toLowerCase().replace(/^www\./,'');
          let selectors=['[data-message-author-role="assistant"]','[data-testid*="assistant-message"]','[data-testid*="model-response"]','[data-testid*="answer-content"]','[class*="assistant-message"]','[class*="model-response"]','[class*="answer-content"]','.model-response-text','.ds-markdown','.font-claude-message','main [class*="prose"]'];
          if(host==='gemini.google.com') selectors=['model-response','message-content','.model-response-text','[data-message-type="model-response"]',...selectors];
          if(host==='perplexity.ai') selectors=['[data-testid*="answer"]','main .prose','main [class*="prose"]',...selectors];
          if(host==='deepseek.com'||host==='chat.deepseek.com') selectors=['.ds-markdown','[class*="markdown"]',...selectors];
          let messages=[];
          for(const selector of selectors){
            let nodes=[];try{nodes=Array.from(document.querySelectorAll(selector)).filter(visible);}catch(_){}
            const values=[];
            for(const node of nodes){
              const text=normalize(node.innerText||node.textContent);
              if(text.length<24||values.includes(text)) continue;
              if(values.some(value=>value.length>text.length&&value.includes(text))) continue;
              values.push(text);
            }
            if(values.length){messages=values.slice(-30);break;}
          }
          messages=messages.filter((value,index,array)=>array.indexOf(value)===index);
          if(!messages.length) return JSON.stringify({status:'PENDING',reason:'No readable assistant response detected yet.',assistantCount:0});
          const latest=messages[messages.length-1];
          const changed=messages.length>Number(state.beforeAssistantCount||0)||latest!==String(state.beforeAssistantLatest||'');
          const stop=Array.from(document.querySelectorAll('button,[role="button"]')).some(el=>{
            if(!visible(el)) return false;
            const label=normalize((el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')+' '+(el.getAttribute('data-testid')||''));
            return /\b(stop generating|stop response|cancel response|stop answer)\b/i.test(label);
          });
          const busy=!!document.querySelector('[aria-busy="true"],[data-is-streaming="true"]')||stop;
          if(changed&&latest===String(state.lastReplyText||'')) state.stablePolls=Number(state.stablePolls||0)+1;
          else { state.lastReplyText=latest; state.stablePolls=0; }
          const stable=Number(state.stablePolls||0)>=3;
          const done=changed&&latest.length>=24&&stable&&!busy;
          return JSON.stringify({status:done?'COMPLETED':'PENDING',response:changed?latest.slice(0,14000):'',assistantCount:messages.length,changed:changed,stablePolls:Number(state.stablePolls||0),busy:busy,reason:done?'A new assistant response was detected and stopped changing.':'Waiting for a new, stable assistant response.'});
        })();
    """.trimIndent()

    val startScrollCapture: String = """
        (function(){
          window.__synthosCaptureDone = false; window.__synthosCaptureCancelled = false; window.__synthosCaptureResult = null;
          (async function(){
            const normalize = s => (s || '').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
            const collected = new Map();
            const articleSelector = 'article,[role="article"],[data-testid*="post"],[data-testid*="feed-item"]';
            for(let pass=0; pass<6 && !window.__synthosCaptureCancelled; pass++){
              const cards=Array.from(document.querySelectorAll(articleSelector));
              for(const card of cards){
                const text=normalize(card.innerText || card.textContent).slice(0,2200);
                if(text.length>35){ const key=text.toLocaleLowerCase().slice(0,180); if(!collected.has(key)) collected.set(key,text); }
              }
              if(pass<5 && !window.__synthosCaptureCancelled){ window.scrollBy(0,Math.max(350,Math.floor(window.innerHeight*0.75))); await new Promise(resolve=>setTimeout(resolve,650)); }
            }
            window.scrollTo(0,0);
            if(window.__synthosCaptureCancelled){ window.__synthosCaptureResult=JSON.stringify({ok:false,kind:'Feed review',title:'Feed review cancelled',url:location.href,content:'The user cancelled this feed review.',summary:'Feed review cancelled.',metadata:{cancelled:true}}); window.__synthosCaptureDone=true; return; }
            const cards=Array.from(collected.values()).slice(0,60);
            const fallback=normalize(document.body ? document.body.innerText : '').slice(0,15000);
            const content=cards.length ? cards.map((x,i)=>(i+1)+'. '+x).join('\n\n---\n\n') : fallback;
            window.__synthosCaptureResult=JSON.stringify({ok:true,kind:'Feed review',title:'Feed review · '+(document.title || location.hostname),url:location.href,content:content,summary:cards.length+' distinct visible content card(s) collected after six scroll passes.'+(cards.length===0?' No article-like cards were detected, so visible page text was saved instead.':''),metadata:{cards:cards.length,passes:6,scrollHeight:document.documentElement ? document.documentElement.scrollHeight : 0,capturedAt:Date.now()}});
            window.__synthosCaptureDone=true;
          })().catch(error=>{ window.__synthosCaptureResult=JSON.stringify({ok:false,kind:'Feed review',title:'Feed review failed',url:location.href,content:String(error && error.message || error),summary:'Could not finish scrolling the page.',metadata:{}}); window.__synthosCaptureDone=true; });
          return 'started';
        })();
    """.trimIndent()

    val pollScrollCapture: String = "window.__synthosCaptureDone ? (window.__synthosCaptureResult || 'null') : 'PENDING';"

    val cancelScrollCapture: String = "window.__synthosCaptureCancelled = true; 'cancelled';"
}
