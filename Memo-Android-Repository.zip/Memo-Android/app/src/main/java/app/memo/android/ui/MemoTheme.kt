package app.memo.android.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape

/** Single design-token source. Components consume MaterialTheme rather than ad-hoc styling. */
object MemoTokens {
    object Spacing {
        val xxs = 4.dp
        val xs = 8.dp
        val sm = 12.dp
        val md = 16.dp
        val lg = 20.dp
        val xl = 24.dp
        val xxl = 32.dp
        val pageMargin = 20.dp
        val minimumTouch = 48.dp
    }

    object Radius {
        val small = 8.dp
        val medium = 12.dp
        val large = 18.dp
        val extraLarge = 24.dp
        val extraExtraLarge = 30.dp
        val pill = 100.dp
    }

    object SemanticLight {
        val success = Color(0xFF26524A)
        val onSuccess = Color(0xFFFFFFFF)
        val successContainer = Color(0xFFD7E8DE)
        val onSuccessContainer = Color(0xFF132F27)
        val warning = Color(0xFF8A4B1F)
        val onWarning = Color(0xFFFFFFFF)
        val warningContainer = Color(0xFFFFE2C7)
        val onWarningContainer = Color(0xFF3B1E08)
        val info = Color(0xFF276B56)
        val onInfo = Color(0xFFFFFFFF)
        val infoContainer = Color(0xFFB2EFCF)
        val onInfoContainer = Color(0xFF163A2C)
    }

    object SemanticDark {
        val success = Color(0xFFB2EFCF)
        val onSuccess = Color(0xFF153B2D)
        val successContainer = Color(0xFF26524A)
        val onSuccessContainer = Color(0xFFD7F5E4)
        val warning = Color(0xFFFFC28D)
        val onWarning = Color(0xFF40230C)
        val warningContainer = Color(0xFF633817)
        val onWarningContainer = Color(0xFFFFE2C7)
        val info = Color(0xFF8BDDB6)
        val onInfo = Color(0xFF123A2D)
        val infoContainer = Color(0xFF265A47)
        val onInfoContainer = Color(0xFFD6F6E3)
    }

    object Light {
        // Paper + Mint: warm paper surfaces, evergreen structure and mint action affordances.
        val primary = Color(0xFF26524A)
        val onPrimary = Color(0xFFFFFFFF)
        val primaryContainer = Color(0xFFD7E8DE)
        val onPrimaryContainer = Color(0xFF132F27)
        val secondary = Color(0xFF506257)
        val onSecondary = Color(0xFFFFFFFF)
        val secondaryContainer = Color(0xFFE1E7DE)
        val onSecondaryContainer = Color(0xFF202B23)
        val tertiary = Color(0xFF276B56)
        val onTertiary = Color(0xFFFFFFFF)
        val tertiaryContainer = Color(0xFFB2EFCF)
        val onTertiaryContainer = Color(0xFF163A2C)
        val background = Color(0xFFF4F2EC)
        val onBackground = Color(0xFF222920)
        val surface = Color(0xFFFBFAF6)
        val onSurface = Color(0xFF222920)
        val surfaceVariant = Color(0xFFE8E9E1)
        val onSurfaceVariant = Color(0xFF4A544A)
        val outline = Color(0xFF747D72)
        val outlineVariant = Color(0xFFD0D4CA)
        val error = Color(0xFFAA3E32)
        val onError = Color(0xFFFFFFFF)
        val errorContainer = Color(0xFFF9DEDC)
        val onErrorContainer = Color(0xFF410E0B)
    }

    object Dark {
        val primary = Color(0xFFB2EFCF)
        val onPrimary = Color(0xFF153B2D)
        val primaryContainer = Color(0xFF26524A)
        val onPrimaryContainer = Color(0xFFD7F5E4)
        val secondary = Color(0xFFC0CDC1)
        val onSecondary = Color(0xFF2B382F)
        val secondaryContainer = Color(0xFF3A4940)
        val onSecondaryContainer = Color(0xFFDEE8DE)
        val tertiary = Color(0xFF8BDDB6)
        val onTertiary = Color(0xFF123A2D)
        val tertiaryContainer = Color(0xFF265A47)
        val onTertiaryContainer = Color(0xFFD6F6E3)
        val background = Color(0xFF171D19)
        val onBackground = Color(0xFFE4E9E1)
        val surface = Color(0xFF202721)
        val onSurface = Color(0xFFE4E9E1)
        val surfaceVariant = Color(0xFF303A33)
        val onSurfaceVariant = Color(0xFFC4D0C4)
        val outline = Color(0xFF849286)
        val outlineVariant = Color(0xFF424E45)
        val error = Color(0xFFFFB4AB)
        val onError = Color(0xFF690005)
        val errorContainer = Color(0xFF93000A)
        val onErrorContainer = Color(0xFFFFDAD6)
    }

    fun colors(dark: Boolean): ColorScheme = if (dark) darkColorScheme(
        primary = Dark.primary, onPrimary = Dark.onPrimary, primaryContainer = Dark.primaryContainer,
        onPrimaryContainer = Dark.onPrimaryContainer, secondary = Dark.secondary, onSecondary = Dark.onSecondary,
        secondaryContainer = Dark.secondaryContainer, onSecondaryContainer = Dark.onSecondaryContainer,
        tertiary = Dark.tertiary, onTertiary = Dark.onTertiary, tertiaryContainer = Dark.tertiaryContainer,
        onTertiaryContainer = Dark.onTertiaryContainer, background = Dark.background, onBackground = Dark.onBackground,
        surface = Dark.surface, onSurface = Dark.onSurface, surfaceVariant = Dark.surfaceVariant,
        onSurfaceVariant = Dark.onSurfaceVariant, outline = Dark.outline, outlineVariant = Dark.outlineVariant,
        error = Dark.error, onError = Dark.onError, errorContainer = Dark.errorContainer,
        onErrorContainer = Dark.onErrorContainer
    ) else lightColorScheme(
        primary = Light.primary, onPrimary = Light.onPrimary, primaryContainer = Light.primaryContainer,
        onPrimaryContainer = Light.onPrimaryContainer, secondary = Light.secondary, onSecondary = Light.onSecondary,
        secondaryContainer = Light.secondaryContainer, onSecondaryContainer = Light.onSecondaryContainer,
        tertiary = Light.tertiary, onTertiary = Light.onTertiary, tertiaryContainer = Light.tertiaryContainer,
        onTertiaryContainer = Light.onTertiaryContainer, background = Light.background, onBackground = Light.onBackground,
        surface = Light.surface, onSurface = Light.onSurface, surfaceVariant = Light.surfaceVariant,
        onSurfaceVariant = Light.onSurfaceVariant, outline = Light.outline, outlineVariant = Light.outlineVariant,
        error = Light.error, onError = Light.onError, errorContainer = Light.errorContainer,
        onErrorContainer = Light.onErrorContainer
    )

    val typography = Typography(
        displayLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 38.sp),
        headlineLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 34.sp),
        headlineMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 24.sp, lineHeight = 30.sp),
        headlineSmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 21.sp, lineHeight = 27.sp),
        titleLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 24.sp),
        titleMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
        titleSmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
        bodyLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
        bodyMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
        bodySmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 17.sp),
        labelLarge = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
        labelMedium = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp),
        labelSmall = TextStyle(fontFamily = FontFamily.Default, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 15.sp)
    )

    val shapes = Shapes(
        extraSmall = RoundedCornerShape(8.dp),
        small = RoundedCornerShape(12.dp),
        medium = RoundedCornerShape(18.dp),
        large = RoundedCornerShape(24.dp),
        extraLarge = RoundedCornerShape(30.dp)
    )
}

@Composable
fun MemoTheme(themeMode: String = "SYSTEM", content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        "DARK" -> true
        "LIGHT" -> false
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = MemoTokens.colors(dark), typography = MemoTokens.typography, shapes = MemoTokens.shapes, content = content)
}
