package app.memo.android.data

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.memo.android.automation.TaskRules
import app.memo.android.runtime.RuntimeRegistry
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.withContext
import java.util.Locale

class MemoWorkspaceViewModel(application: Application) : AndroidViewModel(application) {
    private val vault = EncryptedVault(application)
    private val persistenceQueue = Channel<AppSnapshot>(Channel.CONFLATED)
    private val preferences = application.getSharedPreferences("synthos_preferences", Application.MODE_PRIVATE)
    private val runtimeRegistry = RuntimeRegistry()

    private val _snapshot = MutableStateFlow(AppSnapshot())
    val snapshot: StateFlow<AppSnapshot> = _snapshot.asStateFlow()

    private val _vaultReady = MutableStateFlow(false)
    val vaultReady: StateFlow<Boolean> = _vaultReady.asStateFlow()

    private val _vaultError = MutableStateFlow<String?>(null)
    val vaultError: StateFlow<String?> = _vaultError.asStateFlow()

    private val _themeMode = MutableStateFlow(preferences.getString("theme_mode", "SYSTEM") ?: "SYSTEM")
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _uiLanguage = MutableStateFlow(
        preferences.getString("ui_language", "EN")?.uppercase(Locale.ROOT)?.takeIf { it in setOf("EN", "PL", "TR") } ?: "EN"
    )
    val uiLanguage: StateFlow<String> = _uiLanguage.asStateFlow()


    init {
        viewModelScope.launch {
            for (candidate in persistenceQueue) {
                try {
                    withContext(Dispatchers.IO) { vault.write(candidate) }
                    _vaultError.value = null
                } catch (error: Throwable) {
                    _vaultError.value = safeError(error, "Could not save the encrypted workspace. Export your data before continuing.")
                }
            }
        }
    }
    fun unlockAndLoad() {
        if (_vaultReady.value) return
        viewModelScope.launch {
            try {
                val stored = withContext(Dispatchers.IO) { vault.read() }
                val restored = stored?.recoverInterruptedTasks() ?: AppSnapshot()
                _snapshot.value = restored
                _vaultError.value = null
                _vaultReady.value = true
                if (stored == null) {
                    log("Workspace created on this device.")
                } else if (restored != stored) {
                    persist(restored)
                }
            } catch (error: Throwable) {
                _vaultError.value = safeError(error, "The encrypted workspace could not be opened.")
                _vaultReady.value = true
            }
        }
    }

    /** Clears decrypted data from UI state when the user manually locks the workspace. */
    fun clearSensitiveMemory() {
        _snapshot.value = AppSnapshot()
        _vaultReady.value = false
        _vaultError.value = null
    }

    fun setThemeMode(mode: String) {
        val normalized = mode.uppercase(Locale.ROOT).takeIf { it in setOf("SYSTEM", "LIGHT", "DARK") } ?: "SYSTEM"
        _themeMode.value = normalized
        preferences.edit().putString("theme_mode", normalized).apply()
    }

    /** Interface language is a local device preference; it never changes user-authored content. */
    fun setUiLanguage(language: String) {
        val normalized = language.uppercase(Locale.ROOT).takeIf { it in setOf("EN", "PL", "TR") } ?: "EN"
        _uiLanguage.value = normalized
        preferences.edit().putString("ui_language", normalized).apply()
    }

    fun createConversation(title: String = "New conversation", sourceType: String = "NATIVE", sourceReference: String = ""): String {
        if (_snapshot.value.conversations.size >= 160 || _snapshot.value.entities.size >= 1_200) {
            log("Conversation or entity limit reached. Export a backup before removing older records.", "WARN")
            return ""
        }
        val conversationId = newId()
        val now = nowMillis()
        val conversation = ConversationRecord(
            id = conversationId,
            title = title.trim().take(240).ifBlank { "New conversation" },
            sourceType = sourceType.trim().uppercase(Locale.ROOT).take(40).ifBlank { "NATIVE" },
            sourceReference = sourceReference.trim().take(2_048),
            createdAt = now,
            updatedAt = now
        )
        val conversationEntity = EntityRecord(
            id = conversationId,
            type = "CONVERSATION",
            title = conversation.title,
            description = when (sourceType.uppercase(Locale.ROOT)) {
                "IMPORTED" -> "Imported conversation. Source access was user-mediated."
                "BROWSER_WORKFLOW" -> "Frontier browser workflow conversation. Provider exchanges are retained with source URLs and evidence."
                else -> "Native Memo conversation."
            },
            properties = mapOf("sourceType" to conversation.sourceType, "sourceReference" to conversation.sourceReference),
            sourceConversationId = conversationId,
            createdAt = now,
            updatedAt = now
        )
        updateSnapshot { current ->
            current.copy(
                conversations = listOf(conversation) + current.conversations,
                entities = (listOf(conversationEntity) + current.entities.filterNot { it.id == conversationId }).take(1_200)
            ).withActivity(if (sourceType.equals("IMPORTED", ignoreCase = true)) "Conversation imported: ${conversation.title}" else if (sourceType.equals("BROWSER_WORKFLOW", ignoreCase = true)) "Browser workflow conversation created: ${conversation.title}" else "Conversation created: ${conversation.title}")
        }
        return conversationId
    }

    fun importConversation(title: String, sourceReference: String, transcript: String): Result<String> {
        val cleanTitle = title.trim().take(240)
        val cleanTranscript = transcript.trim().take(24_000)
        if (_snapshot.value.conversations.size >= 160 || _snapshot.value.entities.size >= 1_200) return Result.failure(IllegalStateException("Conversation or entity limit reached. Export a backup before removing older records."))
        if (cleanTitle.isBlank()) return Result.failure(IllegalArgumentException("Add a conversation title."))
        if (cleanTranscript.isBlank()) return Result.failure(IllegalArgumentException("Paste the conversation text to import."))
        if (cleanTranscript.length < 8) return Result.failure(IllegalArgumentException("The imported transcript is too short to be useful."))
        val id = newId()
        val now = nowMillis()
        val conversation = ConversationRecord(
            id = id,
            title = cleanTitle,
            sourceType = "IMPORTED",
            sourceReference = sourceReference.trim().take(2_048),
            messages = listOf(ChatMessageRecord(role = "SOURCE", content = cleanTranscript, sourceType = "IMPORTED", createdAt = now)),
            createdAt = now,
            updatedAt = now
        )
        val sourceEntity = EntityRecord(
            id = id, type = "CONVERSATION", title = cleanTitle,
            description = "User-imported transcript. Memo does not claim direct access to the external service.",
            properties = mapOf("sourceType" to "IMPORTED", "sourceReference" to sourceReference.trim().take(2_048)),
            sourceConversationId = id, sourceExcerpt = cleanTranscript.take(1_000), createdAt = now, updatedAt = now
        )
        updateSnapshot { current ->
            current.copy(
                conversations = listOf(conversation) + current.conversations,
                entities = (listOf(sourceEntity) + current.entities.filterNot { it.id == id }).take(1_200)
            ).withActivity("Conversation imported from a user-provided transcript: $cleanTitle")
        }
        return Result.success(id)
    }

    fun appendChatMessage(conversationId: String, role: String, content: String, modelId: String = "", sourceType: String = "NATIVE"): String? {
        val cleanContent = content.trim().take(24_000)
        val normalizedRole = role.trim().uppercase(Locale.ROOT)
        if (cleanContent.isBlank()) return "Message cannot be empty."
        if (normalizedRole !in setOf("USER", "ASSISTANT", "SYSTEM", "SOURCE", "TOOL")) return "Unsupported message role."
        val current = _snapshot.value
        val currentConversation = current.conversations.firstOrNull { it.id == conversationId } ?: return "Conversation no longer exists."
        val messageLimit = if (normalizedRole == "USER") 249 else 250
        if (currentConversation.messages.size >= messageLimit) return "This conversation is at its message limit. Export the full history before continuing in a linked conversation."
        val message = ChatMessageRecord(role = normalizedRole, content = cleanContent, modelId = modelId.take(160), sourceType = sourceType.take(40))
        updateSnapshot { snapshot ->
            val conversations = snapshot.conversations.map { conversation ->
                if (conversation.id != conversationId) conversation else {
                    val title = if (normalizedRole == "USER" && conversation.title == "New conversation") cleanContent.lineSequence().first().trim().take(72).ifBlank { "New conversation" } else conversation.title
                    conversation.copy(
                        title = title,
                        messages = conversation.messages + message,
                        updatedAt = nowMillis()
                    )
                }
            }
            val updatedConversation = conversations.firstOrNull { it.id == conversationId }
            snapshot.copy(
                conversations = conversations,
                entities = snapshot.entities.map { entity ->
                    if (entity.id == conversationId && updatedConversation != null) entity.copy(title = updatedConversation.title, updatedAt = nowMillis()) else entity
                }
            ).let { next ->
                if (normalizedRole == "USER") next.withActivity("Message added to ${updatedConversation?.title ?: "conversation"}") else next
            }
        }
        return null
    }

    fun renameConversation(conversationId: String, newTitle: String): String? {
        val title = newTitle.trim().take(240)
        if (title.isBlank()) return "Conversation title cannot be empty."
        if (_snapshot.value.conversations.none { it.id == conversationId }) return "Conversation no longer exists."
        updateSnapshot { current ->
            current.copy(
                conversations = current.conversations.map { if (it.id == conversationId) it.copy(title = title, updatedAt = nowMillis()) else it },
                entities = current.entities.map { if (it.id == conversationId && it.type == "CONVERSATION") it.copy(title = title, updatedAt = nowMillis()) else it }
            ).withActivity("Conversation renamed: $title")
        }
        return null
    }

    fun createRelationship(fromEntityId: String, toEntityId: String, relationType: String, sourceConversationId: String = ""): String? {
        val type = relationType.trim().uppercase(Locale.ROOT).replace(Regex("[^A-Z0-9_]+"), "_").trim('_').take(80)
        if (fromEntityId == toEntityId) return "An entity cannot be related to itself."
        if (type.length < 2 || !type.matches(Regex("[A-Z][A-Z0-9_]{1,79}"))) return "Enter a relationship type, such as SUPPORTS or BELONGS_TO."
        val current = _snapshot.value
        val fromEntity = current.entities.firstOrNull { it.id == fromEntityId } ?: return "The source entity no longer exists."
        val toEntity = current.entities.firstOrNull { it.id == toEntityId } ?: return "The target entity no longer exists."
        if (fromEntity.reviewStatus in setOf("REJECTED", "MERGED") || toEntity.reviewStatus in setOf("REJECTED", "MERGED")) return "Archived entities cannot receive new relationships. Open an active entity instead."
        if (sourceConversationId.isNotBlank() && current.conversations.none { it.id == sourceConversationId }) return "The source conversation no longer exists."
        if (current.relationships.any { it.fromEntityId == fromEntityId && it.toEntityId == toEntityId && it.relationType == type && it.sourceConversationId == sourceConversationId }) return "That relationship already exists for this source."
        if (current.relationships.size >= 4_000) return "Relationship limit reached. Export a backup before removing older links."
        val relation = EntityRelationship(fromEntityId = fromEntityId, toEntityId = toEntityId, relationType = type, sourceConversationId = sourceConversationId)
        updateSnapshot { snapshot -> snapshot.copy(relationships = (listOf(relation) + snapshot.relationships).take(4_000)).withActivity("Relationship created: $type") }
        return null
    }

    fun deleteRelationship(relationshipId: String) {
        updateSnapshot { current ->
            if (current.relationships.none { it.id == relationshipId }) current
            else current.copy(relationships = current.relationships.filterNot { it.id == relationshipId }).withActivity("Relationship deleted.")
        }
    }

    fun createEntity(
        type: String,
        title: String,
        description: String,
        properties: Map<String, String> = emptyMap(),
        sourceConversationId: String = "",
        sourceMessageId: String = "",
        sourceJobId: String = "",
        sourceExcerpt: String = "",
        reviewStatus: String = "APPROVED"
    ): String? {
        val normalizedType = type.trim().uppercase(Locale.ROOT).replace(Regex("[^A-Z0-9_]+"), "_").trim('_').take(64)
        val cleanTitle = title.trim().take(240)
        if (!normalizedType.matches(Regex("[A-Z][A-Z0-9_]{1,63}"))) return "Choose a valid entity type."
        if (cleanTitle.isBlank()) return "Give the entity a name."
        if (description.trim().length > 12_000) return "The description is too long."
        val current = _snapshot.value
        if (sourceConversationId.isNotBlank() && current.conversations.none { it.id == sourceConversationId }) return "The source conversation no longer exists."
        if (sourceJobId.isNotBlank()) {
            val sourceJob = current.jobs.firstOrNull { it.id == sourceJobId } ?: return "The source job no longer exists."
            if (sourceConversationId.isNotBlank() && sourceJob.sourceConversationId != sourceConversationId) return "The source job belongs to a different conversation."
        }
        val cleanReviewStatus = reviewStatus.uppercase(Locale.ROOT).takeIf { it in setOf("PROPOSED", "APPROVED") } ?: "APPROVED"
        if (current.entities.size >= 1_200) return "Entity limit reached. Export a backup before removing older entities."
        if (sourceConversationId.isNotBlank() && current.relationships.size >= 4_000) return "Relationship limit reached. Export a backup before removing older links."
        val existing = current.entities.firstOrNull { it.type.equals(normalizedType, true) && it.title.trim().equals(cleanTitle, true) && it.reviewStatus !in setOf("REJECTED", "MERGED") }
        if (existing != null) return "An entity with this type and name already exists: ${existing.title}. Open it to update or link it instead."
        val now = nowMillis()
        val entity = EntityRecord(
            type = normalizedType,
            title = cleanTitle,
            description = description.trim().take(12_000),
            properties = properties.entries.take(40).associate { it.key.trim().take(80) to it.value.trim().take(2_000) },
            reviewStatus = cleanReviewStatus,
            sourceConversationId = sourceConversationId,
            sourceMessageId = sourceMessageId,
            sourceJobId = sourceJobId,
            sourceExcerpt = sourceExcerpt.trim().take(2_000),
            createdAt = now,
            updatedAt = now
        )
        updateSnapshot { snapshot ->
            var relations = snapshot.relationships
            if (sourceConversationId.isNotBlank()) {
                relations = (listOf(EntityRelationship(fromEntityId = sourceConversationId, toEntityId = entity.id, relationType = "PROPOSES", sourceConversationId = sourceConversationId)) + relations).take(4_000)
            }
            snapshot.copy(entities = (listOf(entity) + snapshot.entities).take(1_200), relationships = relations)
                .withActivity("${if (cleanReviewStatus == "PROPOSED") "Entity proposed" else "Entity created"}: ${entity.type} · ${entity.title}")
        }
        return null
    }

    /** Save a reusable browser-backed multi-chat workflow as a proper workspace entity. */
    fun saveBrowserWorkflow(
        existingWorkflowId: String?,
        title: String,
        providerIds: List<String>,
        mode: String
    ): Result<String> {
        if (!_vaultReady.value) return Result.failure(IllegalStateException("Unlock the workspace before saving a workflow."))
        if (_vaultError.value != null) return Result.failure(IllegalStateException("Workspace persistence is unavailable. Export or restore the workspace before continuing."))
        val cleanTitle = title.trim().take(160)
        val validProviders = setOf("chatgpt", "claude", "gemini", "grok", "deepseek", "perplexity", "mistral", "copilot")
        val cleanProviders = providerIds.distinct().filter { it in validProviders }.take(4)
        val cleanMode = mode.uppercase(Locale.ROOT).takeIf { it in setOf("CONSULT_AND_COMPARE", "CRITIQUE_CHAIN") }
            ?: return Result.failure(IllegalArgumentException("Choose a supported workflow mode."))
        if (cleanTitle.isBlank()) return Result.failure(IllegalArgumentException("Name this workflow."))
        if (cleanProviders.size < 2 || cleanProviders.size != providerIds.distinct().size) {
            return Result.failure(IllegalArgumentException("Choose two to four supported frontier chat websites."))
        }
        val current = _snapshot.value
        val workflowDescription = if (cleanMode == "CONSULT_AND_COMPARE") {
            "Reusable browser-backed multi-chat workflow. Each selected frontier site receives the original goal independently through the visible browser. Responses are captured with source evidence, locally compared, and may produce source-grounded entity proposals for human review."
        } else {
            "Reusable browser-backed critique workflow. Each selected frontier site receives the original goal and earlier captured responses through the visible browser, then critiques and refines the work. Responses are captured with source evidence and may produce source-grounded entity proposals for human review."
        }
        val properties = mapOf(
            "providerIds" to org.json.JSONArray(cleanProviders).toString(),
            "mode" to cleanMode,
            "runtime" to "runtime.browser",
            "workflowVersion" to "2"
        )
        if (existingWorkflowId != null) {
            val existing = current.entities.firstOrNull { it.id == existingWorkflowId && it.type == "BROWSER_WORKFLOW" }
                ?: return Result.failure(IllegalStateException("The saved workflow no longer exists."))
            if (current.entities.any { it.id != existing.id && it.type == "BROWSER_WORKFLOW" && it.title.equals(cleanTitle, true) && it.reviewStatus !in setOf("REJECTED", "MERGED") }) {
                return Result.failure(IllegalArgumentException("Another saved workflow already uses this name."))
            }
            updateSnapshot { snapshot ->
                snapshot.copy(entities = snapshot.entities.map { entity ->
                    if (entity.id == existing.id) entity.copy(
                        title = cleanTitle,
                        description = workflowDescription,
                        properties = properties,
                        updatedAt = nowMillis()
                    ) else entity
                }).withActivity("Browser workflow updated: $cleanTitle")
            }
            return Result.success(existing.id)
        }
        if (current.entities.any { it.type == "BROWSER_WORKFLOW" && it.title.equals(cleanTitle, true) && it.reviewStatus !in setOf("REJECTED", "MERGED") }) {
            return Result.failure(IllegalArgumentException("A workflow with this name already exists. Load it to update its settings."))
        }
        val error = createEntity(
            type = "BROWSER_WORKFLOW",
            title = cleanTitle,
            description = workflowDescription,
            properties = properties
        )
        if (error != null) return Result.failure(IllegalStateException(error))
        val saved = _snapshot.value.entities.firstOrNull { it.type == "BROWSER_WORKFLOW" && it.title == cleanTitle }
            ?: return Result.failure(IllegalStateException("The workflow did not appear in the workspace after saving."))
        return Result.success(saved.id)
    }

    fun updateEntityDetails(entityId: String, title: String, description: String): String? {
        val cleanTitle = title.trim().take(240)
        val cleanDescription = description.trim().take(12_000)
        if (cleanTitle.isBlank()) return "Give the entity a name."
        val current = _snapshot.value
        val entity = current.entities.firstOrNull { it.id == entityId } ?: return "Entity no longer exists."
        if (entity.type == "CONVERSATION") return "Rename this entity from AI Chats so the conversation and entity stay synchronized."
        if (entity.reviewStatus in setOf("REJECTED", "MERGED")) return "Archived entity records are read-only so their provenance remains intact."
        if (current.entities.any { it.id != entityId && it.type == entity.type && it.title.trim().equals(cleanTitle, true) && it.reviewStatus !in setOf("REJECTED", "MERGED") }) {
            return "Another ${entity.type.lowercase(Locale.ROOT)} already uses that name. Open it and add a relationship instead."
        }
        updateSnapshot { snapshot ->
            snapshot.copy(entities = snapshot.entities.map { candidate ->
                if (candidate.id == entityId) candidate.copy(title = cleanTitle, description = cleanDescription, updatedAt = nowMillis()) else candidate
            }).withActivity("Entity updated: ${entity.type} · $cleanTitle")
        }
        return null
    }

    /** Merge keeps the source entity as an archived provenance record and redirects its graph links. */
    fun mergeEntities(sourceEntityId: String, targetEntityId: String): String? {
        if (sourceEntityId == targetEntityId) return "Choose two different entities."
        val current = _snapshot.value
        val source = current.entities.firstOrNull { it.id == sourceEntityId } ?: return "The source entity no longer exists."
        val target = current.entities.firstOrNull { it.id == targetEntityId } ?: return "The target entity no longer exists."
        if (source.type == "CONVERSATION" || target.type == "CONVERSATION") return "Conversation records cannot be merged into other entities."
        if (source.type != target.type) return "Only entities of the same type can be merged safely."
        if (source.reviewStatus != "APPROVED" || target.reviewStatus != "APPROVED") return "Approve both entities before merging them."
        if (current.relationships.size >= 4_000) return "Relationship limit reached. Export a backup before removing older links."
        if (current.relationships.any { it.fromEntityId == sourceEntityId && it.toEntityId == targetEntityId && it.relationType == "MERGED_INTO" }) return "This entity is already merged into that target."

        val redirected = current.relationships.mapNotNull { relation ->
            if (relation.relationType == "MERGED_INTO" && relation.fromEntityId == sourceEntityId) return@mapNotNull null
            val from = if (relation.fromEntityId == sourceEntityId) targetEntityId else relation.fromEntityId
            val to = if (relation.toEntityId == sourceEntityId) targetEntityId else relation.toEntityId
            if (from == to) null else relation.copy(fromEntityId = from, toEntityId = to)
        }
        val deduplicated = redirected.distinctBy { "${it.fromEntityId}|${it.toEntityId}|${it.relationType}|${it.sourceConversationId}" }.toMutableList()
        deduplicated += EntityRelationship(
            fromEntityId = sourceEntityId,
            toEntityId = targetEntityId,
            relationType = "MERGED_INTO",
            sourceConversationId = source.sourceConversationId.ifBlank { target.sourceConversationId }
        )
        if (deduplicated.size > 4_000) return "The merge would exceed the workspace relationship limit. Remove old links and try again."

        val mergedProperties = target.properties.toMutableMap()
        source.properties.forEach { (key, value) ->
            if (mergedProperties[key].isNullOrBlank() && (key in mergedProperties || mergedProperties.size < 40)) mergedProperties[key] = value
        }
        val combinedDescription = listOf(target.description.trim(), source.description.trim())
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString("\n\nMerged context: ")
            .take(12_000)
        updateSnapshot { snapshot ->
            snapshot.copy(
                entities = snapshot.entities.map { entity ->
                    when (entity.id) {
                        targetEntityId -> entity.copy(
                            description = combinedDescription,
                            properties = mergedProperties,
                            updatedAt = nowMillis()
                        )
                        sourceEntityId -> entity.copy(reviewStatus = "MERGED", updatedAt = nowMillis())
                        else -> entity
                    }
                },
                relationships = deduplicated
            ).withActivity("Merged ${source.type} · ${source.title} into ${target.title}; source retained in archive.")
        }
        return null
    }

    fun setEntityReviewStatus(entityId: String, status: String) {
        val normalized = status.uppercase(Locale.ROOT).takeIf { it in setOf("APPROVED", "REJECTED") } ?: return
        updateSnapshot { current ->
            val entity = current.entities.firstOrNull { it.id == entityId } ?: return@updateSnapshot current
            if (entity.reviewStatus != "PROPOSED") return@updateSnapshot current
            val updatedEntities = current.entities.map { if (it.id == entityId) it.copy(reviewStatus = normalized, updatedAt = nowMillis()) else it }
            val relations = if (normalized == "REJECTED") current.relationships.filterNot { it.toEntityId == entityId || it.fromEntityId == entityId } else current.relationships.map { relation ->
                if (relation.toEntityId == entityId && relation.relationType == "PROPOSES") relation.copy(relationType = "PRODUCED") else relation
            }
            var updatedJobs = current.jobs
            val sourceJobId = entity.sourceJobId
            if (sourceJobId.isNotBlank()) {
                val remainingProposals = updatedEntities.any { it.sourceJobId == sourceJobId && it.reviewStatus == "PROPOSED" }
                if (!remainingProposals) {
                    val accepted = updatedEntities.count { it.sourceJobId == sourceJobId && it.reviewStatus == "APPROVED" }
                    val rejected = updatedEntities.count { it.sourceJobId == sourceJobId && it.reviewStatus == "REJECTED" }
                    updatedJobs = updatedJobs.map { job ->
                        if (job.id != sourceJobId || job.status != "WAITING_FOR_USER") job else job.copy(
                            status = "SUCCEEDED",
                            resultSummary = "Human review complete: $accepted proposal(s) approved, $rejected rejected.",
                            steps = job.steps.map { step ->
                                if (step.title.equals("Review proposed entities", true) || step.status == "NEEDS_REVIEW") {
                                    step.copy(status = "COMPLETED", detail = "Human review completed: $accepted approved, $rejected rejected.", updatedAt = nowMillis())
                                } else step
                            },
                            updatedAt = nowMillis()
                        )
                    }
                }
            }
            current.copy(entities = updatedEntities, relationships = relations, jobs = updatedJobs)
                .withActivity("Entity ${normalized.lowercase(Locale.ROOT)}: ${entity.title}")
                .let { next ->
                    val completed = updatedJobs.firstOrNull { it.id == sourceJobId && it.status == "SUCCEEDED" }
                    if (completed != null) next.withActivity("Job completed after entity review: ${completed.title}") else next
                }
        }
    }

    fun deleteEntity(entityId: String): String? {
        val current = _snapshot.value
        val entity = current.entities.firstOrNull { it.id == entityId } ?: return "Entity no longer exists."
        if (entity.type == "CONVERSATION") return "Conversation entities are managed by AI Chats."
        if (entity.reviewStatus in setOf("REJECTED", "MERGED")) return "Archived entity records are retained to preserve provenance."
        if (entity.reviewStatus == "PROPOSED") return "Reject this proposal instead so the job review can be completed."
        if (current.relationships.any { it.fromEntityId == entityId || it.toEntityId == entityId }) {
            return "This entity has relationships. Remove the links or merge the entity before deleting it, so the graph remains consistent."
        }
        updateSnapshot { snapshot ->
            snapshot.copy(entities = snapshot.entities.filterNot { it.id == entityId })
                .withActivity("Entity deleted: ${entity.title}", level = "WARN")
        }
        return if (_snapshot.value.entities.none { it.id == entityId }) null else "Workspace changes could not be saved. Check workspace status before retrying."
    }

    /** Executes a bounded app-runtime workflow and persists its verified workspace result. */
    fun createFollowUpTask(sourceEntityId: String, title: String, description: String): Result<String> {
        if (!_vaultReady.value) return Result.failure(IllegalStateException("Unlock the workspace before creating a follow-up task."))
        if (_vaultError.value != null) return Result.failure(IllegalStateException("Workspace persistence is unavailable. Export or restore the workspace before continuing."))
        val before = _snapshot.value
        val creation = FollowUpTaskFactory.create(before, sourceEntityId, title, description, runtimeRegistry)
        if (creation.isFailure) return Result.failure(creation.exceptionOrNull() ?: IllegalStateException("The follow-up task could not be prepared."))
        val outcome = creation.getOrThrow()
        updateSnapshot { current -> if (current == before) outcome.snapshot else current }
        val committed = _snapshot.value.entities.any { it.id == outcome.taskId } &&
            _snapshot.value.relationships.any { it.toEntityId == outcome.taskId } &&
            _snapshot.value.jobs.any { it.id == outcome.jobId && it.status == "SUCCEEDED" }
        return if (committed) Result.success(outcome.jobId) else Result.failure(IllegalStateException("The workspace changed before this task could be committed. Review Work and retry."))
    }

    fun createJob(title: String, goal: String, runtimeId: String, sourceConversationId: String = "", stepTitles: List<String>): String? {
        val cleanTitle = title.trim().take(240)
        val cleanGoal = goal.trim().take(8_000)
        if (cleanTitle.isBlank() || cleanGoal.isBlank() || stepTitles.size > 100) return null
        if (runtimeRegistry.resolve(runtimeId) == null) return null
        if (sourceConversationId.isNotBlank() && _snapshot.value.conversations.none { it.id == sourceConversationId }) return null
        if (_snapshot.value.jobs.size >= 240) { log("The 240-job limit has been reached. Export a backup before removing older jobs.", "WARN"); return null }
        val job = WorkJobRecord(
            title = cleanTitle, goal = cleanGoal, status = "DRAFT", runtimeId = runtimeId.trim().take(80),
            sourceConversationId = sourceConversationId, steps = stepTitles.take(100).map { JobStepRecord(title = it.trim().take(240)) }
        )
        updateSnapshot { current -> current.copy(jobs = (listOf(job) + current.jobs).take(240)).withActivity("Job created: ${job.title}") }
        return job.id
    }

    fun updateJob(jobId: String, transform: (WorkJobRecord) -> WorkJobRecord) {
        updateSnapshot { current ->
            val existing = current.jobs.firstOrNull { it.id == jobId } ?: return@updateSnapshot current
            val updated = transform(existing).copy(updatedAt = nowMillis())
            current.copy(jobs = current.jobs.map { if (it.id == jobId) updated else it })
        }
    }

    fun updateJobStep(jobId: String, stepId: String, status: String, detail: String = "", evidence: String = "") {
        val valid = status.uppercase(Locale.ROOT).takeIf { it in setOf("PENDING", "RUNNING", "COMPLETED", "FAILED", "NEEDS_REVIEW", "SKIPPED") } ?: return
        updateJob(jobId) { job -> job.copy(steps = job.steps.map { step ->
            if (step.id == stepId) step.copy(status = valid, detail = detail.take(2_000), evidence = evidence.take(2_000), updatedAt = nowMillis()) else step
        }) }
    }

    fun updateJobStatus(jobId: String, status: String, resultSummary: String = "") {
        val valid = status.uppercase(Locale.ROOT).takeIf { it in setOf("DRAFT", "READY", "RUNNING", "WAITING_FOR_USER", "SUCCEEDED", "FAILED", "CANCELLED") } ?: return
        updateJob(jobId) { it.copy(status = valid, resultSummary = resultSummary.take(4_000)) }
        log("Job ${valid.lowercase(Locale.ROOT).replace('_', ' ')}: ${_snapshot.value.jobs.firstOrNull { it.id == jobId }?.title ?: "Job"}", if (valid == "FAILED") "ERROR" else "INFO")
    }

    /** Persist an exact external payload before it can be approved or sent. */
    fun proposeExternalAction(
        jobId: String,
        stepId: String,
        runtimeId: String,
        capabilityId: String,
        destination: String,
        title: String,
        payload: String,
        risk: String = "EXTERNAL_WRITE"
    ): String? {
        if (!_vaultReady.value || _vaultError.value != null) return null
        var createdId: String? = null
        updateSnapshot { current ->
            val transition = ActionApprovalLedger.propose(
                current, jobId, stepId, runtimeId, capabilityId, destination, title, payload, risk
            )
            val action = transition.action
            if (!transition.accepted || action == null) {
                current.withActivity(transition.message, jobId, "WARN")
            } else {
                createdId = action.id
                transition.snapshot.withActivity("Action staged for exact-content approval: ${action.title}", jobId)
            }
        }
        return createdId
    }

    fun approveExternalAction(actionId: String, displayedHash: String): Boolean {
        var accepted = false
        updateSnapshot { current ->
            val transition = ActionApprovalLedger.approve(current, actionId, displayedHash)
            accepted = transition.accepted
            if (transition.snapshot == current) {
                if (!transition.accepted) current.withActivity(transition.message, level = "WARN") else current
            } else transition.snapshot.withActivity(transition.message, transition.action?.jobId.orEmpty(), if (transition.accepted) "INFO" else "WARN")
        }
        return accepted
    }

    /** One-use gate immediately before an external side effect. */
    fun beginExternalAction(actionId: String, runtimeId: String, capabilityId: String, destination: String, payload: String): Boolean {
        var accepted = false
        updateSnapshot { current ->
            val transition = ActionApprovalLedger.beginExecution(current, actionId, runtimeId, capabilityId, destination, payload)
            accepted = transition.accepted
            if (transition.snapshot == current) {
                if (!transition.accepted) current.withActivity(transition.message, level = "WARN") else current
            } else transition.snapshot.withActivity(transition.message, transition.action?.jobId.orEmpty(), if (transition.accepted) "INFO" else "WARN")
        }
        return accepted
    }

    fun rejectExternalAction(actionId: String, reason: String = "Rejected by user."): Boolean {
        var accepted = false
        updateSnapshot { current ->
            val transition = ActionApprovalLedger.reject(current, actionId, reason)
            accepted = transition.accepted
            if (transition.snapshot == current) {
                if (!transition.accepted) current.withActivity(transition.message, level = "WARN") else current
            } else transition.snapshot.withActivity(transition.message, transition.action?.jobId.orEmpty(), if (transition.accepted) "INFO" else "WARN")
        }
        return accepted
    }

    fun completeExternalAction(actionId: String, evidenceRef: String): Boolean {
        var accepted = false
        updateSnapshot { current ->
            val transition = ActionApprovalLedger.completeVerified(current, actionId, evidenceRef)
            accepted = transition.accepted
            if (transition.snapshot == current) {
                if (!transition.accepted) current.withActivity(transition.message, level = "WARN") else current
            } else transition.snapshot.withActivity(transition.message, transition.action?.jobId.orEmpty(), if (transition.accepted) "INFO" else "WARN")
        }
        return accepted
    }

    fun markExternalActionNeedsReview(actionId: String, reason: String): Boolean {
        var accepted = false
        updateSnapshot { current ->
            val transition = ActionApprovalLedger.markNeedsReview(current, actionId, reason)
            accepted = transition.accepted
            if (transition.snapshot == current) {
                if (!transition.accepted) current.withActivity(transition.message, level = "WARN") else current
            } else transition.snapshot.withActivity(transition.message, transition.action?.jobId.orEmpty(), if (transition.accepted) "WARN" else "WARN")
        }
        return accepted
    }

    fun createTask(title: String, rawUrl: String, kind: TaskKind, query: String): String? {
        val validation = TaskRules.validate(title, rawUrl, kind, query)
        if (validation != null) return validation
        val normalizedUrl = runCatching { TaskRules.normalizeHttpsUrl(rawUrl) }.getOrElse { return it.message ?: "Invalid URL." }
        val task = TaskRecord(
            title = title.trim(),
            targetUrl = normalizedUrl,
            kind = kind,
            query = query.trim(),
            status = TaskStatus.QUEUED,
            lastMessage = if (normalizedUrl.isBlank()) "Will use the current browser page." else "Ready to open the target page."
        )
        updateSnapshot { current ->
            current.copy(tasks = (listOf(task) + current.tasks).take(200))
                .withActivity("Task created: ${task.title}", task.id)
        }
        return null
    }

    fun markTaskRunning(id: String, message: String = "Waiting for the page. Sign in if needed, then continue.") {
        updateSnapshot { current ->
            current.updateTask(id) { it.copy(status = TaskStatus.RUNNING, lastMessage = message, updatedAt = nowMillis()) }
                .withActivity("Task started: ${current.tasks.firstOrNull { it.id == id }?.title ?: "Task"}", id)
        }
    }

    fun markTaskNeedsReview(id: String, message: String) {
        updateSnapshot { current ->
            current.updateTask(id) { it.copy(status = TaskStatus.NEEDS_REVIEW, lastMessage = message, updatedAt = nowMillis()) }
                .withActivity(message, id)
        }
    }

    fun completeTask(id: String, evidence: EvidenceRecord?, message: String = "Completed and verified.") {
        updateSnapshot { current ->
            var next = current.updateTask(id) { it.copy(status = TaskStatus.COMPLETED, lastMessage = message, updatedAt = nowMillis()) }
            if (evidence != null) next = next.copy(evidence = (listOf(evidence) + next.evidence).take(150))
            next.withActivity("Task completed: $message", id)
        }
    }

    fun failTask(id: String, message: String, blocked: Boolean = false) {
        updateSnapshot { current ->
            current.updateTask(id) {
                it.copy(status = if (blocked) TaskStatus.BLOCKED else TaskStatus.FAILED, lastMessage = message, updatedAt = nowMillis())
            }.withActivity("Task ${if (blocked) "blocked" else "failed"}: $message", id, if (blocked) "WARN" else "ERROR")
        }
    }

    fun addEvidence(evidence: EvidenceRecord) {
        updateSnapshot { current -> current.copy(evidence = (listOf(evidence) + current.evidence).take(150)).withActivity("Evidence captured: ${evidence.title}", evidence.taskId) }
    }

    fun addCouncilRun(run: CouncilRunRecord) {
        updateSnapshot { current ->
            current.copy(councilRuns = (listOf(run) + current.councilRuns.filterNot { it.id == run.id }).take(60))
                .withActivity("Council completed: ${run.pattern.lowercase().replace('_', ' ')} · ${run.turns.count { it.status == "COMPLETED" }} completed turn(s)")
        }
    }

    fun updateCouncilDecision(id: String, decision: String) {
        updateSnapshot { current ->
            current.copy(councilRuns = current.councilRuns.map { run ->
                if (run.id == id) run.copy(finalDecision = decision.trim().take(4_000)) else run
            }).withActivity("Final decision updated for Council run ${id.take(8)}.")
        }
    }

    fun deleteCouncilRun(id: String) {
        updateSnapshot { current -> current.copy(councilRuns = current.councilRuns.filterNot { it.id == id }).withActivity("Council run removed from history.") }
    }

    fun deleteEvidence(id: String) {
        updateSnapshot { current -> current.copy(evidence = current.evidence.filterNot { it.id == id }).withActivity("Evidence item deleted.") }
    }

    fun deleteTask(id: String) {
        updateSnapshot { current -> current.copy(tasks = current.tasks.filterNot { it.id == id }).withActivity("Task deleted.", id) }
    }

    fun log(message: String, level: String = "INFO", taskId: String = "") {
        updateSnapshot { it.withActivity(message, taskId, level) }
    }

    fun exportTo(uri: Uri, resolver: ContentResolver, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            val outcome = withContext(Dispatchers.IO) {
                runCatching {
                    val content = _snapshot.value.copy(themeMode = _themeMode.value).toJson()
                    require(content.toByteArray(Charsets.UTF_8).size <= MAX_WORKSPACE_BACKUP_BYTES) { "Export is larger than 40 MB." }
                    resolver.openOutputStream(uri, "wt")?.use { output -> output.write(content.toByteArray(Charsets.UTF_8)) }
                        ?: error("Could not open the selected destination.")
                }.exceptionOrNull()
            }
            onDone(outcome?.let { safeError(it, "Export failed.") })
            if (outcome == null) log("Workspace exported to a user-selected JSON file.")
        }
    }

    fun importFrom(uri: Uri, resolver: ContentResolver, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val text = resolver.openInputStream(uri)?.use { stream ->
                        val buffer = java.io.ByteArrayOutputStream()
                        val chunk = ByteArray(8_192)
                        var total = 0
                        while (true) {
                            val count = stream.read(chunk)
                            if (count < 0) break
                            total += count
                            require(total <= MAX_WORKSPACE_BACKUP_BYTES) { "Import file is larger than 40 MB." }
                            buffer.write(chunk, 0, count)
                        }
                        buffer.toByteArray().toString(Charsets.UTF_8)
                    } ?: error("Could not read the selected file.")
                    ActionApprovalLedger.invalidateImportedApprovals(AppSnapshot.fromJson(text)).recoverInterruptedTasks()
                }
            }
            result.fold(
                onSuccess = { imported ->
                    _snapshot.value = imported
                    setThemeMode(imported.themeMode)
                    _vaultError.value = null
                    _vaultReady.value = true
                    persist(imported)
                    log("Workspace restored from a JSON export.")
                    onDone(null)
                },
                onFailure = { onDone(safeError(it, "Import failed.")) }
            )
        }
    }

    private fun updateSnapshot(transform: (AppSnapshot) -> AppSnapshot) {
        if (!_vaultReady.value || _vaultError.value != null) return
        val next = transform(_snapshot.value)
        _snapshot.value = next
        persist(next)
    }

    private fun persist(snapshot: AppSnapshot) {
        persistenceQueue.trySend(snapshot)
    }

    private fun AppSnapshot.withActivity(message: String, taskId: String = "", level: String = "INFO"): AppSnapshot =
        copy(activity = (listOf(ActivityRecord(message = message, taskId = taskId, level = level)) + activity).take(500))

    private fun AppSnapshot.updateTask(id: String, transform: (TaskRecord) -> TaskRecord): AppSnapshot =
        copy(tasks = tasks.map { task -> if (task.id == id) transform(task) else task })

    private fun safeError(error: Throwable, fallback: String): String {
        val message = error.message?.trim().orEmpty()
        return (message.takeIf { it.isNotBlank() } ?: fallback).take(220)
    }
}
