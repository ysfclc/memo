package app.memo.android.orchestration

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

class PageSchemaInterpretationParserTest {
    @Test
    fun parsesOnlyBoundedSemanticFieldsAndIgnoresModelInventedActions() {
        val result = PageSchemaInterpretationParser.parse(
            """Here is the mapping:
              {"pagePurpose":"Job search results","intentPatterns":["find relevant jobs","search openings"],
               "fieldSemantics":[
                 {"index":0,"name":"job_keywords","purpose":"Terms used to filter job results","selector":"#override"},
                 {"index":1,"name":"location","purpose":"Geographic filter","action":"submit"}],
               "actions":[{"kind":"CLICK","selector":"#submit"}],"approved":true}
            """.trimIndent(),
            observedControlCount = 2
        )
        assertEquals("Job search results", result?.pagePurpose)
        assertEquals(listOf("find relevant jobs", "search openings"), result?.intentPatterns)
        assertEquals(listOf("job_keywords", "location"), result?.fields?.map { it.name })
        assertTrue(result!!.fields.all { it.index in 0..1 })
    }

    @Test
    fun rejectsMissingPurposeAndUnboundedInputs() {
        assertNull(PageSchemaInterpretationParser.parse("not json", 2))
        assertNull(PageSchemaInterpretationParser.parse("""{"intentPatterns":["search"]}""", 2))
        assertNull(PageSchemaInterpretationParser.parse("{}", 25))
        assertNull(PageSchemaInterpretationParser.parse("x".repeat(24_001), 2))
    }

    @Test
    fun rejectsInvalidDuplicateAndOutOfScopeFields() {
        val result = PageSchemaInterpretationParser.parse(
            """{"pagePurpose":"Lead list","fieldSemantics":[
              {"index":0,"name":"lead_name","purpose":"Name"},
              {"index":0,"name":"company","purpose":"Duplicate index ignored"},
              {"index":1,"name":"#submit","purpose":"Unsafe name ignored"},
              {"index":9,"name":"secret_field","purpose":"Out of scope"},
              {"index":1,"name":"website","purpose":"Website URL"}]}""",
            observedControlCount = 2
        )
        assertEquals(listOf("lead_name", "website"), result?.fields?.map { it.name })
    }
}
