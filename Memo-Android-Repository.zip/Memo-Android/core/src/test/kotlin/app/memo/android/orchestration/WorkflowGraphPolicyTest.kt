package app.memo.android.orchestration

import app.memo.android.data.JobStepRecord
import app.memo.android.data.WorkJobRecord
import org.junit.Assert.*
import org.junit.Test

class WorkflowGraphPolicyTest {
    @Test fun graphAllowsIndependentBranchesAfterTheirOwnDependenciesComplete() {
        val a = JobStepRecord(id = "a", title = "Research")
        val b = JobStepRecord(id = "b", title = "Inspect profile", dependsOn = listOf("a"), status = "COMPLETED")
        val c = JobStepRecord(id = "c", title = "Inspect sources", dependsOn = listOf("a"), status = "PENDING")
        val d = JobStepRecord(id = "d", title = "Compose result", dependsOn = listOf("b", "c"))
        val job = WorkJobRecord(title = "Content", goal = "Prepare content", steps = listOf(a.copy(status = "COMPLETED"), b, c, d))
        assertEquals(listOf("c"), WorkflowGraphPolicy.readyStepIds(job))
        assertTrue(WorkflowGraphPolicy.isReady(job, "c"))
        assertFalse(WorkflowGraphPolicy.isReady(job, "d"))
    }

    @Test fun rejectsCyclesMissingDependenciesAndSelfEdges() {
        val cycle = WorkJobRecord(title = "x", goal = "x", steps = listOf(
            JobStepRecord(id = "a", title = "a", dependsOn = listOf("b")),
            JobStepRecord(id = "b", title = "b", dependsOn = listOf("a"))
        ))
        assertTrue(WorkflowGraphPolicy.validate(cycle)!!.contains("cycle"))
        assertTrue(WorkflowGraphPolicy.validate(cycle.copy(steps = listOf(JobStepRecord(id = "a", title = "a", dependsOn = listOf("missing")))))!!.contains("missing"))
        assertTrue(WorkflowGraphPolicy.validate(cycle.copy(steps = listOf(JobStepRecord(id = "a", title = "a", dependsOn = listOf("a")))))!!.contains("itself"))
    }

    @Test fun retryTimeoutAndTriggerBoundsAreEnforced() {
        val base = WorkJobRecord(title = "x", goal = "x", steps = listOf(JobStepRecord(id = "a", title = "a")))
        assertTrue(WorkflowGraphPolicy.validate(base.copy(steps = listOf(base.steps.single().copy(maxRetries = 4))))!!.contains("Retries"))
        assertTrue(WorkflowGraphPolicy.validate(base.copy(steps = listOf(base.steps.single().copy(timeoutMillis = 900_001))))!!.contains("timeouts"))
        assertTrue(WorkflowGraphPolicy.validate(base.copy(triggerType = "SCHEDULE", triggerEnabled = true))!!.contains("configuration"))
        assertNull(WorkflowGraphPolicy.validate(base.copy(triggerType = "SCHEDULE", triggerConfig = "weekday 09:00", triggerEnabled = true)))
    }

    @Test fun unevaluatedConditionalBranchesAreNeverMarkedReady() {
        val conditional = WorkJobRecord(title = "branch", goal = "branch", steps = listOf(
            JobStepRecord(id = "a", title = "Choose route", status = "COMPLETED"),
            JobStepRecord(id = "b", title = "Conditional follow-up", conditionExpression = "success == true")
        ))
        assertFalse(WorkflowGraphPolicy.isReady(conditional, "b"))
        assertFalse(WorkflowGraphPolicy.readyStepIds(conditional).contains("b"))
    }

    @Test fun legacyJobsKeepSequentialReadinessAndExternalActionRequiresApproval() {
        val job = WorkJobRecord(title = "legacy", goal = "legacy", steps = listOf(
            JobStepRecord(id = "a", title = "a", status = "COMPLETED"),
            JobStepRecord(id = "b", title = "b", status = "PENDING")
        ))
        assertTrue(WorkflowGraphPolicy.isReady(job, "b"))
        val unsafe = job.copy(steps = listOf(JobStepRecord(id = "x", title = "submit", checkpointKind = "EXTERNAL_ACTION", requiresApproval = false)))
        assertTrue(WorkflowGraphPolicy.validate(unsafe)!!.contains("require approval"))
    }
}
