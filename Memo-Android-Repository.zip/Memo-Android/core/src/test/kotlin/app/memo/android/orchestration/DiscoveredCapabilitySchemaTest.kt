package app.memo.android.orchestration

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class DiscoveredCapabilitySchemaTest {
    private fun schema(
        approval: SchemaApprovalState = SchemaApprovalState.PROPOSED,
        pathPrefix: String = "/jobs"
    ) = DiscoveredCapabilitySchema(
        id = "web.example.com.jobs",
        version = 1,
        displayName = "Example job form",
        origin = "https://example.com",
        pathPrefix = pathPrefix,
        intentPatterns = listOf("inspect job forms", "prepare job application"),
        actionKind = SchemaActionKind.OBSERVE,
        fields = listOf(
            CapabilityField(
                name = "search_query",
                label = "Search jobs",
                valueType = "TEXT",
                selectors = listOf(SelectorCandidate("label", "Search jobs", 0.84, "Observed label"))
            )
        ),
        preconditions = listOf("HTTPS origin matches exactly"),
        postconditions = listOf("DOM inventory captured"),
        riskLevel = "LOW",
        approvalState = approval,
        sourceObservationHash = "a".repeat(64),
        createdAt = 1_000,
        updatedAt = 1_000
    )

    @Test fun observedSchemaIsValidButCannotBeReusedBeforeApproval() {
        val proposed = schema()
        assertTrue(DiscoveredCapabilitySchemaPolicy.validate(proposed).valid)
        assertFalse(DiscoveredCapabilitySchemaPolicy.eligibleForReuse(proposed, "https://example.com/jobs/search"))
        val approved = proposed.copy(approvalState = SchemaApprovalState.APPROVED)
        assertTrue(DiscoveredCapabilitySchemaPolicy.eligibleForReuse(approved, "https://example.com/jobs/search"))
    }

    @Test fun reuseRequiresMatchingHttpsOriginAndPathScope() {
        val approved = schema(approval = SchemaApprovalState.APPROVED)
        assertFalse(DiscoveredCapabilitySchemaPolicy.eligibleForReuse(approved, "http://example.com/jobs"))
        assertFalse(DiscoveredCapabilitySchemaPolicy.eligibleForReuse(approved, "https://evil.example.com/jobs"))
        assertFalse(DiscoveredCapabilitySchemaPolicy.eligibleForReuse(approved, "https://example.com/profile"))
        assertFalse(DiscoveredCapabilitySchemaPolicy.eligibleForReuse(approved, "https://example.com:8443/jobs"))
        assertFalse(DiscoveredCapabilitySchemaPolicy.eligibleForReuse(approved, "https://user@example.com/jobs"))
    }

    @Test fun codecRoundTripsVersionedSchemasAndRejectsDuplicateVersions() {
        val original = schema()
        val encoded = DiscoveredCapabilitySchemaCodec.encode(listOf(original))
        assertEquals(original, DiscoveredCapabilitySchemaCodec.decode(encoded).single())
        // Duplicate identity/version is rejected even if the JSON is otherwise valid.
        val twice = DiscoveredCapabilitySchemaCodec.encode(listOf(original, original))
        assertTrue(runCatching { DiscoveredCapabilitySchemaCodec.decode(twice) }.isFailure)
    }

    @Test fun unsafeOriginAndCriticalAutoApprovalFailValidation() {
        val unsafeOrigin = schema().copy(origin = "http://example.com")
        assertFalse(DiscoveredCapabilitySchemaPolicy.validate(unsafeOrigin).valid)
        val critical = schema(approval = SchemaApprovalState.APPROVED).copy(
            actionKind = SchemaActionKind.SUBMIT,
            riskLevel = "CRITICAL"
        )
        assertFalse(DiscoveredCapabilitySchemaPolicy.validate(critical).valid)
    }
}
