package app.memo.android.context

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TextSourcePolicyTest {
    @Test
    fun acceptedTextKeepsProvenanceAndStableFingerprint() {
        val bytes = "# Project\nNext step: test the plan.".toByteArray(Charsets.UTF_8)
        val first = TextSourcePolicy.prepare("notes.md", "content://provider/notes/1", "text/markdown", bytes)
        val second = TextSourcePolicy.prepare("notes.md", "content://provider/notes/1", "text/markdown", bytes)
        assertEquals("# Project\nNext step: test the plan.", first.text)
        assertEquals(bytes.size, first.byteCount)
        assertEquals(first.sha256, second.sha256)
        assertEquals(64, first.sha256.length)
        assertEquals("content://provider/notes/1", first.sourceUri)
    }

    @Test
    fun rejectsUnsupportedFormatsAndOversizedFiles() {
        val unsupported = runCatching {
            TextSourcePolicy.prepare("report.pdf", "content://provider/report", "application/pdf", "not a pdf".toByteArray())
        }
        assertTrue(unsupported.isFailure)
        val oversized = runCatching {
            TextSourcePolicy.prepare("large.txt", "content://provider/large", "text/plain", ByteArray(TextSourcePolicy.MAX_BYTES + 1) { 65 })
        }
        assertTrue(oversized.isFailure)
    }

    @Test
    fun rejectsMalformedUtf8AndNonLocalUris() {
        assertTrue(runCatching {
            TextSourcePolicy.prepare("bad.txt", "content://provider/bad", "text/plain", byteArrayOf(0xC3.toByte(), 0x28))
        }.isFailure)
        assertTrue(runCatching {
            TextSourcePolicy.prepare("notes.txt", "https://example.com/notes.txt", "text/plain", "hello".toByteArray())
        }.isFailure)
    }
}
