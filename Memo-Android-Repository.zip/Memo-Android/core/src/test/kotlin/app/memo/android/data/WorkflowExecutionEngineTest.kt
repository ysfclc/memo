package app.memo.android.data

import org.junit.Assert.*
import org.junit.Test

class WorkflowExecutionEngineTest {
    private fun snapshot(step: JobStepRecord = JobStepRecord(id = "s1", title = "Inspect result")): AppSnapshot =
        AppSnapshot(jobs = listOf(WorkJobRecord(id = "j1", title = "Research", goal = "Find and verify facts", steps = listOf(step))))

    @Test fun startAndUserOutcomeAreAuditedAndRemainExplicitlyUserReported() {
        val started = WorkflowExecutionEngine.start(snapshot(), "j1", "s1", now = 100)
        assertTrue(started.message, started.accepted)
        assertTrue(started.executionToken.isNotBlank())
        val running = started.snapshot.jobs.single().steps.single()
        assertEquals("RUNNING", running.status)
        assertEquals(1, running.attemptCount)
        assertEquals(0L, running.deadlineAt) // Human checkpoints are not timed out while the user works.
        assertTrue(WorkflowExecutionEngine.verifyAudit(started.snapshot))

        val complete = WorkflowExecutionEngine.recordUserOutcome(started.snapshot, "j1", "s1", started.executionToken, "Found two useful source pages.", now = 200)
        assertTrue(complete.message, complete.accepted)
        assertEquals("SUCCEEDED", complete.snapshot.jobs.single().status)
        assertTrue(complete.snapshot.jobs.single().steps.single().evidence.startsWith("USER_REPORTED:"))
        assertEquals("", complete.snapshot.jobs.single().steps.single().executionToken)
        assertEquals(2, complete.snapshot.workflowAuditEvents.size)
        assertTrue(WorkflowExecutionEngine.verifyAudit(complete.snapshot))
    }

    @Test fun staleExecutorResultsAndWrongTokensAreNeverApplied() {
        val started = WorkflowExecutionEngine.start(snapshot(JobStepRecord(id = "s1", title = "Fetch", checkpointKind = "AUTOMATIC")), "j1", "s1", now = 1_000)
        assertTrue(started.accepted)
        val stale = WorkflowExecutionEngine.deliverResult(started.snapshot, "j1", "s1", "old-token", "actual output", now = 1_010)
        assertFalse(stale.accepted)
        assertEquals("RUNNING", stale.snapshot.jobs.single().steps.single().status)

        val delivered = WorkflowExecutionEngine.deliverResult(started.snapshot, "j1", "s1", started.executionToken, "actual output", now = 1_010)
        assertTrue(delivered.message, delivered.accepted)
        assertEquals("COMPLETED", delivered.snapshot.jobs.single().steps.single().status)
        assertTrue(delivered.snapshot.jobs.single().steps.single().evidence.startsWith("RUNTIME_RESULT:"))
    }

    @Test fun generatedArtifactRequiresCurrentTokenAndExactStepProvenance() {
        val started = WorkflowExecutionEngine.start(snapshot(), "j1", "s1", now = 100)
        val artifact = EvidenceRecord(
            id = "e1", title = "Draft", sourceUrl = "", kind = "WORK_ARTIFACT", content = "A draft",
            summary = "A draft", metadata = org.json.JSONObject().put("jobId", "j1").put("stepId", "s1").put("requiresHumanReview", true).toString()
        )
        val withEvidence = started.snapshot.copy(evidence = listOf(artifact))
        val wrongProvenance = artifact.copy(metadata = org.json.JSONObject().put("jobId", "other-job").put("stepId", "s1").put("requiresHumanReview", true).toString())
        val refused = WorkflowExecutionEngine.markArtifactForReview(started.snapshot.copy(evidence = listOf(wrongProvenance)), "j1", "s1", started.executionToken, "e1", "Generated draft", now = 105)
        assertFalse("evidence from another workflow must not attach", refused.accepted)
        val stale = WorkflowExecutionEngine.markArtifactForReview(withEvidence, "j1", "s1", "old-token", "e1", "Generated draft", now = 110)
        assertFalse(stale.accepted)
        assertEquals("RUNNING", stale.snapshot.jobs.single().steps.single().status)

        val accepted = WorkflowExecutionEngine.markArtifactForReview(withEvidence, "j1", "s1", started.executionToken, "e1", "Generated draft", now = 120)
        assertTrue(accepted.message, accepted.accepted)
        assertEquals("NEEDS_REVIEW", accepted.snapshot.jobs.single().steps.single().status)
        assertEquals("evidence:e1", accepted.snapshot.jobs.single().steps.single().evidence)
        assertEquals("", accepted.snapshot.jobs.single().steps.single().executionToken)
        assertEquals("WAITING_FOR_USER", accepted.snapshot.jobs.single().status)
        assertTrue(WorkflowExecutionEngine.verifyAudit(accepted.snapshot))
    }

    @Test fun timeoutReturnsToPendingOnlyWithinBoundedRetryBudget() {
        val step = JobStepRecord(id = "s1", title = "Run bounded action", checkpointKind = "AUTOMATIC", timeoutMillis = 1_000, maxRetries = 1)
        val started = WorkflowExecutionEngine.start(snapshot(step), "j1", "s1", now = 10_000)
        assertEquals(11_000L, started.snapshot.jobs.single().steps.single().deadlineAt)
        val timedOut = WorkflowExecutionEngine.expireTimedOut(started.snapshot, now = 11_001)
        assertTrue(timedOut.accepted)
        assertEquals("PENDING", timedOut.snapshot.jobs.single().steps.single().status)
        assertEquals("WAITING_FOR_USER", timedOut.snapshot.jobs.single().status)
        assertEquals("", timedOut.snapshot.jobs.single().steps.single().executionToken)

        val second = WorkflowExecutionEngine.start(timedOut.snapshot, "j1", "s1", now = 12_000)
        assertTrue(second.accepted)
        val secondTimeout = WorkflowExecutionEngine.expireTimedOut(second.snapshot, now = 13_001)
        assertTrue(secondTimeout.accepted)
        assertEquals("FAILED", secondTimeout.snapshot.jobs.single().steps.single().status)
    }

    @Test fun genericEngineCannotStartExternalWritesAndCancelInvalidatesTokens() {
        val external = snapshot(JobStepRecord(id = "s1", title = "Submit", checkpointKind = "EXTERNAL_ACTION", requiresApproval = true))
        val blocked = WorkflowExecutionEngine.start(external, "j1", "s1")
        assertFalse(blocked.accepted)
        assertTrue(blocked.message.contains("External actions"))
        assertTrue(blocked.snapshot.workflowAuditEvents.isEmpty())

        val active = WorkflowExecutionEngine.start(snapshot(), "j1", "s1", now = 1_000)
        val cancelled = WorkflowExecutionEngine.cancelJob(active.snapshot, "j1", now = 1_100)
        assertTrue(cancelled.accepted)
        assertEquals("CANCELLED", cancelled.snapshot.jobs.single().status)
        assertEquals("CANCELLED", cancelled.snapshot.jobs.single().steps.single().status)
        assertEquals("", cancelled.snapshot.jobs.single().steps.single().executionToken)
        assertFalse(WorkflowExecutionEngine.deliverResult(cancelled.snapshot, "j1", "s1", active.executionToken, "late result", now = 1_200).accepted)
    }

    @Test fun restartInvalidatesInFlightTokenAndAddsRecoveryEvent() {
        val active = WorkflowExecutionEngine.start(snapshot(), "j1", "s1", now = 100)
        val recovered = active.snapshot.recoverInterruptedTasks()
        val step = recovered.jobs.single().steps.single()
        assertEquals("NEEDS_REVIEW", step.status)
        assertEquals("", step.executionToken)
        assertEquals(0L, step.deadlineAt)
        assertEquals(0L, step.startedAt)
        assertEquals("Interrupted by application restart.", step.lastError)
        assertTrue(step.executionToken.isBlank())
        assertTrue(recovered.workflowAuditEvents.any { it.eventType == "STEP_INTERRUPTED_ON_RESTART" })
        assertTrue(WorkflowExecutionEngine.verifyAudit(recovered))
    }

    @Test fun workflowAuditTamperingBlocksFurtherExecutionAndExport() {
        val started = WorkflowExecutionEngine.start(snapshot(), "j1", "s1", now = 100)
        val event = started.snapshot.workflowAuditEvents.single()
        val tampered = started.snapshot.copy(workflowAuditEvents = listOf(event.copy(details = "edited")))
        assertFalse(WorkflowExecutionEngine.verifyAudit(tampered))
        assertFalse(WorkflowExecutionEngine.start(tampered, "j1", "s1").accepted)
        assertTrue(runCatching { tampered.toJson() }.isFailure)
    }

    @Test fun globalStopStillRevokesTokensWhenAuditChainIsDamaged() {
        val started = WorkflowExecutionEngine.start(snapshot(), "j1", "s1", now = 100)
        val first = started.snapshot.workflowAuditEvents.single()
        val damaged = started.snapshot.copy(workflowAuditEvents = listOf(first.copy(details = "modified")))
        val stopped = WorkflowExecutionEngine.cancelActive(damaged, now = 110)
        assertTrue(stopped.accepted)
        assertEquals("CANCELLED", stopped.snapshot.jobs.single().status)
        assertEquals("CANCELLED", stopped.snapshot.jobs.single().steps.single().status)
        assertEquals("", stopped.snapshot.jobs.single().steps.single().executionToken)
        assertTrue(stopped.snapshot.activity.any { it.level == "WARN" })
    }

    @Test fun workflowAuditAndExecutionMetadataRoundTripThroughSchemaSix() {
        val started = WorkflowExecutionEngine.start(snapshot(), "j1", "s1", now = 100)
        val complete = WorkflowExecutionEngine.recordUserOutcome(started.snapshot, "j1", "s1", started.executionToken, "Observed and recorded outcome.", now = 200)
        assertTrue(complete.accepted)
        val raw = complete.snapshot.toJson()
        val root = org.json.JSONObject(raw)
        assertEquals(6, root.optInt("schemaVersion"))
        assertEquals("6.0.0", root.optString("schemaSemver"))
        val restored = AppSnapshot.fromJson(raw)
        assertEquals(complete.snapshot.workflowAuditEvents, restored.workflowAuditEvents)
        assertEquals(1, restored.jobs.single().steps.single().attemptCount)
        assertTrue(WorkflowExecutionEngine.verifyAudit(restored))
    }
}
