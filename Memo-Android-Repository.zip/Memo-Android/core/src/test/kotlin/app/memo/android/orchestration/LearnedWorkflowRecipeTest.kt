package app.memo.android.orchestration

import org.junit.Assert.*
import org.junit.Test

class LearnedWorkflowRecipeTest {
    private fun recipe(approval: RecipeApprovalState = RecipeApprovalState.PROPOSED) = LearnedWorkflowRecipe(
        id = "web.jobs.example.search", version = 1, title = "Search jobs", origin = "https://jobs.example.com", pathPrefix = "/search",
        sourceObservationHash = "a".repeat(64), approvalState = approval, createdAt = 100, updatedAt = 100,
        steps = listOf(
            LearnedRecipeStep("navigate", RecipeStepAction.NAVIGATE, "Open job search"),
            LearnedRecipeStep("query", RecipeStepAction.FILL_PARAMETER, "Fill search query", "name", "q", "job_query", requiresApproval = true, verificationRequired = false),
            LearnedRecipeStep("submit", RecipeStepAction.SUBMIT, "Submit job search", "role-name", "button:Search", requiresApproval = true, verificationRequired = true),
            LearnedRecipeStep("verify", RecipeStepAction.VERIFY_TEXT, "Verify results appeared", "text-exact", "Search results")
        )
    )

    @Test fun proposalRoundTripsAndNeverBecomesRunnableWithoutApproval() {
        val proposal = recipe()
        assertTrue(LearnedWorkflowRecipePolicy.validate(proposal).valid)
        assertFalse(LearnedWorkflowRecipePolicy.eligibleForReuse(proposal, "https://jobs.example.com/search"))
        val decoded = LearnedWorkflowRecipeCodec.decode(LearnedWorkflowRecipeCodec.encode(listOf(proposal))).single()
        assertEquals(proposal, decoded)
        assertFalse(LearnedWorkflowRecipePolicy.eligibleForReuse(decoded, "https://jobs.example.com/search"))
    }

    @Test fun approvedRecipeIsBoundToExactHttpsOriginAndPathScope() {
        val approved = recipe(RecipeApprovalState.APPROVED)
        assertTrue(LearnedWorkflowRecipePolicy.eligibleForReuse(approved, "https://jobs.example.com/search/results"))
        assertFalse(LearnedWorkflowRecipePolicy.eligibleForReuse(approved, "https://evil.example.com/search"))
        assertFalse(LearnedWorkflowRecipePolicy.eligibleForReuse(approved, "http://jobs.example.com/search"))
        assertFalse(LearnedWorkflowRecipePolicy.eligibleForReuse(approved, "https://jobs.example.com/profile"))
    }

    @Test fun rejectsUnapprovedWritesAndLiteralValuesInFillSteps() {
        val noApproval = recipe().copy(steps = recipe().steps.map { if (it.action == RecipeStepAction.SUBMIT) it.copy(requiresApproval = false) else it })
        assertFalse(LearnedWorkflowRecipePolicy.validate(noApproval).valid)
        val literal = recipe().copy(steps = recipe().steps.map { if (it.action == RecipeStepAction.FILL_PARAMETER) it.copy(parameterName = "my actual private search") else it })
        assertFalse(LearnedWorkflowRecipePolicy.validate(literal).valid)
    }

    @Test fun rejectsSensitiveSelectorsAndArbitraryScript() {
        val sensitive = recipe().copy(steps = recipe().steps.map { if (it.id == "query") it.copy(selector = "input[name=password]") else it })
        assertFalse(LearnedWorkflowRecipePolicy.validate(sensitive).valid)
        val script = recipe().copy(steps = recipe().steps.map { if (it.id == "query") it.copy(selector = "javascript:alert(1)") else it })
        assertFalse(LearnedWorkflowRecipePolicy.validate(script).valid)
    }
}
