package app.memo.android.context

import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Locale

/** Deterministic policy for user-selected text sources. This does not extract PDF or media content. */
data class PreparedTextSource(
    val title: String,
    val sourceUri: String,
    val mimeType: String,
    val byteCount: Int,
    val sha256: String,
    val text: String
)

object TextSourcePolicy {
    const val MAX_BYTES = 256 * 1024
    const val MAX_BATCH = 10
    private val allowedExtensions = setOf("txt", "md", "markdown", "csv", "json", "xml", "html", "htm", "log")
    private val allowedMimeTypes = setOf("application/json", "application/xml", "application/csv", "text/csv", "text/markdown", "text/html", "text/plain", "text/xml")

    fun prepare(title: String, sourceUri: String, mimeType: String, bytes: ByteArray): PreparedTextSource {
        val cleanTitle = title.trim().take(180)
        require(cleanTitle.isNotBlank()) { "A source needs a file name." }
        require(sourceUri.startsWith("content://") || sourceUri.startsWith("file://")) { "The source URI is not a local document URI." }
        require(bytes.isNotEmpty()) { "$cleanTitle is empty." }
        require(bytes.size <= MAX_BYTES) { "$cleanTitle is larger than the 256 KB import limit." }

        val normalizedMime = mimeType.trim().lowercase(Locale.ROOT).substringBefore(';')
        val extension = cleanTitle.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val supported = normalizedMime.startsWith("text/") || normalizedMime in allowedMimeTypes || extension in allowedExtensions
        require(supported) { "Unsupported source type for $cleanTitle. Choose text, Markdown, CSV, JSON, XML or HTML files." }

        val decoded = StandardCharsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(bytes)).toString()
        val suspiciousControls = decoded.count { it.code < 32 && it != '\n' && it != '\r' && it != '\t' }
        require(suspiciousControls <= (decoded.length / 100).coerceAtLeast(2)) { "$cleanTitle does not look like UTF-8 text." }
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        return PreparedTextSource(cleanTitle, sourceUri, normalizedMime.ifBlank { "text/plain" }, bytes.size, digest, decoded)
    }
}
