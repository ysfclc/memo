package app.memo.android.orchestration

import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/**
 * A learned website/app capability is a versioned, reviewable recipe, not a hard-coded integration.
 * Discovery may propose a schema from observed DOM/accessibility evidence; only an explicit user
 * approval makes it eligible for reuse. It never grants permission or executes a write by itself.
 */
enum class SchemaActionKind { OBSERVE, NAVIGATE, FILL, CLICK, SUBMIT, UPLOAD, GENERATE_MEDIA }
enum class SchemaApprovalState { PROPOSED, APPROVED, REJECTED, STALE }

data class SelectorCandidate(
    val strategy: String,
    val value: String,
    val confidence: Double,
    val evidence: String = ""
)

data class CapabilityField(
    val name: String,
    val label: String,
    val valueType: String = "TEXT",
    val required: Boolean = false,
    val sensitive: Boolean = false,
    val selectors: List<SelectorCandidate> = emptyList()
)

data class DiscoveredCapabilitySchema(
    val id: String,
    val version: Int,
    val displayName: String,
    val origin: String,
    val pathPrefix: String = "/",
    val intentPatterns: List<String>,
    val actionKind: SchemaActionKind,
    val fields: List<CapabilityField> = emptyList(),
    val preconditions: List<String> = emptyList(),
    val postconditions: List<String> = emptyList(),
    val riskLevel: String = "MEDIUM",
    val approvalState: SchemaApprovalState = SchemaApprovalState.PROPOSED,
    val sourceObservationHash: String,
    val createdAt: Long,
    val updatedAt: Long,
    val notes: String = ""
) {
    val requiresApproval: Boolean get() = actionKind in setOf(SchemaActionKind.FILL, SchemaActionKind.CLICK, SchemaActionKind.SUBMIT, SchemaActionKind.UPLOAD, SchemaActionKind.GENERATE_MEDIA)
}

data class SchemaValidation(val valid: Boolean, val errors: List<String>)

object DiscoveredCapabilitySchemaPolicy {
    private val validTypes = setOf("TEXT", "URL", "EMAIL", "NUMBER", "BOOLEAN", "FILE", "IMAGE", "VIDEO", "JSON")
    private val validRisk = setOf("LOW", "MEDIUM", "HIGH", "CRITICAL")

    fun validate(schema: DiscoveredCapabilitySchema): SchemaValidation {
        val errors = mutableListOf<String>()
        if (!schema.id.matches(Regex("[a-zA-Z0-9._-]{3,120}"))) errors += "Invalid schema id."
        if (schema.version !in 1..10_000) errors += "Version must be positive and bounded."
        if (schema.displayName.isBlank() || schema.displayName.length > 160) errors += "Display name is required and must be at most 160 characters."
        val uri = runCatching { java.net.URI(schema.origin) }.getOrNull()
        if (uri == null || uri.scheme != "https" || uri.host.isNullOrBlank() || uri.userInfo != null || uri.port !in listOf(-1, 443)) errors += "Origin must be a valid HTTPS origin without credentials or a custom port."
        if (uri != null && uri.path.orEmpty() !in listOf("", "/")) errors += "Origin must not contain a path; use pathPrefix for scope."
        if (!schema.pathPrefix.startsWith("/") || schema.pathPrefix.startsWith("//") || schema.pathPrefix.contains("..")) errors += "Path prefix must be an absolute, normalized path."
        if (schema.intentPatterns.isEmpty() || schema.intentPatterns.size > 30 || schema.intentPatterns.any { it.isBlank() || it.length > 240 }) errors += "Provide 1–30 bounded intent patterns."
        if (schema.fields.size > 80 || schema.fields.map { it.name.lowercase() }.distinct().size != schema.fields.size) errors += "Fields must be unique and capped at 80."
        schema.fields.forEach { field ->
            if (!field.name.matches(Regex("[a-zA-Z][a-zA-Z0-9_.-]{0,79}"))) errors += "Invalid field name: ${field.name.take(80)}."
            if (field.label.isBlank() || field.label.length > 160) errors += "Field labels must be non-empty and bounded."
            if (field.valueType !in validTypes) errors += "Unsupported field type for ${field.name}."
            if (field.selectors.size > 8) errors += "Too many selectors for ${field.name}."
            field.selectors.forEach { selector ->
                if (selector.strategy !in setOf("role-name", "label", "placeholder", "test-id", "name", "id", "css", "text-exact", "xpath")) errors += "Unsupported selector strategy for ${field.name}."
                if (selector.value.isBlank() || selector.value.length > 300) errors += "Selector for ${field.name} is empty or too long."
                if (selector.confidence !in 0.0..1.0) errors += "Selector confidence for ${field.name} must be between 0 and 1."
            }
        }
        if (schema.preconditions.size > 30 || schema.postconditions.size > 30) errors += "Too many pre/postconditions."
        if (schema.preconditions.any { it.isBlank() || it.length > 300 } || schema.postconditions.any { it.isBlank() || it.length > 300 }) errors += "Pre/postconditions must be bounded and non-empty."
        if (schema.riskLevel !in validRisk) errors += "Unknown risk level."
        if (!schema.sourceObservationHash.matches(Regex("[a-f0-9]{64}"))) errors += "Source observation must have a SHA-256 hash."
        if (schema.createdAt <= 0 || schema.updatedAt < schema.createdAt) errors += "Invalid schema timestamps."
        if (schema.requiresApproval && schema.approvalState == SchemaApprovalState.APPROVED && schema.riskLevel == "CRITICAL") errors += "Critical-risk schemas cannot be auto-approved; require per-run human approval."
        return SchemaValidation(errors.isEmpty(), errors.distinct())
    }

    fun eligibleForReuse(schema: DiscoveredCapabilitySchema, url: String): Boolean {
        if (schema.approvalState != SchemaApprovalState.APPROVED || !validate(schema).valid) return false
        val uri = runCatching { java.net.URI(url) }.getOrNull() ?: return false
        val origin = runCatching { java.net.URI(schema.origin) }.getOrNull() ?: return false
        return uri.scheme == "https" && uri.host.equals(origin.host, ignoreCase = true) &&
            uri.port in listOf(-1, 443) && uri.userInfo == null &&
            (uri.path ?: "/").let { it == schema.pathPrefix.trimEnd('/') || it.startsWith(schema.pathPrefix.let { p -> if (p.endsWith('/')) p else "$p/" }) }
    }
}

/** Deterministic, versioned JSON persistence format. Store it inside the encrypted workspace vault. */
object DiscoveredCapabilitySchemaCodec {
    const val FORMAT_VERSION = 1

    fun encode(schemas: List<DiscoveredCapabilitySchema>): String = JSONObject().apply {
        put("formatVersion", FORMAT_VERSION)
        put("schemas", JSONArray().apply { schemas.forEach { put(it.toJson()) } })
    }.toString()

    fun decode(json: String): List<DiscoveredCapabilitySchema> {
        val root = JSONObject(json)
        require(root.optInt("formatVersion", -1) == FORMAT_VERSION) { "Unsupported capability schema format." }
        val rows = root.optJSONArray("schemas") ?: JSONArray()
        require(rows.length() <= 500) { "Capability schema store exceeds the safe limit." }
        return (0 until rows.length()).map { index ->
            val row = rows.getJSONObject(index)
            val schema = row.toSchema()
            val validation = DiscoveredCapabilitySchemaPolicy.validate(schema)
            require(validation.valid) { "Invalid capability schema: ${validation.errors.joinToString()}" }
            schema
        }.also { list -> require(list.map { it.id to it.version }.distinct().size == list.size) { "Duplicate schema id/version." } }
    }

    private fun DiscoveredCapabilitySchema.toJson() = JSONObject().apply {
        put("id", id); put("version", version); put("displayName", displayName); put("origin", origin); put("pathPrefix", pathPrefix)
        put("intentPatterns", JSONArray(intentPatterns)); put("actionKind", actionKind.name); put("riskLevel", riskLevel)
        put("approvalState", approvalState.name); put("sourceObservationHash", sourceObservationHash)
        put("createdAt", createdAt); put("updatedAt", updatedAt); put("notes", notes.take(1000))
        put("fields", JSONArray().apply { fields.forEach { f -> put(JSONObject().apply {
            put("name", f.name); put("label", f.label); put("valueType", f.valueType); put("required", f.required); put("sensitive", f.sensitive)
            put("selectors", JSONArray().apply { f.selectors.forEach { s -> put(JSONObject().apply { put("strategy", s.strategy); put("value", s.value); put("confidence", s.confidence); put("evidence", s.evidence.take(300)) }) } })
        }) } })
        put("preconditions", JSONArray(preconditions)); put("postconditions", JSONArray(postconditions))
    }

    private fun JSONObject.toSchema(): DiscoveredCapabilitySchema {
        val fieldsArray = optJSONArray("fields") ?: JSONArray()
        val fields = (0 until fieldsArray.length()).map { i ->
            val f = fieldsArray.getJSONObject(i); val selectors = f.optJSONArray("selectors") ?: JSONArray()
            CapabilityField(f.getString("name"), f.getString("label"), f.optString("valueType", "TEXT"), f.optBoolean("required"), f.optBoolean("sensitive"),
                (0 until selectors.length()).map { j -> selectors.getJSONObject(j).let { s -> SelectorCandidate(s.getString("strategy"), s.getString("value"), s.getDouble("confidence"), s.optString("evidence")) } })
        }
        fun strings(key: String): List<String> { val a = optJSONArray(key) ?: JSONArray(); return (0 until a.length()).map { a.getString(it) } }
        return DiscoveredCapabilitySchema(getString("id"), getInt("version"), getString("displayName"), getString("origin"), optString("pathPrefix", "/"), strings("intentPatterns"),
            SchemaActionKind.valueOf(getString("actionKind")), fields, strings("preconditions"), strings("postconditions"), optString("riskLevel", "MEDIUM"),
            SchemaApprovalState.valueOf(getString("approvalState")), getString("sourceObservationHash"), getLong("createdAt"), getLong("updatedAt"), optString("notes"))
    }
}

fun sha256Observation(observation: String): String = MessageDigest.getInstance("SHA-256")
    .digest(observation.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
