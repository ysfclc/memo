package app.memo.android.orchestration

import org.json.JSONArray
import org.json.JSONObject

/**
 * A teachable browser recipe is a typed plan with evidence and checks, never an opaque script.
 * It stores parameter names and selectors, not user-entered values or arbitrary JavaScript.
 */
enum class RecipeStepAction { NAVIGATE, OBSERVE, FILL_PARAMETER, CLICK, SUBMIT, WAIT_FOR_TEXT, VERIFY_TEXT }
enum class RecipeApprovalState { PROPOSED, APPROVED, REJECTED, STALE }

data class LearnedRecipeStep(
    val id: String,
    val action: RecipeStepAction,
    val description: String,
    val selectorStrategy: String = "",
    val selector: String = "",
    val parameterName: String = "",
    val expectedText: String = "",
    val timeoutMillis: Long = 10_000,
    val requiresApproval: Boolean = action in setOf(RecipeStepAction.FILL_PARAMETER, RecipeStepAction.CLICK, RecipeStepAction.SUBMIT),
    val verificationRequired: Boolean = action in setOf(RecipeStepAction.CLICK, RecipeStepAction.SUBMIT)
)

data class LearnedWorkflowRecipe(
    val id: String,
    val version: Int,
    val title: String,
    val origin: String,
    val pathPrefix: String,
    val sourceObservationHash: String,
    val steps: List<LearnedRecipeStep>,
    val approvalState: RecipeApprovalState = RecipeApprovalState.PROPOSED,
    val createdAt: Long,
    val updatedAt: Long,
    val notes: String = ""
)

data class RecipeValidation(val valid: Boolean, val errors: List<String>)

object LearnedWorkflowRecipePolicy {
    private val selectorStrategies = setOf("role-name", "label", "placeholder", "test-id", "name", "id", "css", "text-exact")
    private val parameterPattern = Regex("[a-zA-Z][a-zA-Z0-9_.-]{0,79}")

    fun validate(recipe: LearnedWorkflowRecipe): RecipeValidation {
        val errors = mutableListOf<String>()
        if (!recipe.id.matches(Regex("[a-zA-Z0-9._-]{3,120}"))) errors += "Invalid recipe id."
        if (recipe.version !in 1..10_000) errors += "Recipe version is outside the supported range."
        if (recipe.title.isBlank() || recipe.title.length > 160) errors += "Recipe title is required and bounded."
        val origin = runCatching { java.net.URI(recipe.origin) }.getOrNull()
        if (origin == null || origin.scheme != "https" || origin.host.isNullOrBlank() || origin.userInfo != null || origin.port !in listOf(-1, 443) || origin.path.orEmpty() !in listOf("", "/")) errors += "Recipe origin must be an HTTPS origin without credentials, custom ports, or a path."
        if (!recipe.pathPrefix.startsWith("/") || recipe.pathPrefix.startsWith("//") || recipe.pathPrefix.contains("..")) errors += "Recipe path scope must be normalized and absolute."
        if (!recipe.sourceObservationHash.matches(Regex("[a-f0-9]{64}"))) errors += "Recipe must retain a SHA-256 source observation fingerprint."
        if (recipe.steps.isEmpty() || recipe.steps.size > 80) errors += "Recipe must contain 1–80 steps."
        if (recipe.steps.map { it.id }.distinct().size != recipe.steps.size) errors += "Step ids must be unique."
        recipe.steps.forEachIndexed { index, step ->
            if (!step.id.matches(Regex("[a-zA-Z0-9._-]{1,100}"))) errors += "Step ${index + 1} has an invalid id."
            if (step.description.isBlank() || step.description.length > 240) errors += "Step ${index + 1} needs a bounded description."
            if (step.timeoutMillis !in 500..120_000) errors += "Step ${index + 1} timeout must be 500–120000 ms."
            if (step.action in setOf(RecipeStepAction.FILL_PARAMETER, RecipeStepAction.CLICK, RecipeStepAction.SUBMIT, RecipeStepAction.WAIT_FOR_TEXT, RecipeStepAction.VERIFY_TEXT)) {
                if (step.selectorStrategy !in selectorStrategies || step.selector.isBlank() || step.selector.length > 300) errors += "Step ${index + 1} needs a supported, bounded selector."
            }
            if (step.action == RecipeStepAction.FILL_PARAMETER && !parameterPattern.matches(step.parameterName)) errors += "Fill steps must refer to a named parameter, never a captured literal value."
            if (step.action != RecipeStepAction.FILL_PARAMETER && step.parameterName.isNotBlank()) errors += "Only fill steps may name a parameter."
            if (step.action in setOf(RecipeStepAction.CLICK, RecipeStepAction.SUBMIT) && !step.requiresApproval) errors += "Click and submit steps must require per-run approval."
            if (step.action in setOf(RecipeStepAction.CLICK, RecipeStepAction.SUBMIT) && !step.verificationRequired) errors += "Click and submit steps must verify a postcondition."
            if (step.selector.contains("javascript:", ignoreCase = true) || step.selector.contains("eval(", ignoreCase = true)) errors += "Arbitrary script selectors are not allowed."
            if (Regex("(?i)(password|passwd|secret|token|otp|one-time-code|credit.?card|cvv)").containsMatchIn(step.selector) || Regex("(?i)(password|passwd|secret|token|otp|one-time-code|credit.?card|cvv)").containsMatchIn(step.parameterName)) errors += "Sensitive controls cannot be stored as reusable recipe fields."
            if (step.expectedText.length > 500) errors += "Step ${index + 1} verification text is too long."
        }
        if (recipe.createdAt <= 0 || recipe.updatedAt < recipe.createdAt) errors += "Recipe timestamps are invalid."
        if (recipe.approvalState == RecipeApprovalState.APPROVED && recipe.steps.any { it.action in setOf(RecipeStepAction.CLICK, RecipeStepAction.SUBMIT) && !it.requiresApproval }) errors += "External actions cannot bypass per-run approval."
        return RecipeValidation(errors.isEmpty(), errors.distinct())
    }

    fun eligibleForReuse(recipe: LearnedWorkflowRecipe, url: String): Boolean {
        if (recipe.approvalState != RecipeApprovalState.APPROVED || !validate(recipe).valid) return false
        val target = runCatching { java.net.URI(url) }.getOrNull() ?: return false
        val origin = runCatching { java.net.URI(recipe.origin) }.getOrNull() ?: return false
        if (target.scheme != "https" || !target.host.equals(origin.host, true) || target.port !in listOf(-1, 443) || target.userInfo != null) return false
        val path = target.path.ifBlank { "/" }
        return path == recipe.pathPrefix.trimEnd('/') || path.startsWith(if (recipe.pathPrefix.endsWith('/')) recipe.pathPrefix else "${recipe.pathPrefix}/")
    }
}

object LearnedWorkflowRecipeCodec {
    const val FORMAT_VERSION = 1
    fun encode(recipes: List<LearnedWorkflowRecipe>): String = JSONObject().apply {
        put("formatVersion", FORMAT_VERSION)
        put("recipes", JSONArray().apply { recipes.forEach { recipe -> put(recipe.toJson()) } })
    }.toString()

    fun decode(raw: String): List<LearnedWorkflowRecipe> {
        val root = JSONObject(raw)
        require(root.optInt("formatVersion", -1) == FORMAT_VERSION) { "Unsupported learned recipe format." }
        val rows = root.optJSONArray("recipes") ?: JSONArray()
        require(rows.length() <= 500) { "Recipe catalog exceeds the supported limit." }
        val recipes = (0 until rows.length()).map { i ->
            val row = rows.getJSONObject(i)
            val stepsJson = row.optJSONArray("steps") ?: JSONArray()
            val steps = (0 until stepsJson.length()).map { j ->
                val s = stepsJson.getJSONObject(j)
                LearnedRecipeStep(
                    id = s.getString("id"), action = RecipeStepAction.valueOf(s.getString("action")),
                    description = s.getString("description"), selectorStrategy = s.optString("selectorStrategy"),
                    selector = s.optString("selector"), parameterName = s.optString("parameterName"),
                    expectedText = s.optString("expectedText"), timeoutMillis = s.optLong("timeoutMillis", 10_000),
                    requiresApproval = s.optBoolean("requiresApproval"), verificationRequired = s.optBoolean("verificationRequired")
                )
            }
            LearnedWorkflowRecipe(row.getString("id"), row.getInt("version"), row.getString("title"), row.getString("origin"), row.getString("pathPrefix"), row.getString("sourceObservationHash"), steps,
                RecipeApprovalState.valueOf(row.getString("approvalState")), row.getLong("createdAt"), row.getLong("updatedAt"), row.optString("notes"))
        }
        recipes.forEach { recipe -> require(LearnedWorkflowRecipePolicy.validate(recipe).valid) { "Invalid learned recipe: ${LearnedWorkflowRecipePolicy.validate(recipe).errors.joinToString()}" } }
        require(recipes.map { it.id to it.version }.distinct().size == recipes.size) { "Duplicate recipe id/version." }
        return recipes
    }

    private fun LearnedWorkflowRecipe.toJson() = JSONObject().apply {
        put("id", id); put("version", version); put("title", title); put("origin", origin); put("pathPrefix", pathPrefix)
        put("sourceObservationHash", sourceObservationHash); put("approvalState", approvalState.name); put("createdAt", createdAt); put("updatedAt", updatedAt); put("notes", notes.take(1000))
        put("steps", JSONArray().apply { steps.forEach { s -> put(JSONObject().apply {
            put("id", s.id); put("action", s.action.name); put("description", s.description); put("selectorStrategy", s.selectorStrategy); put("selector", s.selector)
            put("parameterName", s.parameterName); put("expectedText", s.expectedText); put("timeoutMillis", s.timeoutMillis); put("requiresApproval", s.requiresApproval); put("verificationRequired", s.verificationRequired)
        }) } })
    }
}
