package app.memo.android.data

import app.memo.android.orchestration.WorkflowGraphPolicy
import java.security.MessageDigest
import java.util.UUID

/** A durable, hash-chained description of a workflow state transition. Payloads and secrets never belong here. */
data class WorkflowAuditEvent(
    val id: String = newId(),
    val sequence: Long,
    val at: Long,
    val actor: String,
    val eventType: String,
    val jobId: String,
    val stepId: String = "",
    val status: String,
    val previousHash: String,
    val eventHash: String,
    val details: String = ""
)

data class WorkflowTransition(
    val snapshot: AppSnapshot,
    val accepted: Boolean,
    val message: String,
    val executionToken: String = ""
)

/**
 * Deterministic workflow state transitions for Memo's typed DAG.
 * It does not invoke models, browsers, or apps. Executors must carry the execution token
 * back with their result; stale results are discarded. External-write steps remain behind
 * ActionApprovalLedger and cannot be started here.
 */
object WorkflowExecutionEngine {
    const val MAX_EVENTS = 4_000
    private const val GENESIS = "WORKFLOW-GENESIS"

    fun start(
        snapshot: AppSnapshot,
        jobId: String,
        stepId: String,
        actor: String = "USER",
        now: Long = nowMillis()
    ): WorkflowTransition {
        val integrityError = integrityError(snapshot)
        if (integrityError != null) return rejected(snapshot, integrityError)
        if (snapshot.workflowAuditEvents.size >= MAX_EVENTS) return rejected(snapshot, "Workflow audit history is full. Export a backup before starting more work.")
        val job = snapshot.jobs.firstOrNull { it.id == jobId } ?: return rejected(snapshot, "This workflow no longer exists.")
        if (job.status in setOf("SUCCEEDED", "FAILED", "CANCELLED")) return rejected(snapshot, "This workflow is ${job.status.lowercase()}; create or reopen a draft before starting work.")
        val graphError = WorkflowGraphPolicy.validate(job)
        if (graphError != null) return rejected(snapshot, "Workflow validation failed: $graphError")
        val step = job.steps.firstOrNull { it.id == stepId } ?: return rejected(snapshot, "This workflow step no longer exists.")
        if (step.requiresApproval || step.checkpointKind == "EXTERNAL_ACTION") {
            return rejected(snapshot, "External actions must be started through the exact-content approval and destination runtime, not the generic workflow engine.")
        }
        if (step.conditionExpression.isNotBlank()) return rejected(snapshot, "This step has an unevaluated condition. Memo will not guess whether the branch should run.")
        if (!WorkflowGraphPolicy.isReady(job, stepId)) return rejected(snapshot, "This step is waiting for its dependencies or needs review.")
        if (step.status !in setOf("PENDING", "NEEDS_REVIEW")) return rejected(snapshot, "This step cannot start from ${step.status}.")

        val token = UUID.randomUUID().toString()
        val attempt = (step.attemptCount + 1).coerceAtMost(4)
        val hasExecutionDeadline = step.checkpointKind !in setOf("USER_CHECKPOINT", "HUMAN_REVIEW")
        val deadline = if (hasExecutionDeadline) safeDeadline(now, step.timeoutMillis) else 0L
        val updatedStep = step.copy(
            status = "RUNNING",
            executionToken = token,
            attemptCount = attempt,
            startedAt = now,
            deadlineAt = deadline,
            lastError = "",
            detail = appendDetail(step.detail, "Started by $actor at $now; attempt $attempt.", 2_000),
            updatedAt = now
        )
        val updatedJob = job.copy(
            status = "RUNNING",
            steps = job.steps.map { if (it.id == stepId) updatedStep else it },
            resultSummary = if (deadline == 0L) "A user checkpoint is active. Memo has not executed the deliverable; record what was actually observed." else "Execution is running with a deadline and correlation token.",
            updatedAt = now
        )
        val base = snapshot.copy(jobs = snapshot.jobs.map { if (it.id == jobId) updatedJob else it })
        val audited = appendEvent(base, updatedJob, updatedStep, "STEP_STARTED", actor, "attempt=$attempt; deadline=$deadline", now)
            ?: return rejected(snapshot, "The workflow audit chain could not accept this transition. No work was started.")
        return WorkflowTransition(audited, true, "Step started. Results must return with this execution token.", token)
    }

    /** A human-entered outcome is explicitly labelled as user-reported, never as independently verified. */
    fun recordUserOutcome(
        snapshot: AppSnapshot,
        jobId: String,
        stepId: String,
        executionToken: String,
        outcome: String,
        now: Long = nowMillis()
    ): WorkflowTransition {
        val integrityError = integrityError(snapshot)
        if (integrityError != null) return rejected(snapshot, integrityError)
        if (snapshot.workflowAuditEvents.size >= MAX_EVENTS) return rejected(snapshot, "Workflow audit history is full. Export a backup before recording more work.")
        val job = snapshot.jobs.firstOrNull { it.id == jobId } ?: return rejected(snapshot, "This workflow no longer exists.")
        val step = job.steps.firstOrNull { it.id == stepId } ?: return rejected(snapshot, "This workflow step no longer exists.")
        if (step.requiresApproval || step.checkpointKind == "EXTERNAL_ACTION") return rejected(snapshot, "External-action outcomes must be recorded by the approved destination runtime with saved response evidence.")
        if (step.status != "RUNNING") return rejected(snapshot, "Start this checkpoint before recording an outcome.")
        if (executionToken.isBlank() || executionToken != step.executionToken) return rejected(snapshot, "This result belongs to an old or different execution. It was not applied.")
        val clean = outcome.trim().take(2_000)
        if (clean.length < 6) return rejected(snapshot, "Record a concrete outcome of at least six characters.")
        if (step.deadlineAt > 0 && now > step.deadlineAt) return expireOne(snapshot, job, step, now)

        val updatedStep = step.copy(
            status = "COMPLETED",
            evidence = "USER_REPORTED: $clean".take(2_000),
            detail = appendDetail(step.detail, "Outcome recorded by user at $now; it is not independently verified.", 2_000),
            executionToken = "",
            deadlineAt = 0L,
            startedAt = 0L,
            lastError = "",
            updatedAt = now
        )
        val steps = job.steps.map { if (it.id == stepId) updatedStep else it }
        val status = resultingJobStatus(steps)
        val updatedJob = job.copy(
            status = status,
            steps = steps,
            resultSummary = when (status) {
                "SUCCEEDED" -> "All checkpoints have a recorded outcome. User-reported outcomes are not independently verified unless linked to separate evidence."
                "FAILED" -> "A required checkpoint failed. Review the failure before continuing."
                else -> "Checkpoint outcome recorded by user. Continue with a dependency-ready step."
            },
            updatedAt = now
        )
        val base = snapshot.copy(jobs = snapshot.jobs.map { if (it.id == jobId) updatedJob else it })
        val audited = appendEvent(base, updatedJob, updatedStep, "STEP_USER_OUTCOME_RECORDED", "USER", "User-reported outcome saved; no independent verification asserted.", now)
            ?: return rejected(snapshot, "The workflow audit chain could not accept this transition. The outcome was not saved.")
        return WorkflowTransition(audited, true, if (status == "SUCCEEDED") "All workflow checkpoints have outcomes; verification status remains explicit." else "User-reported checkpoint outcome saved.")
    }

    /** Stores a generated artifact as NEEDS_REVIEW only if the originating execution token is still current. */
    fun markArtifactForReview(
        snapshot: AppSnapshot,
        jobId: String,
        stepId: String,
        executionToken: String,
        evidenceId: String,
        detail: String,
        now: Long = nowMillis()
    ): WorkflowTransition {
        val integrityError = integrityError(snapshot)
        if (integrityError != null) return rejected(snapshot, integrityError)
        if (snapshot.workflowAuditEvents.size >= MAX_EVENTS) return rejected(snapshot, "Workflow audit history is full. Export a backup before accepting more work.")
        val job = snapshot.jobs.firstOrNull { it.id == jobId } ?: return rejected(snapshot, "This workflow no longer exists.")
        val step = job.steps.firstOrNull { it.id == stepId } ?: return rejected(snapshot, "This workflow step no longer exists.")
        if (step.status != "RUNNING" || executionToken.isBlank() || executionToken != step.executionToken) {
            return rejected(snapshot, "This artifact belongs to an old or different execution. It remains in Evidence but was not attached to this checkpoint.")
        }
        if (step.requiresApproval || step.checkpointKind == "EXTERNAL_ACTION") return rejected(snapshot, "External writes cannot become draft artifacts through a generic executor result.")
        if (step.deadlineAt > 0L && now > step.deadlineAt) return expireOne(snapshot, job, step, now)
        val evidence = snapshot.evidence.firstOrNull { it.id == evidenceId }
            ?: return rejected(snapshot, "The draft artifact was not committed to Evidence.")
        val artifactMatches = runCatching {
            val metadata = org.json.JSONObject(evidence.metadata)
            metadata.optString("jobId") == jobId && metadata.optString("stepId") == stepId && metadata.optBoolean("requiresHumanReview", false)
        }.getOrDefault(false)
        if (!artifactMatches) return rejected(snapshot, "The Evidence item does not identify this workflow step as its source.")

        val updatedStep = step.copy(
            status = "NEEDS_REVIEW",
            evidence = "evidence:$evidenceId",
            detail = appendDetail(detail, "Artifact saved to Evidence at $now. Human review is required; model output is not independent verification.", 2_000),
            executionToken = "",
            deadlineAt = 0L,
            startedAt = 0L,
            lastError = "",
            updatedAt = now
        )
        val steps = job.steps.map { if (it.id == stepId) updatedStep else it }
        val updatedJob = job.copy(
            status = if (steps.any { it.status == "RUNNING" }) "RUNNING" else "WAITING_FOR_USER",
            steps = steps,
            resultSummary = "A draft artifact is saved to Evidence and awaits human review. It is not independently verified.",
            updatedAt = now
        )
        val base = snapshot.copy(jobs = snapshot.jobs.map { if (it.id == jobId) updatedJob else it })
        val audited = appendEvent(base, updatedJob, updatedStep, "STEP_ARTIFACT_READY_FOR_REVIEW", "LOCAL_RUNTIME", "evidence:$evidenceId; artifact content omitted from audit", now)
            ?: return rejected(snapshot, "The workflow audit chain could not record the draft artifact. The checkpoint was not changed.")
        return WorkflowTransition(audited, true, "Draft artifact attached to the active checkpoint for review.")
    }

    /** Accepts delayed executor output only if its execution token is still current. */
    fun deliverResult(
        snapshot: AppSnapshot,
        jobId: String,
        stepId: String,
        executionToken: String,
        result: String,
        evidenceRef: String = "",
        now: Long = nowMillis()
    ): WorkflowTransition {
        val integrityError = integrityError(snapshot)
        if (integrityError != null) return rejected(snapshot, integrityError)
        val job = snapshot.jobs.firstOrNull { it.id == jobId } ?: return rejected(snapshot, "This workflow no longer exists.")
        val step = job.steps.firstOrNull { it.id == stepId } ?: return rejected(snapshot, "This workflow step no longer exists.")
        if (step.status != "RUNNING" || executionToken.isBlank() || executionToken != step.executionToken) {
            return rejected(snapshot, "Stale execution result discarded. The step has moved on or been cancelled.")
        }
        if (step.deadlineAt > 0 && now > step.deadlineAt) return expireOne(snapshot, job, step, now)
        val clean = result.trim().take(2_000)
        if (clean.length < 2) return fail(snapshot, jobId, stepId, executionToken, "Executor returned an empty result.", retryable = true, now = now)
        if (step.requiresApproval || step.checkpointKind == "EXTERNAL_ACTION") return rejected(snapshot, "External writes cannot be completed through a generic executor result.")
        if (snapshot.workflowAuditEvents.size >= MAX_EVENTS) return rejected(snapshot, "Workflow audit history is full. Export a backup before accepting more results.")

        val savedEvidence = evidenceRef.trim().take(2_048)
        if (savedEvidence.isNotBlank() && !snapshot.evidence.any { it.id == savedEvidence.removePrefix("evidence:") }) {
            return rejected(snapshot, "The referenced evidence record is not present in this workspace.")
        }
        val updatedStep = step.copy(
            status = "COMPLETED",
            evidence = (if (savedEvidence.isBlank()) "RUNTIME_RESULT: " else "RUNTIME_RESULT; ${savedEvidence}: ") + clean,
            detail = appendDetail(step.detail, "Executor result accepted at $now with current correlation token.", 2_000),
            executionToken = "",
            deadlineAt = 0L,
            startedAt = 0L,
            lastError = "",
            updatedAt = now
        )
        val steps = job.steps.map { if (it.id == stepId) updatedStep else it }
        val status = resultingJobStatus(steps)
        val updatedJob = job.copy(
            status = status,
            steps = steps,
            resultSummary = if (status == "SUCCEEDED") "All workflow steps returned outcomes. Check the evidence links before treating side effects as verified." else "A result was accepted. Dependency-ready steps may now continue.",
            updatedAt = now
        )
        val base = snapshot.copy(jobs = snapshot.jobs.map { if (it.id == jobId) updatedJob else it })
        val audited = appendEvent(base, updatedJob, updatedStep, "STEP_RESULT_ACCEPTED", "EXECUTOR", "Result accepted; evidenceRef=${if (savedEvidence.isBlank()) "none" else savedEvidence}; result content omitted from audit.", now)
            ?: return rejected(snapshot, "The workflow audit chain could not accept this result. No result was applied.")
        return WorkflowTransition(audited, true, "Current executor result accepted.")
    }

    /** Bounded retry policy. Retrying is never done automatically here; the step returns to PENDING for an explicit run. */
    fun fail(
        snapshot: AppSnapshot,
        jobId: String,
        stepId: String,
        executionToken: String,
        reason: String,
        retryable: Boolean,
        now: Long = nowMillis()
    ): WorkflowTransition {
        val integrityError = integrityError(snapshot)
        if (integrityError != null) return rejected(snapshot, integrityError)
        if (snapshot.workflowAuditEvents.size >= MAX_EVENTS) return rejected(snapshot, "Workflow audit history is full. Export a backup before recording more failures.")
        val job = snapshot.jobs.firstOrNull { it.id == jobId } ?: return rejected(snapshot, "This workflow no longer exists.")
        val step = job.steps.firstOrNull { it.id == stepId } ?: return rejected(snapshot, "This workflow step no longer exists.")
        if (step.status != "RUNNING" || executionToken.isBlank() || executionToken != step.executionToken) return rejected(snapshot, "Failure report belongs to an old or different execution. It was ignored.")
        if (step.requiresApproval || step.checkpointKind == "EXTERNAL_ACTION") return rejected(snapshot, "External action failures must be resolved by the approved runtime and action ledger.")
        val safeError = redactReason(reason)
        val retry = retryable && step.attemptCount <= step.maxRetries
        val updatedStep = step.copy(
            status = if (retry) "PENDING" else "FAILED",
            detail = appendDetail(step.detail, if (retry) "Attempt failed; one bounded manual retry is available." else "Attempt failed; retry budget exhausted or failure is not retryable.", 2_000),
            evidence = "",
            executionToken = "",
            deadlineAt = 0L,
            startedAt = 0L,
            lastError = safeError,
            updatedAt = now
        )
        val steps = job.steps.map { if (it.id == stepId) updatedStep else it }
        val status = if (retry) "WAITING_FOR_USER" else if (steps.any { it.status == "RUNNING" }) "RUNNING" else "FAILED"
        val updatedJob = job.copy(status = status, steps = steps, resultSummary = if (retry) "Step failed. A bounded retry is available and requires an explicit user start." else "Step failed: $safeError", updatedAt = now)
        val base = snapshot.copy(jobs = snapshot.jobs.map { if (it.id == jobId) updatedJob else it })
        val audited = appendEvent(base, updatedJob, updatedStep, if (retry) "STEP_RETRY_AVAILABLE" else "STEP_FAILED", "EXECUTOR", "retryable=$retryable; $safeError", now)
            ?: return rejected(snapshot, "The workflow audit chain could not record this failure. No state change was applied.")
        return WorkflowTransition(audited, true, if (retry) "Step failed. A bounded manual retry is available." else "Step failed and cannot be retried automatically.")
    }

    /** Expire only steps with a non-zero runtime deadline. Human checkpoints intentionally have no timeout. */
    fun expireTimedOut(snapshot: AppSnapshot, now: Long = nowMillis()): WorkflowTransition {
        var current = snapshot
        var expired = 0
        val candidates = snapshot.jobs.flatMap { job -> job.steps.filter { it.status == "RUNNING" && it.deadlineAt > 0L && now > it.deadlineAt }.map { job.id to it.id } }
        for ((jobId, stepId) in candidates) {
            val job = current.jobs.firstOrNull { it.id == jobId } ?: continue
            val step = job.steps.firstOrNull { it.id == stepId } ?: continue
            val transition = expireOne(current, job, step, now)
            if (transition.accepted) { current = transition.snapshot; expired++ }
        }
        return if (expired == 0) WorkflowTransition(snapshot, false, "No workflow execution has exceeded its timeout.")
        else WorkflowTransition(current, true, "$expired workflow execution(s) timed out. Retry is bounded and never automatic.")
    }

    fun cancelJob(snapshot: AppSnapshot, jobId: String, actor: String = "USER", reason: String = "Cancelled by user.", now: Long = nowMillis()): WorkflowTransition {
        val integrityError = integrityError(snapshot)
        if (integrityError != null) return rejected(snapshot, integrityError)
        val job = snapshot.jobs.firstOrNull { it.id == jobId } ?: return rejected(snapshot, "This workflow no longer exists.")
        val changed = job.steps.filter { it.status in setOf("RUNNING", "PENDING") }
        if (changed.isEmpty() && job.status == "CANCELLED") return WorkflowTransition(snapshot, true, "Workflow is already cancelled.")
        if (snapshot.workflowAuditEvents.size + changed.size + 1 > MAX_EVENTS) return rejected(snapshot, "Workflow audit history is full. Export a backup before cancelling more work.")
        var updatedJob = job.copy(
            status = "CANCELLED",
            steps = job.steps.map { step ->
                when (step.status) {
                    "RUNNING" -> step.copy(status = "CANCELLED", executionToken = "", deadlineAt = 0L, startedAt = 0L, lastError = "Cancelled by user.", updatedAt = now)
                    "PENDING" -> step.copy(status = "SKIPPED", executionToken = "", deadlineAt = 0L, startedAt = 0L, updatedAt = now)
                    else -> step
                }
            },
            resultSummary = redactReason(reason),
            updatedAt = now
        )
        var current = snapshot.copy(jobs = snapshot.jobs.map { if (it.id == jobId) updatedJob else it })
        for (changedStep in changed) {
            updatedJob = current.jobs.first { it.id == jobId }
            val actual = updatedJob.steps.first { it.id == changedStep.id }
            val event = appendEvent(current, updatedJob, actual, if (changedStep.status == "RUNNING") "STEP_CANCELLED" else "STEP_SKIPPED_ON_CANCEL", actor, "Cancellation requested; any external side effect remains subject to its runtime receipt.", now)
                ?: return rejected(snapshot, "The workflow audit chain could not record cancellation. No cancellation was applied.")
            current = event
        }
        val finalJob = current.jobs.first { it.id == jobId }
        val final = appendEvent(current, finalJob, null, "JOB_CANCELLED", actor, redactReason(reason), now)
            ?: return rejected(snapshot, "The workflow audit chain could not record cancellation. No cancellation was applied.")
        return WorkflowTransition(final, true, "Workflow cancelled. Any already-started external side effect must still be checked at its destination.")
    }

    fun cancelActive(snapshot: AppSnapshot, reason: String = "Global stop requested by user.", now: Long = nowMillis()): WorkflowTransition {
        // The emergency stop is deliberately fail-safe: a full or damaged audit log must not prevent
        // revoking execution tokens. The warning is retained in activity if the event chain cannot grow.
        val ids = snapshot.jobs.filter { it.status == "RUNNING" || it.steps.any { step -> step.status == "RUNNING" } }
        if (ids.isEmpty()) return WorkflowTransition(snapshot, true, "No active workflow steps were running.")
        val activeStepCount = ids.sumOf { job -> job.steps.count { it.status == "RUNNING" || it.status == "PENDING" } }
        val canAudit = verifyAudit(snapshot) && snapshot.workflowAuditEvents.size + activeStepCount + ids.size <= MAX_EVENTS
        var current = snapshot
        for (original in ids) {
            val latest = current.jobs.firstOrNull { it.id == original.id } ?: continue
            val cancelled = latest.copy(
                status = "CANCELLED",
                steps = latest.steps.map { step ->
                    when (step.status) {
                        "RUNNING" -> step.copy(status = "CANCELLED", executionToken = "", deadlineAt = 0L, startedAt = 0L, lastError = "Cancelled by global stop.", updatedAt = now)
                        "PENDING" -> step.copy(status = "SKIPPED", executionToken = "", deadlineAt = 0L, startedAt = 0L, updatedAt = now)
                        else -> step
                    }
                },
                resultSummary = redactReason(reason),
                updatedAt = now
            )
            current = current.copy(jobs = current.jobs.map { if (it.id == latest.id) cancelled else it })
        }
        if (canAudit) {
            for (original in ids) {
                val job = current.jobs.firstOrNull { it.id == original.id } ?: continue
                for (oldStep in original.steps.filter { it.status == "RUNNING" || it.status == "PENDING" }) {
                    val step = job.steps.firstOrNull { it.id == oldStep.id } ?: continue
                    current = appendEvent(current, job, step, if (oldStep.status == "RUNNING") "STEP_CANCELLED" else "STEP_SKIPPED_ON_GLOBAL_STOP", "GLOBAL_STOP", "Execution token revoked by the global stop.", now) ?: current
                }
                val cancelledJob = current.jobs.firstOrNull { it.id == original.id } ?: continue
                current = appendEvent(current, cancelledJob, null, "JOB_CANCELLED_BY_GLOBAL_STOP", "GLOBAL_STOP", "Global stop requested; destination verification is still required for uncertain external effects.", now) ?: current
            }
        } else {
            current = current.copy(activity = (listOf(ActivityRecord(level = "WARN", message = "Global stop revoked workflow execution tokens, but workflow audit capacity/integrity prevented writing a stop event.")) + current.activity).take(500))
        }
        return WorkflowTransition(current, true, if (canAudit) "Global stop revoked active workflow tokens. Any external side effects still need destination verification." else "Global stop revoked active workflow tokens; the audit issue is recorded as a warning. Check uncertain destinations before retrying.")
    }

    /** Adds a bounded audit event for application-level mutations that already produced a new snapshot. */
    fun auditStateChange(
        snapshot: AppSnapshot,
        jobId: String,
        eventType: String,
        actor: String = "USER",
        details: String = "",
        stepId: String = "",
        now: Long = nowMillis()
    ): WorkflowTransition {
        val integrityError = integrityError(snapshot)
        if (integrityError != null) return rejected(snapshot, integrityError)
        if (snapshot.workflowAuditEvents.size >= MAX_EVENTS) return rejected(snapshot, "Workflow audit history is full. Export a backup before changing workflow state.")
        val job = snapshot.jobs.firstOrNull { it.id == jobId } ?: return rejected(snapshot, "This workflow no longer exists.")
        val step = if (stepId.isBlank()) null else job.steps.firstOrNull { it.id == stepId }
            ?: return rejected(snapshot, "This workflow step no longer exists.")
        val updated = appendEvent(snapshot, job, step, eventType, actor, details, now)
            ?: return rejected(snapshot, "The workflow audit chain could not record this change.")
        return WorkflowTransition(updated, true, "Workflow change audited.")
    }

    /** A process restart invalidates every execution token and marks interrupted work for review, never replay. */
    fun recordRestartRecovery(original: AppSnapshot, recovered: AppSnapshot, now: Long = nowMillis()): AppSnapshot {
        if (original.jobs.none { it.status == "RUNNING" || it.steps.any { step -> step.status == "RUNNING" } }) return recovered
        val requiredRecoveryEvents = original.jobs.sumOf { job ->
            val running = job.steps.count { it.status == "RUNNING" }
            if (job.status != "RUNNING" && running == 0) 0 else if (running > 0) running else 1
        }
        if (!verifyAudit(recovered) || recovered.workflowAuditEvents.size + requiredRecoveryEvents > MAX_EVENTS) {
            return recovered.copy(activity = (listOf(ActivityRecord(level = "WARN", message = "Interrupted workflows were recovered, but workflow audit integrity or capacity prevented adding recovery events.")) + recovered.activity).take(500))
        }
        var current = recovered
        for (oldJob in original.jobs) {
            val interrupted = oldJob.steps.filter { it.status == "RUNNING" }
            if (oldJob.status != "RUNNING" && interrupted.isEmpty()) continue
            val job = current.jobs.firstOrNull { it.id == oldJob.id } ?: continue
            if (interrupted.isEmpty()) {
                current = appendEvent(current, job, null, "JOB_INTERRUPTED_ON_RESTART", "SYSTEM", "Job state requires user review after process restart.", now) ?: return current
            } else {
                for (oldStep in interrupted) {
                    val currentJob = current.jobs.firstOrNull { it.id == oldJob.id } ?: continue
                    val step = currentJob.steps.firstOrNull { it.id == oldStep.id } ?: continue
                    current = appendEvent(current, currentJob, step, "STEP_INTERRUPTED_ON_RESTART", "SYSTEM", "In-flight work was not replayed; inspect destination or work product before retrying.", now) ?: return current
                }
            }
        }
        return current
    }

    fun verifyAudit(snapshot: AppSnapshot): Boolean {
        val events = snapshot.workflowAuditEvents
        if (events.size > MAX_EVENTS) return false
        var previous = GENESIS
        var expectedSequence = 1L
        val usedIds = mutableSetOf<String>()
        for (event in events) {
            if (event.id.isBlank() || !usedIds.add(event.id)) return false
            if (event.sequence != expectedSequence || event.previousHash != previous) return false
            if (event.jobId.isBlank() || event.eventType.isBlank() || event.status.isBlank()) return false
            val calculated = eventHash(event.copy(eventHash = ""))
            if (!constantTimeEquals(calculated, event.eventHash)) return false
            previous = event.eventHash
            expectedSequence++
        }
        return true
    }

    private fun expireOne(snapshot: AppSnapshot, job: WorkJobRecord, step: JobStepRecord, now: Long): WorkflowTransition {
        if (snapshot.workflowAuditEvents.size >= MAX_EVENTS) return rejected(snapshot, "Workflow audit history is full. Export a backup before recording a timeout.")
        if (step.status != "RUNNING" || step.deadlineAt <= 0L || now <= step.deadlineAt) return rejected(snapshot, "This step has not timed out.")
        val retry = step.attemptCount <= step.maxRetries && !step.requiresApproval && step.checkpointKind != "EXTERNAL_ACTION"
        val nextStep = step.copy(
            status = if (retry) "PENDING" else "FAILED",
            detail = appendDetail(step.detail, "Execution timed out at $now.", 2_000),
            lastError = "Execution deadline exceeded.",
            executionToken = "",
            deadlineAt = 0L,
            startedAt = 0L,
            updatedAt = now
        )
        val steps = job.steps.map { if (it.id == step.id) nextStep else it }
        val status = if (retry) "WAITING_FOR_USER" else if (steps.any { it.status == "RUNNING" }) "RUNNING" else "FAILED"
        val nextJob = job.copy(status = status, steps = steps, resultSummary = if (retry) "Step timed out. A bounded manual retry is available." else "Step timed out and retry budget was exhausted.", updatedAt = now)
        val base = snapshot.copy(jobs = snapshot.jobs.map { if (it.id == job.id) nextJob else it })
        val audited = appendEvent(base, nextJob, nextStep, if (retry) "STEP_TIMEOUT_RETRY_AVAILABLE" else "STEP_TIMEOUT_FAILED", "SYSTEM", "deadline=${step.deadlineAt}; retryAvailable=$retry", now)
            ?: return rejected(snapshot, "The workflow audit chain could not record the timeout. No state change was applied.")
        return WorkflowTransition(audited, true, if (retry) "Execution timed out. A bounded manual retry is available." else "Execution timed out; retry budget is exhausted.")
    }

    private fun resultingJobStatus(steps: List<JobStepRecord>): String = when {
        steps.isNotEmpty() && steps.all { it.status in setOf("COMPLETED", "SKIPPED") } -> "SUCCEEDED"
        steps.any { it.status == "FAILED" } && steps.none { it.status == "RUNNING" } -> "FAILED"
        steps.any { it.status == "RUNNING" } -> "RUNNING"
        else -> "WAITING_FOR_USER"
    }

    private fun integrityError(snapshot: AppSnapshot): String? = if (verifyAudit(snapshot)) null else "The workflow audit chain failed verification. Further workflow transitions are blocked. Export the workspace for investigation."

    private fun appendEvent(
        snapshot: AppSnapshot,
        job: WorkJobRecord,
        step: JobStepRecord?,
        type: String,
        actor: String,
        details: String,
        now: Long
    ): AppSnapshot? {
        val events = snapshot.workflowAuditEvents
        if (events.size >= MAX_EVENTS || !verifyAudit(snapshot)) return null
        val previous = events.lastOrNull()?.eventHash ?: GENESIS
        val eventBase = WorkflowAuditEvent(
            sequence = (events.lastOrNull()?.sequence ?: 0L) + 1L,
            at = now,
            actor = actor.trim().take(40).ifBlank { "SYSTEM" },
            eventType = type.take(64),
            jobId = job.id,
            stepId = step?.id.orEmpty(),
            status = step?.status ?: job.status,
            previousHash = previous,
            eventHash = "",
            details = redactReason(details).take(500)
        )
        val event = eventBase.copy(eventHash = eventHash(eventBase))
        return snapshot.copy(workflowAuditEvents = events + event)
    }

    private fun eventHash(event: WorkflowAuditEvent): String {
        val values = listOf(event.id, event.sequence.toString(), event.at.toString(), event.actor, event.eventType, event.jobId, event.stepId, event.status, event.previousHash, event.details)
        val canonical = values.joinToString("") { "${it.toByteArray(Charsets.UTF_8).size}:$it;" }
        return MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    private fun safeDeadline(now: Long, timeoutMillis: Long): Long = if (Long.MAX_VALUE - now < timeoutMillis) Long.MAX_VALUE else now + timeoutMillis

    private fun appendDetail(previous: String, addition: String, max: Int): String = (previous.trim().take(max / 2) + "\n" + addition.trim()).trim().takeLast(max)

    private fun redactReason(raw: String): String = raw.replace(Regex("(?i)(bearer\\s+)[A-Za-z0-9._~+/-]+=*")) { "${it.groupValues[1]}[redacted]" }
        .replace(Regex("(?i)((?:api[_-]?key|token|password|secret)\\s*[:=]\\s*)[^\\s,;]+")) { "${it.groupValues[1]}[redacted]" }
        .replace(Regex("[\\r\\n\\t]+"), " ").trim().take(500).ifBlank { "No further details provided." }

    private fun constantTimeEquals(left: String, right: String): Boolean = MessageDigest.isEqual(left.toByteArray(Charsets.UTF_8), right.toByteArray(Charsets.UTF_8))

    private fun rejected(snapshot: AppSnapshot, message: String) = WorkflowTransition(snapshot, false, message)
}
