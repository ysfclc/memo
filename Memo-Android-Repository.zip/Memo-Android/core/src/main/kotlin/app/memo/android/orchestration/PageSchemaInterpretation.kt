package app.memo.android.orchestration

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** A bounded semantic mapping proposed from a read-only page observation by local inference. */
data class InterpretedPageField(val index: Int, val name: String, val purpose: String)

data class PageSchemaInterpretation(
    val pagePurpose: String,
    val intentPatterns: List<String>,
    val fields: List<InterpretedPageField>
)

/**
 * Accepts only a small allowlisted subset of model output. The model cannot supply selectors,
 * actions, permissions, destinations, approval state, or executable workflow steps.
 */
object PageSchemaInterpretationParser {
    private val fieldNamePattern = Regex("^[a-z][a-z0-9_]{1,47}$")

    fun parse(raw: String, observedControlCount: Int): PageSchemaInterpretation? {
        if (raw.isBlank() || raw.length > 24_000 || observedControlCount !in 0..24) return null
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        val json = runCatching { JSONObject(raw.substring(start, end + 1)) }.getOrNull() ?: return null

        fun clean(value: String, limit: Int): String =
            value.replace(Regex("[\\r\\n\\t ]+"), " ").trim().take(limit)

        val purpose = clean(json.optString("pagePurpose"), 200)
        if (purpose.isBlank()) return null

        val intents = mutableListOf<String>()
        val inputIntents = json.optJSONArray("intentPatterns") ?: JSONArray()
        for (i in 0 until minOf(inputIntents.length(), 8)) {
            val value = clean(inputIntents.optString(i), 160)
            if (value.isNotBlank() && intents.none { it.equals(value, ignoreCase = true) }) intents += value
        }

        val fields = mutableListOf<InterpretedPageField>()
        val inputFields = json.optJSONArray("fieldSemantics") ?: JSONArray()
        val seenIndices = mutableSetOf<Int>()
        val seenNames = mutableSetOf<String>()
        for (i in 0 until minOf(inputFields.length(), 24)) {
            val row = inputFields.optJSONObject(i) ?: continue
            val index = row.optInt("index", -1)
            if (index !in 0 until observedControlCount || index in seenIndices) continue
            val name = clean(row.optString("name"), 48).lowercase(Locale.ROOT)
            val fieldPurpose = clean(row.optString("purpose"), 180)
            if (!fieldNamePattern.matches(name) || name in seenNames || fieldPurpose.isBlank()) continue
            seenIndices += index
            seenNames += name
            fields += InterpretedPageField(index, name, fieldPurpose)
        }
        return PageSchemaInterpretation(purpose, intents, fields)
    }
}
