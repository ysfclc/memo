package app.memo.android.orchestration

import app.memo.android.data.JobStepRecord
import app.memo.android.data.WorkJobRecord

/** Deterministic graph validation/readiness rules. This class never executes a step or trigger. */
object WorkflowGraphPolicy {
    private val triggerTypes = setOf("MANUAL", "SCHEDULE", "EVENT")
    private val outputTypes = setOf("TEXT", "ENTITY_LIST", "URL_LIST", "FILE", "IMAGE", "VIDEO", "BOOLEAN", "JSON")

    fun validate(job: WorkJobRecord): String? {
        if (job.graphVersion !in 1..10) return "Unsupported workflow graph version."
        if (job.steps.isEmpty() || job.steps.size > 100) return "A workflow graph must contain 1–100 steps."
        if (job.triggerType !in triggerTypes) return "Unsupported workflow trigger type."
        if (job.triggerEnabled && job.triggerType == "MANUAL") return "Manual workflows do not need an enabled background trigger."
        if (job.triggerEnabled && job.triggerConfig.isBlank()) return "An enabled schedule or event trigger needs explicit configuration."
        val ids = job.steps.map { it.id }
        if (ids.any { it.isBlank() } || ids.distinct().size != ids.size) return "Workflow step IDs must be unique and non-empty."
        val idSet = ids.toSet()
        for (step in job.steps) {
            if (step.dependsOn.size > 100 || step.dependsOn.distinct().size != step.dependsOn.size) return "A step has duplicate or excessive dependencies."
            if (step.id in step.dependsOn) return "A workflow step cannot depend on itself."
            if (step.dependsOn.any { it !in idSet }) return "A workflow dependency points to a missing step."
            if (step.maxRetries !in 0..3) return "Retries must be bounded between 0 and 3."
            if (step.timeoutMillis !in 1_000..900_000) return "Step timeouts must be between 1 second and 15 minutes."
            if (step.outputType !in outputTypes) return "Unsupported step output type: ${step.outputType}."
            if (step.conditionExpression.length > 500) return "A branch condition is too long."
            if ((step.requiresApproval || step.checkpointKind == "EXTERNAL_ACTION") && !step.requiresApproval) return "External-action steps must require approval."
        }
        val byId = job.steps.associateBy { it.id }
        val visiting = mutableSetOf<String>()
        val visited = mutableSetOf<String>()
        fun visit(id: String): Boolean {
            if (id in visiting) return false
            if (id in visited) return true
            visiting += id
            for (dependency in byId.getValue(id).dependsOn) if (!visit(dependency)) return false
            visiting -= id
            visited += id
            return true
        }
        if (ids.any { !visit(it) }) return "Workflow dependencies contain a cycle."
        return null
    }

    /** Old backups without dependency metadata retain their original sequential semantics. */
    fun dependencies(job: WorkJobRecord, step: JobStepRecord): List<String> {
        if (job.steps.any { it.dependsOn.isNotEmpty() }) return step.dependsOn
        val index = job.steps.indexOfFirst { it.id == step.id }
        return if (index > 0) listOf(job.steps[index - 1].id) else emptyList()
    }

    fun isReady(job: WorkJobRecord, stepId: String): Boolean {
        if (validate(job) != null) return false
        val step = job.steps.firstOrNull { it.id == stepId } ?: return false
        if (step.status !in setOf("PENDING", "NEEDS_REVIEW")) return false
        // Branch expressions are metadata until a deterministic evaluator exists; never expose a runnable button for an unevaluated branch.
        if (step.conditionExpression.isNotBlank()) return false
        val byId = job.steps.associateBy { it.id }
        return dependencies(job, step).all { dependencyId -> byId[dependencyId]?.status == "COMPLETED" }
    }

    fun readyStepIds(job: WorkJobRecord): List<String> = job.steps.filter { isReady(job, it.id) }.map { it.id }
}
