# Memo 1 — Implementation log and evidence ledger

This file is the durable record of decisions and verified progress for the Memo 2 → Memo 1 implementation. Append entries; do not erase failed attempts or silently rewrite status.

## Current governing state

- Target repository: `ysfclc/memo`.
- Blueprint repository: `ysfclc/memo-2` (read-only reference for this mission).
- Canonical ZIP: `Memo-Android-Repository.zip`.
- Active contract: `IMPLEMENTATION_CONTRACT.md`.
- Task-level plan: `TASKS.md`.
- Scope crosswalk: `MEMO2_ALIGNMENT_MATRIX.md`.
- Product gap evidence: `PRODUCT_GAP_REGISTRY.md`, `FEATURE_AUDIT.md`, `MEMO-PATCH1-AUDIT.md`.
- Product implementation is **not considered complete** because the package compiles or an APK is produced.

## Entry template (copy for each work package)

### YYYY-MM-DD — WP-ID / TASK-ID — short title

- **Requirement:**
- **Blueprint reference:**
- **Memo 1 baseline commit / ZIP SHA-256:**
- **Files changed:**
- **Data compatibility impact:** none / described migration:
- **Implementation summary:**
- **Tests added/updated:**
- **Commands and results:**
- **CI run URL / run ID:**
- **Exact commit SHA tested:**
- **Artifact path, size, SHA-256:**
- **Device/emulator evidence:** verified / pending / not applicable (explain):
- **Security and failure-path review:**
- **Known gaps / follow-up task IDs:**
- **Status:** `[ ]` open / `[~]` partial or awaiting evidence / `[x]` verified

## Initial entry — plan package

### 2026-10-28 — PLAN-001 — Install strict implementation governance in source ZIP

- **Requirement:** Implement the Memo 2 product ambition in Memo 1; preserve Memo 1 and use the user's personal context safely.
- **Blueprint reference:** `docs/TASKS.md`, `docs/BUILD_PLAN.md`, `docs/FEATURES.md`, `docs/ARCHITECTURE.md`, `docs/PROGRESS.md` in `ysfclc/memo-2`.
- **Files changed:** `IMPLEMENTATION_CONTRACT.md`, `MEMO2_ALIGNMENT_MATRIX.md`, `IMPLEMENTATION_LOG.md`; cross-links in `TASKS.md` and `README.md`; source checksum manifest refreshed.
- **Implementation summary:** Adds mandatory source/baseline gate, phase exit criteria M0–M6, evidence protocol, no-scope-cut rules, and a requirement-to-acceptance crosswalk. No product feature is marked implemented by this documentation change.
- **Tests and results:** Pending archive integrity and manifest/source verification in this packaging step; no Android build claimed for this documentation-only change.
- **Status:** `[~]` governance packaged; G0 source reconciliation and actual implementation remain open.

### 2026-10-28 — WP-02 through WP-07 — context execution and guarded artifact workflows

- **Requirement:** Implement concrete vertical slices from the full Memo product plan within Memo 1 without replacing the app shell, vault identity, or stored-data compatibility.
- **Blueprint reference:** `TASKS.md` context routing, capability compiler, Self Model, encrypted backup, live execution/stop and human-review requirements; `MEMO2_ALIGNMENT_MATRIX.md` M0–M6 crosswalk.
- **Memo 1 baseline commit / ZIP SHA-256:** Repository branch upload commit observed: `4df5bcddb7572fee9a2d8fe8a599ecc24ebc8b1b`. Working source is a derived local ZIP snapshot; final repack SHA-256 is recorded separately with the delivered archive.
- **Files changed:** Added core `WorkspaceContextRetriever.kt`, `CapabilityCompiler.kt`, `SelfModelFactualityGuard.kt`, `EncryptedBackupCodec.kt` and associated tests; modified `IntentPlanner.kt`, `MemoWorkspaceViewModel.kt`, `WorkspaceScreens.kt`, `MemoWorkspaceApp.kt`, `OpenAiCompatibleClient.kt`, `AiRuntimeViewModel.kt`, localization catalog; updated task, audit, gap, README, changelog and governance docs.
- **Data compatibility impact:** No persisted model schema bump in this increment. Existing primary vault filenames, Keystore aliases, app ID and workflow vault are preserved. Encrypted backup is a new portable format and does not replace the on-device vault.
- **Implementation summary:** Adds bounded source-linked workspace retrieval for Work prompts; lets an untouched DRAFT plan regenerate safely; compiles task intents into registered capability IDs with stable manifest fingerprint and permission/approval state; adds narrow unsupported numeric/date claim flags for Self Model drafts; adds authenticated, bounded AES-256-GCM passphrase backup/restore; adds incremental compatible remote response streaming and best-effort active-connection cancellation. Remote use of workspace context is still separately opt-in.
- **Tests added/updated:** `CapabilityCompilerTest`, `WorkspaceContextRetrieverTest`, `SelfModelFactualityGuardTest`, `EncryptedBackupCodecTest`, planner/outcome tests.
- **Commands and results:** Pure Kotlin helper compilation via local `kotlinc`: PASS. Manual smoke harness for deterministic capability manifest / optional Android status / external approval: PASS. Context retrieval/provenance/action gate/factuality harness: PASS. Encrypted backup round-trip, plaintext absence, wrong-passphrase rejection and tamper rejection: PASS. Final `python3 tools/verify_source.py`: PASS (32 integration files, Android isolation and wiring checks, XML/manifest, EN/PL/TR static UI catalog 363/363). Remote runner tests: 12/12 PASS from `remote-runner/` working directory. Android Gradle, Android unit tests, lint and device/runtime behavior are not claimed by these source/helper checks.
- **CI run URL / run ID:** `https://github.com/ysfclc/memo/actions/runs/40704538951` was triggered on uploaded source; no CI result is used as evidence for these feature claims.
- **Exact commit SHA tested:** Local working source includes additional edits not contained in upload commit `4df5bcddb7572fee9a2d8fe8a599ecc24ebc8b1b`; do not treat that commit as testing these later edits.
- **Artifact path, size, SHA-256:** The final archive is `/mnt/data/Memo-Android-Repository.zip`; byte size and archive SHA-256 are in the adjacent `.sha256.txt` receipt supplied with the package. The archive hash is kept outside the ZIP to avoid a self-referential checksum.
- **Device/emulator evidence:** Pending.
- **Security and failure-path review:** Backup authenticates header and ciphertext before JSON decode/replacement; password and transient byte arrays are cleared on completion/error paths; context output is bounded and marked untrusted; external action steps cannot be started through the generic plan runner. Remote stream cancellation is best-effort and must not be confused with proof the server stopped computing.
- **Known gaps / follow-up task IDs:** Unified stores and migration/rollback, source-file and multi-file share intake, local ASR/TTS and model backend breadth, generic cross-runtime DAG, full versioned skill/tool/surface registry, restore preview, remote idempotency receipts, and device acceptance remain open.
- **Status:** `[~]` partial feature implementation; full M0–M6 scope remains open.


### 2026-10-28 — WP-08 / M2.B0a, M2.B0d, M3.6.B1, M3.7.C1 — Today command centre and voice-first capture UX

- **Requirement:** Reduce friction between thought capture and useful next action; make unfinished work, review obligations and runtime/privacy status visible; improve UI hierarchy without creating a second navigation system.
- **Blueprint reference:** `TASKS.md` M2.B0 design system, M3.6 language support, M3.7 everyday product; `IMPLEMENTATION_CONTRACT.md` UX and evidence rules.
- **Baseline:** Current canonical upload snapshot in the working package; this is a derived source package, not a claim that local changes are on the GitHub branch until the user uploads the next ZIP.
- **Files changed:** `app/src/main/java/app/memo/android/ui/MemoWorkspaceApp.kt`, `MemoLocalization.kt`, `app/src/test/java/app/memo/android/ui/MemoLocalizationTest.kt`, `tools/verify_source.py`, `TASKS.md`, `CHANGELOG.md`, `FEATURE_AUDIT.md`, `PRODUCT_GAP_REGISTRY.md`.
- **Implementation summary:** Home is presented as Today with review count and truthful runtime signals; tap-to-talk fills the editable composer; three text-only workflow starters are available; non-terminal jobs are surfaced with review/waiting/failure states prioritized; new copy has EN/PL/TR entries. Voice recognition remains platform-service dependent and never auto-submits.
- **Data compatibility impact:** none; no persistence schema or vault paths changed.
- **Tests and results:** `python3 tools/verify_source.py` passes including source integration, one-Activity boundary, 360/360 catalog coverage for static UI text requiring translation, and updated Today/voice markers. Gradle compilation could not be run in this environment because the pinned Gradle distribution download failed at DNS resolution; this is not treated as product acceptance. Device/Compose visual behavior is pending.
- **Security and failure-path review:** no new background microphone service; no silent capture; recognition failure is shown to the user; speech remains editable; no action or message is sent by voice capture alone. Templates are prefilled prompts, not simulated capabilities.
- **Known gaps / follow-up:** continue M2.B0 design-system pass (motion/reduced-motion, haptics, 48dp and 200% font audit), full responsive/large-screen UI, real local ASR/TTS, Quick Settings/launcher capture, source attachment ingestion, Today briefing and quiet-hours controls.
- **Status:** `[~]` UI/UX slice implemented; full roadmap remains open.


### 2026-10-28 — WP-09 / M3.7.B2 — Bounded text-source intake

- **Requirement:** Bring user-selected source files into Memo's Evidence store with traceable provenance and explicit limits, without pretending unsupported formats were extracted.
- **Blueprint reference:** `TASKS.md` M3.7.B1/B2 and `PRODUCT_GAP_REGISTRY.md` source handling requirements.
- **Files changed:** `app/src/main/java/app/memo/android/ui/MemoWorkspaceApp.kt`, `app/src/main/java/app/memo/android/ui/MemoLocalization.kt`, `app/src/test/java/app/memo/android/ui/MemoLocalizationTest.kt`, `TASKS.md`, `IMPLEMENTATION_LOG.md`, `FEATURE_AUDIT.md`, `PRODUCT_GAP_REGISTRY.md`, `CHANGELOG.md`, `tools/verify_source.py`.
- **Implementation summary:** Added a multi-document picker reachable from Today; accepts text-based MIME types or recognized text extensions, at most 10 sources per selection and 256 KiB per file, rejects empty/binary-looking/unsupported files, computes SHA-256, records MIME/size/import method/immutable-original metadata, saves source text into Evidence, then navigates to Evidence. Failures are reported instead of silently omitted.
- **Data compatibility impact:** no schema change; new `IMPORTED_SOURCE` evidence kind uses the existing Evidence record.
- **Tests and results:** `TextSourcePolicy.kt` compiles independently with `kotlinc`; a smoke harness passes supported text, stable SHA-256, unsupported-PDF and oversized-file cases. Structural verifier and 12/12 remote-runner tests pass; source checksum manifest verified. Android Gradle compilation could not be run in the editing environment due unavailable Gradle distribution download; device import behavior remains pending.
- **Security and failure-path review:** bounded byte reads prevent unbounded file allocation; extension/MIME checks and control-byte screening reject unsupported/binary content; no external provider receives imported content automatically; source hashes make exact imported bytes identifiable. Imported content remains local evidence. The current 256 KiB/UTF-8 limit is explicit.
- **Known gaps / follow-up:** PDF text extraction, OCR/image/screenshot capture, audio/video transcription, multi-file content chunking, deduplication, durable source URI permissions, review inbox semantics and share-sheet ACTION_SEND_MULTIPLE integration remain open.
- **Status:** `[~]` bounded text intake implemented in source; multimodal ingestion remains open.


## WP-10 — Private quick capture from Today
- Added a dedicated save-to-Evidence action beside the existing Plan & start and Ask in chat actions.
- Quick capture preserves the user's exact trimmed text as a `QUICK_CAPTURE` EvidenceRecord, adds local-only provenance metadata, and routes directly to Evidence.
- Saving is distinct from AI chat and job planning; no model or external action is invoked by this path.
- Validation pending: full Android compilation and device persistence must be confirmed in GitHub Actions/device testing before this work package can be marked complete.
