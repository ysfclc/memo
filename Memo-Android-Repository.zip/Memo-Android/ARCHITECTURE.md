# Memo Android — Architecture and implementation notes

## Product boundary

Memo is one local-first workspace, not a collection of independent mini-apps. Talk, Browse, Apps, Work, Library, People & opportunities, and Studio share one encrypted vault, the same domain records, and a common visual system. Specialized workflows are views over the same evidence and records rather than separate databases.

The first delivery is Android-only. The native app is written in Java/Kotlin with a native view-based UI. That is the appropriate reuse path for the inherited Android runtime because it preserves the existing AccessibilityService, WebView, LiteRT-LM, Android Keystore, biometric prompt, and durable run state without wrapping them in a second mobile runtime.

## Layers

```text
Android Activity / Native UI
  ├── Talk / shared chat
  ├── HTTPS WebView workspace
  ├── App inventory and live app assistance
  ├── Tasks / workflows / job and run history
  ├── Library / records / Studio
  └── Model discovery / settings
          │ typed domain operations
          ▼
Domain and execution layer
  ├── JobCompiler + SkillRegistry
  ├── PlanProposalParser
  ├── WorkflowPolicy + AccessibilityService
  ├── DeviceAiScanner + LocalModelRuntime
  └── CaptureRecord + MemoRecord + Task/Workflow/Run records
          │ single local persistence boundary
          ▼
SynthStore (legacy class name retained for migration safety)
  ├── AES-GCM encrypted JSON vault
  ├── Android Keystore key
  ├── schema migration / atomic replacement
  └── no backend required for core operation
```

### Why the storage class still has an old internal name

`SynthStore` and existing preference namespaces remain named for compatibility with the inherited vault and settings. The user-facing product is branded Memo. Renaming encrypted storage aliases during a refactor could strand existing local data, so the internal name is deliberately retained until a tested migration is designed.

## Unified domain records

`SynthStore` owns the data boundary. It stores chat messages, tasks, app-capability observations, jobs, workflows, execution runs, captures, and the unified `MemoRecord` collection. The current `MemoRecord` kind values are:

| Kind | Role | Key fields |
|---|---|---|
| `contact` | Person or relationship | title, subtitle, notes, HTTPS source, status |
| `company` | Organization | title, subtitle, notes, HTTPS source, status |
| `opportunity` | Job, deal or other opportunity | title, role/deal descriptor, notes, HTTPS source, status |
| `project` | Durable project context | title, descriptor, notes, HTTPS source, status |
| `studio_draft` | Private editable content | title, format/destination, body, status, optional source |

Each saved source has its own ID, provenance label, package/URL and capture time. A record can link to the source capture by ID and to an HTTPS URL. The current schema limits local captures to 200 and unified records to 500; the newest records are shown first. Records are intentionally extensible and not a rigid universal CRM schema.

The current relation strategy is pragmatic: a record may link to its source and is passed as bounded context to the local model. This version does not yet provide a first-class general-purpose graph edge table, deduplication engine, arbitrary relationship editor, or multi-device sync. Those are not implied by the UI.

Schema updates are additive. Existing encrypted vaults missing `captures` or `records` get empty arrays during load, so this change does not require wiping previous Memo/SynthOS data.

## Local AI path

1. A user submits a request in Talk or starts a supported workflow action.
2. `SkillRegistry` selects bounded, versioned instructions.
3. `JobCompiler` assembles the user request, a small conversation tail, launchable app metadata, an optional latest app observation, known capabilities/tasks, and up to 16 saved records.
4. `LocalModelRuntime` invokes the explicitly selected on-device model. No response is fabricated when no model is configured or inference fails.
5. `PlanProposalParser` validates the response format and turns only allowed proposals into structured review objects.
6. Tasks are durable user-visible records; UI workflows remain subject to policy validation and explicit approval. Producing a plan is not the same as having executed it.

The built-in local runtime currently accepts compatible `.litertlm` models only. The device scanner can recognize `.gguf`, `.tflite`, `.task`, `.onnx`, `.safetensors`, `.ggml`, and `.pte` files as candidates, but does not claim those formats can run in Memo.

## Device AI discovery

The scan has three stages:

1. Query installed launchable apps and match known local inference or AI assistant names/package tokens.
2. Query Android's shared `MediaStore.Files` index for candidate model extensions and inspect Memo's own model library.
3. If, and only if, the user explicitly enables Android's **All files access**, conduct a bounded (100,000 directory-entry maximum; 18 directory levels) filename/size scan of shared storage. It skips cache/hidden directories and `Android/data` / `Android/obb` paths.

The scan does not open model data during discovery and sends nothing to a server. Import is separate, size-limited to 6 GiB, copied into Memo's private model directory, hashed, and kept separately from other models. It does not inspect other apps' private internal storage; Android's application sandbox forbids this for ordinary apps. The broad storage permission is sensitive and subject to Google Play distribution policy; check eligibility before publishing.

## Browse and native apps

### Web browsing

The in-app browser uses Android WebView, with HTTPS-only top-level navigation, mixed content blocked, file/content URL access disabled, Safe Browsing enabled, and no JavaScript bridge. JavaScript and DOM storage are enabled for modern web-app compatibility. User-gesture popup windows are hosted in child WebViews/dialogs inside Memo. A single document picker is used only when a site asks the user to upload a file. The browser can inspect bounded visible page text, links and control labels, then save user-selected evidence to the Library. Editable values are never extracted by the page-inspection command.

Cookies are used for normal browser session behaviour; sites may still block WebView authentication, use passkeys/biometrics differently, require system-browser-only authentication, or prohibit embedded browsing. The app does not attempt to bypass those restrictions. Navigation and file upload remain explicit user actions.

### Installed native apps

Memo lists launchable apps and can open one while using Android's AccessibilityService to observe exposed UI labels. A floating action panel overlays the actual target app. This is not a hidden in-process embedding of arbitrary app views. Apps using custom drawing, protected windows or inaccessible controls may expose little UI. Memo must not claim every app is fully controllable or readable.

The global floating assistant is opt-in; its collapsed bubble stays available across app transitions while enabled and offers Talk, Browse, Capture, Task, Work and Library. Capture is user-triggered, not automatic. A normal native app cannot force-overlay all apps; Android requires the user to grant overlay permission and Accessibility access separately. On lock, the overlay is removed and active workflows pause.

## Privacy / security

- Device-credential or biometric prompt, with secure-device requirement.
- Android Keystore-backed key used for AES-GCM local vault encryption.
- Atomic vault persistence and additive migration of newly introduced arrays.
- Android app backup disabled.
- Secure window flag on Memo's own screens.
- No mandatory account/backend or ambient upload.
- Remote guest execution is optional and off until a trusted endpoint is configured. It sends only an explicitly approved workflow definition/policy envelope, not chat history or model prompt context.
- Text shared from the Android share sheet is saved only following an explicit Share-to-Memo action and after the encrypted workspace is unlocked.

Security caveat: an unlocked, rooted/compromised device and its owner-granted powerful Accessibility/All files permissions are outside the protection guarantee. All-files access should not be silently activated.

## Motion and UI system

The UI uses `DesignSystem` tokens for typeface, colors, shape, spacing and haptic/press transitions. Screen changes use a short fade/vertical settle, cards are grouped in consistent surfaces, and state labels describe actual run or record state. Motion respects the existing animations setting. The primary use cases are designed as scrollable mobile screens; the browser uses the available content height and honors Android's keyboard resize behaviour.

## Background and real-time behaviour

- Inference and device scans use bounded background threads and return to the UI thread for updates.
- Workflow execution is step-based, stateful, and checks the lock screen and foreground target before interacting with another app.
- Interrupted jobs/runs are recovered into review/paused states instead of being silently replayed.
- There is no cloud realtime bus or mandatory background sync in this build. Android background execution is constrained by the OS; durable long-running tasks should eventually use WorkManager or a deliberately designed foreground-service workflow rather than rely on a forever-running Activity.

## Build status and known constraints

This implementation was created by integrating the available Android source, not by copying the HTML prototype. Static text/manifest checks are possible in this workspace, but a native APK build requires Android SDK Platform 35, Build Tools 35.0.0, Gradle 8.9, JDK 17+ and dependency resolution. The current build container did not include the Android SDK, `android.jar`, or an installed Gradle distribution. The included custom `gradlew` bootstrapper attempted to download Gradle 8.9, but the environment could not resolve `services.gradle.org`. Therefore APK compilation, `lint`, emulator/device tests and end-to-end login checks are **not verified here**. This is an explicit limitation, not a claimed build success.

Before release, run a real-device acceptance pass for:

- Fresh install, lock setup and authentication, app update and vault migration.
- Local model import, checksum storage, inference success/failure/recovery and memory pressure.
- WebView sign-in, redirects, passkeys, cookies, popups, uploads, downloads and file handling.
- Share sheet, Library save/delete, record/draft editing, clipboard, record limits and source linkage.
- Optional All files access grant/deny and the 100k scan limit.
- Accessibility/overlay grant/deny, display position, system permission windows, target switching, lock/unlock, accessibility-only apps, and stop/recovery of each workflow step.
- External guest runner disabled-by-default and safe handling of timeouts/unknown outcomes.

App boundary: supported web companions are opened in Memo Browser. Arbitrary native third-party app UI remains Android-owned and is assisted by the opt-in floating panel; it is not falsely represented as embedded.
