# Product gap registry — prioritized, with acceptance criteria

Memo should feel like a capable, safe execution partner, not a collection of buttons. These are product gaps inferred by comparing every supplied build with the intended end state; the user does not need to discover each gap one by one.

Priority meanings: **P0** release blockers; **P1** core product capability; **P2** expansion that depends on stable core execution.

## P0 — make the current build trustworthy

- [ ] **Android CI is green.** The exact source ZIP builds with Android unit tests and lint; APK is present, hashed and downloadable as the workflow artifact.
- [ ] **Real-device acceptance.** First-run/unlock, keyboard resize, share-in, local inference, remote-consent rejection, notifications and Accessibility pause/stop behaviors are exercised on at least one Android device.
- [ ] **Data-store migration strategy.** Document which encrypted vault owns each data class; add schema version, backup-before-migration and rollback; eventually converge on one transaction/event boundary without discarding older data.
- [ ] **Reliable action ledger.** Every workflow action has run/step IDs, start/finish/timeout, status, evidence/postcondition, error category and explicit user-approved external effects. App restart leaves an inspectable interrupted run.
- [ ] **External side-effect safety.** Use destination-bound approval previews, artifact hash, idempotency key or receipt where supported. If outcome is uncertain, pause for review rather than auto-send/re-submit.
- [ ] **Encrypted backup.** Offer an encrypted export with a user-selected passphrase/recovery path, schema version, integrity check and restore preview. Keep plaintext JSON export explicitly labelled if retained.
- [ ] **Permission & privacy audit.** Explain all permissions at point of use; never read screen content/clipboard/microphone silently; keep lock-screen notification bodies generic.

## P1 — cohesive day-to-day product

- [ ] **Unified workflow graph.** DAG with named steps, dependencies, typed inputs/outputs, retries/timeouts, checkpoints, cancellation, conditional branches, and durable state. A workflow can combine local AI → visible frontier website → native app → review → measurement.
- [ ] **Versioned capability registry.** Store editable agents, skills, prompts, tool schemas, app/browser surface schemas and permissions. Each run pins exact revisions and records what actually executed.
- [ ] **Generic browser surface engine.** Per-site versioned DOM/semantic selectors, state signatures, page-change alert, action budget, evidence screenshot/text, postconditions and replay fixtures. Provider scripts remain adapters, not the whole automation model.
- [ ] **Workflow gallery/editor.** Searchable reusable blueprints, inspect-before-run plan, permission summary, inputs, generated artifacts, per-step log, recovery/redo and revision diff; no buttons that pretend to work without a connected executor.
- [ ] **Reminders and task scheduling.** Local task due-date reminders, snooze/complete actions, quiet hours, daily nudge, missed/overdue review, timezone/reboot handling. Current daily nudge is only the first layer.
- [ ] **Voice entry.** Keep tap-to-talk with editable transcript; add a one-tap notification/launcher/Quick Settings entry into voice capture and a spoken-confirmation step before risky actions.
- [ ] **Optional wake word, only after a proper privacy design.** User opt-in, visible foreground service/notification, on-device wake-word model, mic indicator, hardware/battery controls, immediate off switch and documented OS limitations. Do not promise a magic always-on assistant across locked devices; Android restricts background microphone service starts.
- [ ] **Model discovery and install.** One-tap catalogue for supported formats with exact compatibility, hash, size, storage/RAM checks, download resume/cancel/rollback and clear statement that installed third-party app models may not expose APIs Memo can call.
- [ ] **Pocket-style source handling.** `ACTION_SEND_MULTIPLE`/URI imports, file size/type limits, review inbox, immutable original capture, derived working copy, source hash/URL/timestamp, per-mission/context selection and versioned backup.
- [ ] **Capture that produces traceable records.** Quick text, share sheet, voice, image/screenshot and selected text; every capture has original source, extraction results, provenance and a review step before it changes the graph.
- [ ] **Private draft → public-safe studio.** Drafts, claims/evidence check, media/carousel storyboard, generated asset provenance, channel-specific preview, destination-bound human approval, post receipts and later engagement measurements.

## P2 — the powerful “arms and hands” expansion

- [ ] **CRM and relationship flows.** From voice or text, create person/org/meeting, link entities, deduplicate, gather evidence-backed enrichment and queue follow-up tasks. Proposed mutations remain reviewable.
- [ ] **Job discovery/application workflow.** Search configured sources, create job entities, explain match criteria, deduplicate and approve a shortlist, then fill applications with a complete preview and explicit submit approval. Never claim an application was submitted without receipt/evidence.
- [ ] **Content performance loop.** After user-approved publication, collect permitted channel metrics, link data to the exact post/version, compare outcomes, preserve evidence and use measurements to refine future drafts.
- [ ] **Multimodal source pipeline.** Text, PDF, documents, images, OCR, screenshots, video frames, audio transcripts and generated assets, with file limits and local/cloud privacy routing made explicit.
- [ ] **Measurement and optimization loop.** Every goal defines observable success metrics, data source, sampling schedule, limits and review interval. Optimizations remain proposals until authorized.
- [ ] **Cross-device execution and secure pairing.** Mutually authenticated pairing, device scopes, expiring capabilities, revocation, signed run manifests, heartbeat, audit and remote cancellation. Do not launch a hosted service without explicit deployment/consent.
- [ ] **Accessibility and power-user controls.** VoiceOver/TalkBack semantics, keyboard support, scalable text, offline states, reduce-motion preference, permission diagnostics, battery/thermal notice and visible system state.

## Notification policy

- Current implementation: local Android notifications and daily reminder only, user-controlled, generic/private body. This requires notification permission on Android 13+. No push server exists in this build.
- Optional future remote push: only when paired remote execution or a hosted service is actually deployed. Use a minimal opaque event ID; fetch details after the device is unlocked; no private prompt or model output in push payloads; opt-in, revoke, delete-token and auditable delivery.

## Voice policy

- Current implementation: user taps mic, platform recognizer fills an editable chat draft; it is not guaranteed offline and does not run continuously.
- Future wake-word: implement only if on-device detection, OS-compliant foreground operation, visible mic state, configurable sensitivity and true battery/privacy tests are available. Android 12+ background foreground-service starts are restricted; newer versions also constrain microphone while-in-use access. Tap-to-talk is the reliable baseline.


## Additional product features worth planning now

These additions are derived from the combined source inventory and the design blueprint. They are roadmap items, not claims about the current implementation.

- [ ] **Approval inbox and action queue.** One place to review pending proposed records, browser actions, native runs and publication drafts. Each card shows destination, exact payload, source evidence, risk, and the specific permission required. Approvals expire and are invalidated when the target or payload hash changes.
- [ ] **Global pause / emergency stop.** Stop new work; request cooperative cancellation from active runtimes; expose any action whose outcome remains unknown. A stop must not falsely imply that an already-submitted third-party action was rolled back.
- [ ] **Notification deep links and safe actions.** Notifications should open the exact run/review screen and can later offer Pause, Review, Snooze or Mark done where semantics are safe. Keep private content out of notification text; re-authenticate before showing protected details.
- [ ] **Quick capture entry points.** Add launcher shortcuts, Android Quick Settings Tile and a notification action for explicit voice/text capture. These are better first steps than always-listening wake detection and work within normal user-triggered permission boundaries.
- [ ] **Privacy profiles and context allowlists.** Define per-workflow/per-project what can leave the device (none, selected excerpts, selected files, explicit full handoff), and make the payload visible before transmission. Remote-provider consent should not be remembered globally by accident.
- [ ] **Model readiness diagnostics.** Before installing or running a local model, check format compatibility, free storage, approximate memory requirements, accelerator availability, checksum, license/source, warm-up result, cancellation and rollback. A downloaded model is not a working model.
- [ ] **Record integrity tools.** Search duplicate candidates, preview reversible merge/relink actions, preserve the archived source record and provenance, and let the user undo accidental links. Add export/restore fixture tests before changing the schema.
- [ ] **Workflow test fixtures.** Allow developers/power users to replay captured, sanitized page/app states against a versioned schema without performing external side effects. Fixture success must be distinguished from a live-device success.
- [ ] **Offline queue with explicit routing.** Save work while offline, show which steps can be completed locally, and ask before remote providers are used when connectivity returns. Never silently substitute remote inference for a failed local model.
- [ ] **Goal measurement contract.** For each measurable workflow, define the metric, source, sample period, threshold and stopping rule. Preserve the observed numbers and their source; present optimizations as proposals until accepted.
