# Memo import history

GitHub Actions appends one immutable record to `notes/imports/` for every successfully integrated `incoming/memo.zip` upload. These notes are preserved across source snapshot imports.
