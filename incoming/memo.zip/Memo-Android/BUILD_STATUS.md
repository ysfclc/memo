# Build and verification status — 28 October 2026

## Verified in the current source workspace

- `python3 tools/verify_source.py`: passed. Checks required integration files, confirms the `:core` module contains no Android framework imports, parses Android XML, checks microphone/notification/boot permissions and receivers, verifies language/notification catalog markers, and confirms CI accepts only the canonical ZIP, verifies its per-file SHA-256 manifest, checks the Memo-only launcher boundary, and includes core/app test, lint, and APK tasks.
- `python3 -m unittest discover -s tests -v` from `remote-runner/`: **12/12 tests passed**. Tests cover bearer-token authentication, explicit approval, workflow bounds, sensitive-text rejection, durable interrupted-job status, and final postcondition verification.
- All **10 Android XML files** parse successfully.
- The current source tree contains the persisted English/Polish/Turkish language preference, exact-string translation catalog/tests, tap-to-talk input, local notification center, daily reminder scheduling, workflow status notifications, and their manifest permissions/receivers.
- Cross-build feature inventory exists in `FEATURE_AUDIT.md`; priorities and acceptance criteria exist in `PRODUCT_GAP_REGISTRY.md`.

## Not verified — do not claim as passed

- Android/Kotlin compilation, Gradle JVM tests, Android lint, APK assembly, emulator tests, Accessibility behavior, real-device voice recognition, notifications, app automation, and remote paired-device behavior.
- I attempted `./gradlew --version`; its pinned Gradle download failed because this environment could not resolve `services.gradle.org`. No Android SDK/Gradle installation is available to finish the build locally.
- No APK is included or claimed to have been built. Use `.github/workflows/build-apk.yml` in GitHub Actions as the build gate, then install the resulting APK and complete `DEVICE_ACCEPTANCE_CHECKLIST.md`.

## Current release status

**Development source package; not release-certified.** Do not distribute as production-ready until Android CI is green, real-device acceptance is complete, the remaining product gaps are reviewed, and release signing/security checks have been completed.


## Director's Cut source reset — 28 October 2026

- Replaced the old duplicate Activity UI with `app.memo.android.runtime.MemoRuntimeBridge`; the accessibility service now reports status through Memo's listener boundary.
- Recentered the home experience on unsent conversational capture, linked records/sources, review attention and work continuity.
- Renamed active Compose app, viewmodel and design-token entry points to Memo-specific names. Extracted platform-independent domain contracts and deterministic rules into a new `:core` JVM module. Existing encrypted-vault aliases and filenames are intentionally unchanged.
- Updated `tools/verify_source.py` to cover the new product boundary and prompt handoff.
- Local Gradle compilation remains unavailable in this environment because the wrapper distribution cannot be downloaded. Run the delivered GitHub Actions workflow before treating this archive as build-verified.


## 28 October 2026 — exact-content approval slice

### Verified in this workspace

- `python3 tools/verify_source.py`: passed after adding the exact approval dialog's Polish/Turkish strings. Static translation scan: 283/283 eligible literal `Text()` labels across six scanned Compose UI source files have catalog entries.
- `PYTHONPATH=. python3 -m unittest discover -s tests -v` from `remote-runner/`: 12/12 passed. (Running the same discovery command from the project root fails because `server` is imported relative to `remote-runner/`; use the command above.)
- The actual `ActionApprovalLedger.kt` compiled with `kotlinc` in an isolated harness using minimal snapshot/evidence stubs. That harness passed proposal → approval → begin execution → evidence-backed completion, missing-evidence review, changed-payload invalidation, and audit-tamper detection. This validates the ledger logic's tested branches, not the Android/core integration or JSON codec.
- Added `ActionApprovalLedgerTest.kt` and schema v4 round-trip/tamper test. These tests have **not** been run through Gradle yet. Added `ActionApprovalInboxScreen.kt` under More with queue/review/history filters, exact-payload/audit inspection, rejection, guarded routing to a matching live browser approval, and explicit review for uncertain outcomes. The inbox cannot approve saved history.

### Blocking verification

- `./gradlew :core:test --offline --no-daemon` could not run because the Gradle wrapper attempted to download Gradle 8.14.6 and DNS resolution for `services.gradle.org` failed. Kotlin compilation of the full project, core JSON tests, Android unit tests, lint and APK build remain unverified.
- Browser WebView behavior and exact prompt approval must be tested on a real device after CI compilation passes. Global pause/stop and adoption of the shared ledger by native/guest/publication runtimes remain open product tasks. The new central inbox still needs Android compile and device acceptance.


## 2026-10-28 source increment

The action inbox and first top-level stop control are present in source. Static/source verification and guest runner tests are not substitutes for Kotlin/Compose compilation. Full Gradle testing remains blocked locally by the unavailable Gradle distribution download; no APK or device acceptance is claimed.

## 30 October 2026 — intent-routing regression correction

- Corrected planner precedence so explicit automation intent is routed to AUTOMATION before the generic Android/app BUILD keyword. Optional Android capabilities remain marked `OPTIONAL_PERMISSION`; no permission is granted by planning.
- Added regression coverage for automation-in-an-Android-app and preserved the existing ordinary app-build classification check.
- Re-ran `python3 tools/verify_source.py`: passed. Re-ran `PYTHONPATH=. python3 -m unittest discover -s tests -v` from `remote-runner/`: 12/12 passed.
- The Gradle `:core:test` task was not locally executable because the pinned Gradle 8.14.6 distribution could not be downloaded (`services.gradle.org` DNS unavailable). The GitHub Actions Android test/lint/debug APK gate remains required. This package is not release-certified.

