# Memo Android — complete repository bundle

This ZIP contains the complete `Memo-Android/` Android project and the repository-root GitHub Actions workflow at `.github/workflows/build-apk.yml`.

## Apply it to the existing GitHub repository

1. Download and extract this ZIP.
2. Copy/replace the included `Memo-Android/` directory and `.github/workflows/build-apk.yml` into the root of your repository.
3. Commit the changed files, then run **Actions → Build Memo APK**.

The Android source includes the nullable `Workflow?` handling fix, the missing `android.content.Intent` import, and an explicit Android 13+ `POST_NOTIFICATIONS` permission check before posting notifications.

The workflow pins Gradle 8.14.6 and installs Android SDK packages without requesting the removed `tools` package. It runs the remote-runner unit tests, Android unit tests, lint, and debug APK assembly, then uploads the APK as an Actions artifact.

## Verification status

The ZIP structure and source checks are verified locally, and the remote-runner test suite is run before packaging. The latest GitHub run compiled Kotlin, compiled Java, ran Android unit tests, and assembled the debug APK, but failed on the notification-permission lint finding. This bundle addresses that specific lint finding. A successful end-to-end GitHub Actions run is still required to confirm the APK artifact.
