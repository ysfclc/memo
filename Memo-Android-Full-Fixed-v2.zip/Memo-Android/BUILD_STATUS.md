# Build status

- Gradle 8.14.6 is pinned in the wrapper and workflow.
- Android SDK setup avoids the removed `tools` package.
- The prior GitHub run reached Kotlin compilation, Java compilation, unit tests, and `assembleDebug`; its sole reported lint error was `MissingPermission` at notification posting.
- The source now checks `POST_NOTIFICATIONS` on Android 13+ before posting and checks whether notifications are enabled.
- A fresh GitHub Actions run is required to verify that lint passes and the APK artifact is uploaded.
