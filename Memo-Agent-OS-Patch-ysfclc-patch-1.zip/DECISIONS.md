# Decisions

## 2026-10-30 — Repository and workflow
- **Active target:** `ysfclc-patch-1`.
- **Out of scope:** `memo-2`; do not inspect for implementation reuse or modify unless explicitly authorized.
- **Handoff format:** deliver Agent OS documents as a separate ZIP so the user can apply them without replacing the existing Android source archive.
- **Source integrity:** retain the existing app ZIP and checksum/verification process until its contents are understood.
- **CI contract:** preserve Java 17, Android SDK 35/build-tools 35.0.0, Gradle 8.13, `:core` and `:app`, and the repository's tests/lint/assembly checks.

## 2026-10-29 — Product direction
- Memo is browser-first. Browsing content and the active website should occupy the primary workspace.
- Memo actions should be a compact floating affordance, not a large persistent panel that steals browsing space.
- Explore the browser as a universal adapter for agent interaction with visible interfaces. Do not bypass sign-in, access controls, user confirmation, or site protections.
- The LinkedIn Google-login issue is a user-reported reproduction target, not a confirmed root cause or universal platform defect.
