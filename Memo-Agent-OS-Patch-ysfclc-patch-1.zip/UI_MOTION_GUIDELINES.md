# UI & Motion Guidelines

## Core principle
The browser is the product's primary workspace. Memo's intelligence should feel close at hand without taking over the page.

## Layout
- Give the active web page the dominant share of available space.
- Keep Memo's main action as a small, discoverable floating affordance or similarly compact control.
- Open larger agent/task surfaces only when the user invokes them; make them dismissible and preserve browser context.
- Respect mobile safe areas, keyboard insets, orientation changes, and touch ergonomics.

## Visual quality
- Use a coherent design system for typography, spacing, radii, elevation, color, and iconography.
- Establish clear hierarchy: page first, contextual Memo controls second, supporting metadata third.
- Avoid generic dashboard patterns, excessive cards, decorative gradients without purpose, and dense permanent toolbars.
- Provide clear focus, pressed, selected, disabled, and destructive states.

## Motion
- Use motion to explain transitions, reveal context, and confirm state changes.
- Prefer short, purposeful opacity/transform transitions with consistent easing.
- Avoid animating layout in ways that cause page jumps or interfere with browser gestures, text selection, scrolling, or keyboard use.
- Respect reduced-motion preferences and avoid continuous attention-grabbing animation.

## Interaction and state
Every interactive control must have real behavior. Implement and design for loading, empty, error, offline, permission-denied, authentication-required, and success states where applicable. Never show fake progress or imply an action completed before confirmation.

## Accessibility
- Maintain readable contrast and scalable text.
- Provide accessible labels and logical focus order.
- Ensure touch targets are comfortable and controls remain usable with keyboard/screen readers where supported.
- Do not communicate state through color or motion alone.

## Review checklist
- Does the browser remain the dominant surface?
- Can the user discover and dismiss Memo controls without losing context?
- Are all visible controls functional?
- Are all meaningful states represented?
- Does motion clarify rather than distract?
- Are touch, keyboard, accessibility, and reduced-motion behaviors considered?
