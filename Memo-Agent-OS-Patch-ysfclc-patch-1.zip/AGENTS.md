# Memo — Agent Operating System

## Mission
Build Memo as a coherent, reliable product on the active branch `ysfclc-patch-1`. Treat the repository and its checked-in documents as the durable project memory. Do not restart the product from assumptions or replace existing source before understanding it.

## Non-negotiable boundaries
- Work only on `ysfclc-patch-1` unless the user explicitly changes the target.
- **Never modify `memo-2`.** It is a separate repository and is out of scope.
- Preserve the Android source archive and its integrity checks until the archive has been inspected and the impact of any change is understood.
- Never claim a build, test, deployment, browser action, or repository write succeeded unless the relevant tool reports success.
- Do not bypass authentication, access controls, CAPTCHAs, or user confirmation. Browser automation should operate through the same visible UI a human can use.
- Do not introduce fake controls, placeholder functionality presented as complete, or speculative architecture.

## Product thesis
Memo is a browser-first working environment with a capable local agent. The browser is the primary surface; Memo actions should be available through a compact floating affordance and should not consume the browsing workspace. The browser can act as a universal adapter: if a person can legitimately interact with an interface, the local agent may assist with that same visible interface, subject to user control and site rules. Prefer robust visible-UI interaction over brittle bespoke integrations when appropriate, but use official integrations where they are clearly safer or more reliable.

## Knowledge map and reading order
1. Read this file and `USER_CONTEXT.md`.
2. Read `MEMO_TO_FIRMA.md` and any product vision documents if present. If missing, record that fact; do not invent their contents.
3. Read `ARCHITECTURE.md`, `DECISIONS.md`, `PROGRESS.md`, `BLOCKERS.md`, and `SESSION_LOG.md`.
4. Inspect `TASKS.md`, the build workflow, source archive contents, checksum manifest, and verification scripts.
5. Inspect the actual application source before planning implementation.

## Session protocol
At the start:
- Confirm repository, branch, working tree, and latest commit.
- Read the knowledge map above and inspect recent commits/CI.
- Identify the smallest valuable task consistent with the product vision.

During work:
- Trace existing behavior before changing it.
- Make focused, reversible changes; preserve existing conventions.
- Keep UI browser-first, polished, accessible, and responsive.
- Implement real behavior and all relevant loading, empty, error, offline, permission, and authentication states.
- Add or update tests for changed behavior.

Before finishing:
- Run the narrowest relevant tests, then the repository's required verification/build commands where possible.
- Review the diff for accidental scope changes, secrets, placeholders, and regressions.
- Update `PROGRESS.md`, `SESSION_LOG.md`, `DECISIONS.md`, and `BLOCKERS.md` as appropriate.
- Commit only when repository write access is available and the user-authorized scope is clear.
- Report exact changes, tests and outcomes, commit hash, and unresolved blockers. Be explicit about anything not verified.

## Quality bar
- The browser remains the dominant workspace; agent UI is compact and contextual.
- Visual hierarchy, spacing, typography, transitions, and touch targets should feel production-grade.
- Motion should communicate state and hierarchy, not decorate every interaction.
- No dead buttons, fake progress, fabricated data, or hidden side effects.
- Prefer local-first operation and provider independence where consistent with the existing architecture.
- Explain permissions and consequential actions; ask before submitting, purchasing, posting, deleting, or sending.

## Definition of done
A task is done only when implementation, tests/verification, UX states, documentation, and truthful reporting are complete. If the environment prevents one of these, state the limitation and leave a reproducible next step.
