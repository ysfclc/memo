# User & Product Context

This file captures durable project-relevant preferences and requirements. Treat it as working context, not as a substitute for current user instructions.

## Collaboration preferences
- The user expects autonomous, end-to-end engineering rather than repeated plans without implementation.
- Be direct and specific. Do not overstate progress or claim unverified work.
- Preserve project continuity across sessions through repository documentation.
- When delivery by ZIP is requested, provide a usable ZIP and clear application instructions; do not silently change the source package or repository layout.

## Product direction
- Memo should be a coherent, sellable product, not a demo dashboard.
- Browser experience is central and should feel like a proper browser, with browsing space prioritized.
- Memo actions should appear as a compact floating icon/control rather than occupying the screen permanently.
- The agent should be able to work through visible interfaces a human can use where appropriate — the “Browser as Universal Adapter” idea — reducing reliance on fragile one-off integrations.
- Visible-UI automation must remain within user-authorized access and site rules. Never bypass authentication or security controls.

## Reported issue to investigate
- User reports that LinkedIn sign-in via Google does not work in Memo's browser, while a ChatGPT-associated sign-in path works for them.
- Reproduce and inspect the actual browser/auth flow before proposing a fix. Do not infer the cause from this report alone.

## Engineering preferences
- Inspect existing code and architecture before changing them.
- Favor robust, maintainable behavior over superficial UI patches.
- No dead buttons, fake integrations, placeholder screens represented as finished features, or fabricated success states.
- Preserve local-first/provider-independent goals where supported by the actual architecture.
- Make consequential actions explicit and user-controlled.
