# Architecture Notes

## Verified from repository/workflow inspection
- The repository currently distributes the Android application source in `Memo-Android-Repository.zip`.
- A separate `memo1-task-runbook.zip` is present.
- CI workflow: `.github/workflows/build-apk.yml`.
- CI uses Java 17, Android SDK platform 35, build-tools 35.0.0, and Gradle 8.13.
- Expected Gradle modules: `:core` and `:app`.
- CI checks include `:core:test`, `:app:testDebugUnitTest`, `:app:lintDebug`, and `:app:assembleDebug`.
- Workflow performs source archive path/hash validation and selected Android manifest/runtime checks.

## Not yet verified — inspect source before documenting
- Kotlin/Java versions and Android UI toolkit.
- App navigation and state-management approach.
- Browser engine, tab/session model, cookie and storage handling.
- Agent orchestration/runtime and local model integration.
- Persistence, encryption, permission boundaries, and background execution.
- Test architecture and dependency-injection approach.

## Expected inspection sequence
1. Read archive task manifest and checksum manifest.
2. Run the repository's source verification script before and after extraction as prescribed by the runbook.
3. Inspect Gradle settings/build files and module boundaries.
4. Trace app entry point, navigation, browser surface, floating Memo controls, and agent invocation path.
5. Trace authentication/session handling and reproduce the LinkedIn issue.
6. Update this document only with facts verified from source.

## Safety and integrity
Do not replace the source archive or weaken checksum/path validation as a shortcut. Keep browser automation inside the user's authorized session and visible UI; require confirmation for consequential actions.
