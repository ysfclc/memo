package app.memo.ui

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.graphics.Bitmap
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import app.memo.core.domain.AgentRun
import app.memo.core.domain.RunStatus
import app.memo.core.domain.StepKind
import app.memo.core.domain.StepStatus
import app.memo.runtime.MemoRuntime
import app.memo.runtime.Planner
import app.memo.ui.components.EmptyState
import app.memo.ui.components.MemoButton
import app.memo.ui.components.MemoButtonStyle
import app.memo.ui.components.MemoCard
import app.memo.ui.components.Pill
import app.memo.ui.components.ScreenHeader
import app.memo.ui.components.StatTile
import app.memo.ui.nav.MemoNavShell
import app.memo.ui.nav.NavState
import app.memo.ui.nav.Route
import app.memo.ui.nav.SharedKind
import app.memo.ui.nav.sharedElement
import app.memo.ui.theme.MemoTheme
import org.json.JSONObject

/** The root of the app. Navigation state lives here; the shell owns animation and back handling. */
@Composable
fun MemoRoot(runtime: MemoRuntime) {
    var route by rememberSaveable { mutableStateOf(Route.LIVE) }
    var sheetOpen by rememberSaveable { mutableStateOf(false) }
    val snap by runtime.snapshot

    MemoNavShell(
        state = NavState(route = route, sheetOpen = sheetOpen),
        onStateChange = { next ->
            route = next.route
            sheetOpen = next.sheetOpen
        },
    ) { current ->
        when (current) {
            Route.LIVE -> LiveScreen(
                runs = snap.runs,
                auditCount = snap.auditCount,
                auditOk = snap.auditOk,
                draftCount = snap.drafts.size,
                onApprove = { run, step -> runtime.decide(run, step, true) },
                onVeto = { run, step -> runtime.decide(run, step, false) },
                onStopAll = { runtime.stopEverything() },
                message = snap.lastReply,
            )
            Route.TALK -> TalkScreen(runtime = runtime)
            Route.WORK -> WorkScreen(snap.people, snap.companies, snap.tasks)
            Route.STUDIO -> StudioScreen(snap.drafts)
            Route.BROWSER -> BrowserScreen()
            Route.MODELS -> ModelsScreen(runtime.models)
            Route.SETTINGS -> SettingsScreen(
                auditCount = snap.auditCount,
                auditOk = snap.auditOk,
                quarantined = snap.quarantined,
                storageError = snap.storageError,
                recoveryPending = snap.recoveryPending,
                onConfirmRecovery = { runtime.confirmRecovery() },
                onStopAll = { runtime.stopEverything() },
            )
        }
    }
}

fun humanize(name: String): String = name.lowercase().replace('_', ' ')

private fun pretty(json: String): String =
    runCatching { JSONObject(json).toString(2) }.getOrDefault(json)

// ------------------------------------------------------------------- Live

@Composable
fun LiveScreen(
    runs: List<AgentRun>,
    auditCount: Int,
    auditOk: Boolean,
    draftCount: Int,
    onApprove: (String, String) -> Unit,
    onVeto: (String, String) -> Unit,
    onStopAll: () -> Unit,
    message: String,
) {
    val waiting = runs.flatMap { run ->
        run.steps.filter { it.status == StepStatus.WAITING_USER && it.spec.kind == StepKind.HUMAN_APPROVAL }
            .map { run to it }
    }
    val active = runs.count { it.status == RunStatus.RUNNING || it.status == RunStatus.WAITING_USER }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Live", "What Memo is doing, and what waits for you.")
        Row(
            Modifier.padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            StatTile("Running", active, Modifier.weight(1f))
            StatTile("Approvals", waiting.size, Modifier.weight(1f))
            StatTile("Drafts", draftCount, Modifier.weight(1f))
            StatTile("Audit", auditCount, Modifier.weight(1f), suffix = if (auditOk) " ✓" else " !")
        }
        if (message.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(message, modifier = Modifier.padding(horizontal = 20.dp), color = MemoTheme.colors.inkMuted, fontSize = 13.sp)
        }
        Spacer(Modifier.height(12.dp))

        LazyColumn(
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f),
        ) {
            if (waiting.isNotEmpty()) {
                item { Text("Waiting for you", style = MemoTheme.typography.subtitle, color = MemoTheme.colors.ink) }
                items(waiting, key = { (run, step) -> run.id + step.spec.id }) { (run, step) ->
                    MemoCard {
                        Text(run.spec.title, style = MemoTheme.typography.subtitle, color = MemoTheme.colors.ink)
                        Spacer(Modifier.height(4.dp))
                        Text("Review the filled artifact before it is saved.", color = MemoTheme.colors.inkMuted, fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MemoTheme.colors.canvas)
                                .padding(12.dp),
                        ) {
                            Text(
                                step.artifact.ifBlank { "(nothing filled yet)" }.let(::pretty),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = MemoTheme.colors.ink,
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MemoButton(
                                onClick = { onApprove(run.id, step.spec.id) },
                                enabled = step.artifact.isNotBlank(),
                                style = MemoButtonStyle.PRIMARY,
                            ) {
                                Icon(Icons.Outlined.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.size(6.dp))
                                Text("Approve")
                            }
                            MemoButton(
                                onClick = { onVeto(run.id, step.spec.id) },
                                style = MemoButtonStyle.SECONDARY,
                            ) {
                                Icon(Icons.Outlined.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.size(6.dp))
                                Text("Veto")
                            }
                        }
                    }
                }
            }

            item { Text("Recent runs", style = MemoTheme.typography.subtitle, color = MemoTheme.colors.ink) }
            if (runs.isEmpty()) {
                item {
                    Text(
                        "Nothing yet. Say or type a command in Talk.",
                        color = MemoTheme.colors.inkMuted,
                        fontSize = 14.sp,
                    )
                }
            }
            items(runs.sortedByDescending { it.createdAt }.take(30), key = { it.id }) { run ->
                MemoCard(Modifier.sharedElement(SharedKind.RUN, run.id)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            run.spec.title,
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MemoTheme.typography.subtitle,
                            color = MemoTheme.colors.ink,
                        )
                        Pill(humanize(run.status.name), emphasis = run.status == RunStatus.COMPLETED)
                    }
                    if (run.failure.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(run.failure, color = MemoTheme.colors.attention, fontSize = 13.sp)
                    }
                }
            }

            if (active > 0) {
                item {
                    MemoButton(onClick = onStopAll, style = MemoButtonStyle.QUIET, contentColor = MemoTheme.colors.attention) {
                        Text("Stop all active runs")
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------- Talk

@Composable
fun TalkScreen(runtime: MemoRuntime) {
    var text by rememberSaveable { mutableStateOf("") }
    var reply by remember { mutableStateOf("") }

    fun submit(raw: String) {
        if (raw.isBlank()) return
        reply = runtime.handleUtterance(raw)
        text = ""
    }

    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = if (result.resultCode == Activity.RESULT_OK) {
            result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        } else {
            null
        }
        if (!spoken.isNullOrBlank()) submit(spoken)
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        ScreenHeader("Talk", "Describe the work. Memo plans it and waits at each gate.")
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("e.g. Add Ada Lovelace to my CRM") },
            minLines = 2,
            shape = RoundedCornerShape(16.dp),
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            MemoButton(onClick = { submit(text) }, enabled = text.isNotBlank(), style = MemoButtonStyle.PRIMARY) {
                Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(6.dp))
                Text("Plan")
            }
            MemoButton(
                onClick = {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a Memo command")
                    }
                    runCatching { voice.launch(intent) }
                        .onFailure { reply = "Voice recognition is not available on this device." }
                },
                style = MemoButtonStyle.SECONDARY,
            ) {
                Icon(Icons.Outlined.Mic, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(6.dp))
                Text("Speak")
            }
        }
        Spacer(Modifier.height(16.dp))
        if (reply.isNotBlank()) {
            MemoCard(Modifier.sharedElement(SharedKind.MESSAGE_ARTIFACT, reply.hashCode().toString())) {
                Text(reply, fontSize = 15.sp, color = MemoTheme.colors.ink)
            }
            Spacer(Modifier.height(12.dp))
        }
        MemoCard {
            Text("Examples", style = MemoTheme.typography.subtitle, color = MemoTheme.colors.ink)
            Spacer(Modifier.height(6.dp))
            Text(Planner.helpText(), color = MemoTheme.colors.inkMuted, fontSize = 13.sp)
        }
    }
}

// ------------------------------------------------------------------- Work

@Composable
fun WorkScreen(
    people: List<app.memo.core.domain.Person>,
    companies: List<app.memo.core.domain.Company>,
    tasks: List<app.memo.core.domain.Task>,
) {
    LazyColumn(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item { ScreenHeader("Work", "People, companies and tasks you approved.") }
        item { SectionTitle("People (${people.size})") }
        if (people.isEmpty()) item { EmptyLine("No people yet. Try \"Add … to my CRM\".") }
        items(people, key = { it.fullName + it.phone }) { p ->
            MemoCard(Modifier.padding(horizontal = 20.dp).sharedElement(SharedKind.RECORD, p.fullName + p.phone)) {
                Text(p.fullName, style = MemoTheme.typography.subtitle, color = MemoTheme.colors.ink)
                if (p.notes.isNotBlank()) Text(p.notes, color = MemoTheme.colors.inkMuted, fontSize = 13.sp)
            }
        }
        item { SectionTitle("Companies (${companies.size})") }
        if (companies.isEmpty()) item { EmptyLine("Companies appear here once captured.") }
        items(companies, key = { it.domain }) { c ->
            MemoCard(Modifier.padding(horizontal = 20.dp).sharedElement(SharedKind.RECORD, c.domain)) {
                Text(c.displayName.ifBlank { c.domain }, style = MemoTheme.typography.subtitle, color = MemoTheme.colors.ink)
            }
        }
        item { SectionTitle("Tasks (${tasks.size})") }
        if (tasks.isEmpty()) item { EmptyLine("No tasks yet. Try \"Add task …\".") }
        items(tasks, key = { it.title + it.createdAt }) { t ->
            MemoCard(Modifier.padding(horizontal = 20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(t.title, modifier = Modifier.weight(1f), style = MemoTheme.typography.subtitle, color = MemoTheme.colors.ink)
                    Pill(humanize(t.state.name))
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, modifier = Modifier.padding(horizontal = 20.dp), style = MemoTheme.typography.subtitle, color = MemoTheme.colors.ink)
}

@Composable
private fun EmptyLine(text: String) {
    Text(text, modifier = Modifier.padding(horizontal = 20.dp), color = MemoTheme.colors.inkMuted, fontSize = 13.sp)
}

// ----------------------------------------------------------------- Studio

@Composable
fun StudioScreen(drafts: List<app.memo.core.domain.ContentDraft>) {
    LazyColumn(
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item { ScreenHeader("Studio", "Drafts approved for use. Publishing is not wired in this build.") }
        if (drafts.isEmpty()) item { EmptyLine("No drafts yet. Try \"Draft post about …\".") }
        items(drafts, key = { it.title + it.createdAt }) { d ->
            MemoCard(Modifier.padding(horizontal = 20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        d.title,
                        modifier = Modifier.weight(1f),
                        style = MemoTheme.typography.subtitle,
                        color = MemoTheme.colors.ink,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Pill(humanize(d.kind.name))
                }
                Spacer(Modifier.height(8.dp))
                Text(d.body, color = MemoTheme.colors.inkMuted, fontSize = 13.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// ---------------------------------------------------------------- Browser

/** Managed HTTPS browsing session; no JavaScript bridge is exposed to websites. */
@Composable
fun BrowserScreen() {
    val context = LocalContext.current
    var address by rememberSaveable { mutableStateOf("https://www.google.com") }
    var pageTitle by rememberSaveable { mutableStateOf("Ready") }
    var progress by rememberSaveable { mutableStateOf(0) }
    val browser = remember {
        WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.safeBrowsingEnabled = true
            android.webkit.CookieManager.getInstance().setAcceptCookie(true)
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    progress = newProgress
                    pageTitle = view?.title?.takeIf { it.isNotBlank() } ?: if (newProgress < 100) "Loading…" else "Page loaded"
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return true
                    return !uri.scheme.equals("https", ignoreCase = true)
                }
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    address = url.orEmpty(); pageTitle = "Loading…"
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    address = url.orEmpty()
                    pageTitle = view?.title?.takeIf { it.isNotBlank() } ?: "Page loaded"
                }
            }
        }
    }
    androidx.compose.runtime.DisposableEffect(browser) {
        onDispose { browser.stopLoading(); browser.onPause(); browser.destroy() }
    }
    fun navigate(raw: String) {
        val input = raw.trim()
        if (input.isBlank()) return
        val normalized = when {
            input.startsWith("https://", true) -> input
            input.startsWith("http://", true) -> "https://" + input.substringAfter("://")
            input.contains(' ') || !input.contains('.') -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(input, "UTF-8")
            else -> "https://$input"
        }
        val uri = android.net.Uri.parse(normalized)
        if (uri.scheme != "https" || uri.host.isNullOrBlank()) { pageTitle = "Blocked: HTTPS pages only"; return }
        address = normalized; browser.loadUrl(normalized)
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Browser", "In-app web session · HTTPS only")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = address, onValueChange = { address = it }, singleLine = true,
                modifier = Modifier.weight(1f), label = { Text("Website or search") })
            Spacer(Modifier.size(8.dp))
            androidx.compose.material3.Button(onClick = { navigate(address) }) { Text("Go") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(pageTitle, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MemoTheme.colors.inkMuted, fontSize = 12.sp)
            Text("$progress%", color = MemoTheme.colors.inkMuted, fontSize = 12.sp)
            TextButton(onClick = { if (browser.canGoBack()) browser.goBack() }) { Text("Back") }
            TextButton(onClick = { browser.reload() }) { Text("Reload") }
        }
        AndroidView(factory = { browser }, modifier = Modifier.fillMaxSize(), update = { view ->
            if (view.url.isNullOrBlank()) view.loadUrl("https://www.google.com")
        })
    }
}

// --------------------------------------------------------------- Settings

@Composable
fun SettingsScreen(
    auditCount: Int,
    auditOk: Boolean,
    quarantined: Int,
    storageError: String,
    recoveryPending: Boolean,
    onConfirmRecovery: () -> Unit,
    onStopAll: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp),
    ) {
        ScreenHeader("Settings", "Trust, audit and controls. Everything stays on this device.")
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (storageError.isNotEmpty()) {
                MemoCard {
                    Text("Storage", style = MemoTheme.typography.subtitle, color = MemoTheme.colors.attention)
                    Spacer(Modifier.height(4.dp))
                    Text(storageError, color = MemoTheme.colors.ink, fontSize = 13.sp)
                    if (recoveryPending) {
                        Spacer(Modifier.height(10.dp))
                        MemoButton(onClick = onConfirmRecovery, style = MemoButtonStyle.SECONDARY) {
                            Text("I reviewed my data, resume saving")
                        }
                    }
                }
            }
            MemoCard {
                Text("Audit trail", style = MemoTheme.typography.subtitle, color = MemoTheme.colors.ink)
                Spacer(Modifier.height(4.dp))
                Text(
                    "$auditCount outbound entries · chain " + if (auditOk) "verified" else "BROKEN",
                    color = if (auditOk) MemoTheme.colors.inkMuted else MemoTheme.colors.attention,
                    fontSize = 13.sp,
                )
                if (quarantined > 0) {
                    Text("$quarantined stored rows were quarantined on load.", color = MemoTheme.colors.attention, fontSize = 13.sp)
                }
            }
            MemoCard {
                Text("Kill switch", style = MemoTheme.typography.subtitle, color = MemoTheme.colors.ink)
                Spacer(Modifier.height(4.dp))
                Text("Stops every active run. Side effects already approved are not undone.", color = MemoTheme.colors.inkMuted, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                MemoButton(onClick = onStopAll, style = MemoButtonStyle.SECONDARY) { Text("Stop all runs") }
            }
            MemoCard {
                Text("Data", style = MemoTheme.typography.subtitle, color = MemoTheme.colors.ink)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Workspace, runs, audit and models live in app-private storage. Nothing leaves the device except pinned model downloads you start.",
                    color = MemoTheme.colors.inkMuted,
                    fontSize = 13.sp,
                )
            }
        }
    }
}
